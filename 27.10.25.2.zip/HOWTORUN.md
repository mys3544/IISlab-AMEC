# ====================================================================================================
# SETUP GUIDE - GETTING STARTED ON A NEW MACHINE
# ====================================================================================================

## Setting Up OpenCV and GStreamer DLL Paths

When running on a new machine, you need to configure the OpenCV and GStreamer DLL paths.

### Option 1: Set Environment Variable (Recommended)
```bash
# Set the AMEC base directory environment variable
set AMEC_BASE_DIR=C:\path\to\your\AMEC\installation
# Example:
set AMEC_BASE_DIR=C:\Users\igombala\Desktop\AMEC\AMEC
```

Or set it permanently in Windows:
1. Open System Properties → Environment Variables
2. Add `AMEC_BASE_DIR` with your AMEC installation path

### Option 2: Auto-Detection (Fallback)
The system will automatically try to detect common locations:
- Original location: `C:\Users\Mys\Desktop\AMEC\AMEC`
- New user location: `C:\Users\igombala\Desktop\AMEC\AMEC`
- Relative paths from the script directory

### Option 3: Modify config.py
Edit `config.py` and update the default base directory:

```python
base_dir = r'C:\Users\igombala\Desktop\AMEC\AMEC'  # Change this to your path
```

### Verify Setup
The system will print messages indicating whether DLL paths were found:
- `[OK] Added OpenCV DLL path: ...` - Success
- `[WARNING] OpenCV DLL path not found: ...` - Needs configuration

# ====================================================================================================
# CALIBRATION GUIDE - HOW TO CALIBRATE WHEN TRAVELING TO NEW LOCATIONS
# ====================================================================================================

## Quick Calibration for New Location

### 1. Enhanced Calibration (Better Accuracy)
```bash
python localization.py calibrate \
    --source udp://5000 \
    --use-gstreamer \
    --map-width-cm 305.0 \
    --map-height-cm 268.0 \
    --camera-height-cm 195.0 \
    --camera-angle-degrees 42.0 \
    --robot-height-cm 5.0 \
    --out enhanced_calibration.json
```
OR (single line version)
```bash
python localization.py calibrate --source udp://5000 --use-gstreamer --map-width-cm 305.0 --map-height-cm 268.0 --camera-height-cm 195.0     --camera-angle-degrees 42.0 --robot-height-cm 5.0 --out enhanced_calibration.json
```

**Steps:**
1. A window opens showing your camera feed
2. Click 4 corners in this order: Bottom-Left, Bottom-Right, Top-Right, Top-Left
3. Calibration completes automatically



### 2. Adjust Waypoints for New Arena
```bash
python run_waypoint_adjustment.py
```
**Steps:**
1. A window opens showing your camera feed
2. Press 'R' = restart
3. Click position of waypoints according to Text message in the Window
4. After all waypoint are adjusted press 'S' = save
5. Press 'Q = Quit


### 3. Verify Calibration
```bash
python start.py --target-waypoint Parking_Left
```

### 4. Parking slot Calibration

**Steps:**
1. A window opens showing your camera feed
2. Press 'C' to enter calibration mode
3. Press 'R' to reset
4. Press 'N' ro add new parking slot
5. Follow instructions
6. Press 'C' to exit calibration mode


## Important Parameters:
- `--map-width-cm`: Physical width of your track in cm
- `--map-height-cm`: Physical height of your track in cm
- `--source`: `udp://PORT` for UDP stream, `0` for webcam
- `--use-gstreamer`: Required for UDP streams

**See CALIBRATION_GUIDE.md for detailed instructions.**

# ====================================================================================================
# RUNNING COMMANDS
# ====================================================================================================


# 27.10.25 - default spravanie -bez YOLO detekcie znaciek

python start.py --fps 10 --udp-send-interval 10 --source-port 5000 --object-source-port 6000 --nav-port 5001 --parking-port 5002 --object-port 5003 --nav-udp-ip 192.168.0.105 --nav-udp-port 50001 --parking-udp-ip 192.168.0.105 --parking-udp-port 50002 --object-udp-ip 192.168.0.105 --object-udp-port 50003 --confidence 0.9 --target-waypoint Parking_Left --no-object-detection --continuous


## start.py Flags Reference

**Stream Configuration (stream multiplicator settings, NOT INPUT STREAM SETTINGS FROM RASPBERRY):**
- `--source-port` - UDP stream source port (default: 5000)
- `--object-source-port` - Object detection UDP stream port (default: 6000)
- `--nav-port` - Navigation stream port (default: 5001)
- `--parking-port` - Parking detection stream port (default: 5002)
- `--object-port` - Object detection stream port (default: 5003)
- `--fps` - Stream frame rate (default: 10)
- `--latency` - Stream latency in ms (default: 5)
- `--bitrate` - Video bitrate in kbps (default: 4000)
- `--udp-send-interval` - Send UDP packets every N frames (default: 1)

**UDP Output Configuration:**
- `--nav-udp-ip` / `--nav-udp-port` - Navigation UDP output
- `--parking-udp-ip` / `--parking-udp-port` - Parking detection UDP output
- `--object-udp-ip` / `--object-udp-port` - Object detection UDP output

**Model & Data Files:**
- `--calibration` - Calibration file (default: enhanced_calibration.json)
- `--waypoints` - Waypoints file (default: logical_waypoints.json)
- `--model` - Navigation/parking YOLO model (default: model_car_heading.pt)
- `--object-model` - Object detection YOLO model (default: best.pt)
- `--zones-file` - Parking zones file (default: parking_zones.json)

**Behavior:**
- `--target-waypoint` - Target waypoint for navigation (default: Parking_Left)
- `--confidence` - Detection confidence threshold (default: 0.9)
- `--no-object-detection` - Skip object detection (only navigation & parking)
- `--continuous` - Enable continuous navigation (cycles through waypoints)
- `--use-yolo-heading` - Use YOLO-based heading instead of movement-based (default: movement-based)
- `--log-dir` - Log directory (default: logs)


