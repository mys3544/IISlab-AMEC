# Setting Up AMEC on a New Machine

## Problem
The original code had hardcoded OpenCV and GStreamer DLL paths specific to the original development machine. When running on a different machine, you would see errors like:
```
multiplier has stopped unexpectedly (exit code: 1)
```

## Solution
The code has been updated to automatically detect OpenCV and GStreamer paths. You have three options:

### Option 1: Set Environment Variable (Recommended)

**For PowerShell:**
```powershell
$env:AMEC_BASE_DIR = "C:\Users\igombala\Desktop\AMEC\AMEC"
python start.py --fps 10 --udp-send-interval 10 --source-port 5000 --target-waypoint Parking_Left --no-object-detection --continuous
```

**For Command Prompt:**
```cmd
set AMEC_BASE_DIR=C:\Users\igombala\Desktop\AMEC\AMEC
python start.py --fps 10 --udp-send-interval 10 --source-port 5000 --target-waypoint Parking_Left --no-object-detection --continuous
```

**To make it permanent:**
1. Open System Properties → Environment Variables
2. Click "New" under User variables
3. Variable name: `AMEC_BASE_DIR`
4. Variable value: Your AMEC installation path (e.g., `C:\Users\igombala\Desktop\AMEC\AMEC`)

### Option 2: Let Auto-Detection Find It

The system will automatically try these locations:
- `C:\Users\Mys\Desktop\AMEC\AMEC` (original)
- `C:\Users\igombala\Desktop\AMEC\AMEC` (new user)
- Relative to script directory

If your installation is in one of these locations, it should work automatically.

### Option 3: Edit config.py

Open `config.py` and modify line 47 to point to your installation:

```python
# Find this line (around line 47):
base_dir = r'C:\Users\Mys\Desktop\AMEC\AMEC'

# Change it to your path:
base_dir = r'C:\Users\igombala\Desktop\AMEC\AMEC'
```

## Files Updated
The following files now use the centralized configuration:
- ✓ `stream_multiplier.py`
- ✓ `object_detection.py`
- ✓ `adjust_waypoints.py`
- ✓ `localization.py`
- ✓ `navigation.py`
- ✓ `parking_detection.py`

## Verification
When you run the system, you should see messages like:
```
[OK] Auto-detected AMEC base directory: C:\Users\igombala\Desktop\AMEC\AMEC
[OK] Added OpenCV DLL path: C:\Users\igombala\Desktop\AMEC\AMEC\opencv-4.12.0\build\install\x64\vc17\bin
[OK] Added GStreamer DLL path: C:\Users\igombala\Desktop\AMEC\AMEC\gstreamer\1.0\msvc_x86_64\bin
```

If you see warnings, the system will still attempt to run but may encounter DLL errors.

## Complete Example Command for New Machine

```powershell
# Set the environment variable
$env:AMEC_BASE_DIR = "C:\Users\igombala\Desktop\AMEC\AMEC"

# Run the system
python start.py --fps 10 --udp-send-interval 10 --source-port 5000 --object-source-port 6000 --nav-port 5001 --parking-port 5002 --object-port 5003 --nav-udp-ip 192.168.0.105 --nav-udp-port 50001 --parking-udp-ip 192.168.0.105 --parking-udp-port 50002 --object-udp-ip 192.168.0.105 --object-udp-port 50003 --confidence 0.9 --target-waypoint Parking_Left --no-object-detection --continuous
```

## Troubleshooting

**If you still see DLL errors:**
1. Verify OpenCV and GStreamer are installed in the expected directory structure
2. Check that the DLL files exist in the paths shown in the error messages
3. Try setting the `AMEC_BASE_DIR` environment variable explicitly
4. Check `config.py` to see what default path it's using

**Directory structure expected:**
```
AMEC/
├── opencv-4.12.0/
│   └── build/
│       └── install/
│           └── x64/
│               └── vc17/
│                   └── bin/  (OpenCV DLLs here)
└── gstreamer/
    └── 1.0/
        └── msvc_x86_64/
            └── bin/  (GStreamer DLLs here)
```
