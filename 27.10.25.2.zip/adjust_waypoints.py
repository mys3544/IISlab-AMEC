#!/usr/bin/env python3
"""
Interactive waypoint adjustment tool.
Click on the video feed to position waypoints exactly where you want them.
"""

import argparse
import json
import os
import time
from pathlib import Path
from typing import List, Tuple, Optional
import numpy as np

# Add OpenCV and GStreamer paths
from config import setup_opencv_gstreamer_paths
setup_opencv_gstreamer_paths()
import cv2

from localization import load_calibration, open_video_capture


class WaypointAdjuster:
    """Interactive waypoint adjustment tool"""
    
    def __init__(self, calibration_file: str, waypoints_file: str):
        self.calib = load_calibration(Path(calibration_file))
        self.waypoints = self.load_waypoints(waypoints_file)
        self.H = self.calib.homography.astype(float)
        self.current_waypoint = 0
        self.window_name = "Adjust Waypoints"
        self.adjusting = False
        
    def load_waypoints(self, waypoints_file: str) -> List[dict]:
        """Load waypoints from JSON file"""
        with open(waypoints_file, 'r') as f:
            return json.load(f)
    
    def pixel_to_world(self, pixel_x: int, pixel_y: int) -> Tuple[float, float]:
        """Convert pixel coordinates to world coordinates"""
        pixel_point = np.array([[pixel_x, pixel_y]], dtype=np.float64)
        world_point = cv2.perspectiveTransform(pixel_point.reshape(-1, 1, 2), self.H)
        return float(world_point[0, 0, 0]), float(world_point[0, 0, 1])
    
    def world_to_pixel(self, world_x: float, world_y: float) -> Tuple[int, int]:
        """Convert world coordinates to pixel coordinates"""
        world_point = np.array([[world_x, world_y]], dtype=np.float64)
        pixel_point = cv2.perspectiveTransform(world_point.reshape(-1, 1, 2), np.linalg.inv(self.H))
        return int(pixel_point[0, 0, 0]), int(pixel_point[0, 0, 1])
    
    def mouse_callback(self, event, x, y, flags, param):
        """Handle mouse clicks for waypoint adjustment"""
        if event == cv2.EVENT_LBUTTONDOWN and self.adjusting:
            # Update current waypoint position
            world_x, world_y = self.pixel_to_world(x, y)
            self.waypoints[self.current_waypoint]['world_x'] = world_x
            self.waypoints[self.current_waypoint]['world_y'] = world_y
            
            print(f"Waypoint {self.current_waypoint + 1} '{self.waypoints[self.current_waypoint]['name']}' moved to ({world_x:.1f}, {world_y:.1f}) cm")
            
            # Move to next waypoint
            self.current_waypoint += 1
            if self.current_waypoint >= len(self.waypoints):
                print("All waypoints adjusted! Press 's' to save.")
                self.adjusting = False
                self.current_waypoint = 0
    
    def draw_instructions(self, frame):
        """Draw current instructions on the frame"""
        height, width = frame.shape[:2]
        
        if self.adjusting and self.current_waypoint < len(self.waypoints):
            waypoint = self.waypoints[self.current_waypoint]
            
            # Instructions background
            cv2.rectangle(frame, (10, 10), (width - 10, 100), (0, 0, 0), -1)
            cv2.rectangle(frame, (10, 10), (width - 10, 100), (255, 255, 255), 2)
            
            # Instructions text
            cv2.putText(frame, f"Adjusting Waypoint {self.current_waypoint + 1}/{len(self.waypoints)}", 
                       (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.putText(frame, f"Name: {waypoint['name']}", 
                       (20, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.putText(frame, f"Description: {waypoint['description']}", 
                       (20, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
            cv2.putText(frame, "Click to position this waypoint", 
                       (20, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        else:
            # Control instructions
            cv2.rectangle(frame, (10, 10), (width - 10, 80), (0, 0, 0), -1)
            cv2.rectangle(frame, (10, 10), (width - 10, 80), (255, 255, 255), 2)
            
            cv2.putText(frame, "Waypoint Adjustment Complete", 
                       (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(frame, "Press 's' to save, 'r' to restart, 'q' to quit", 
                       (20, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
    
    def draw_waypoints(self, frame):
        """Draw all waypoints on the frame"""
        for i, waypoint in enumerate(self.waypoints):
            pixel_x, pixel_y = self.world_to_pixel(waypoint['world_x'], waypoint['world_y'])
            
            if 0 <= pixel_x < frame.shape[1] and 0 <= pixel_y < frame.shape[0]:
                # Highlight current waypoint being adjusted
                if i == self.current_waypoint and self.adjusting:
                    # Draw large circle for current waypoint
                    cv2.circle(frame, (pixel_x, pixel_y), 15, (0, 255, 255), -1)
                    cv2.circle(frame, (pixel_x, pixel_y), 10, (255, 255, 255), -1)
                    # Draw pulsing effect
                    cv2.circle(frame, (pixel_x, pixel_y), 20, (0, 255, 255), 2)
                else:
                    # Draw normal waypoint
                    cv2.circle(frame, (pixel_x, pixel_y), 8, waypoint['color'], -1)
                    cv2.circle(frame, (pixel_x, pixel_y), 4, (255, 255, 255), -1)
                
                # Draw waypoint number
                cv2.putText(frame, str(i + 1), (pixel_x - 5, pixel_y + 5), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
                
                # Draw waypoint name
                cv2.putText(frame, waypoint['name'], (pixel_x + 10, pixel_y - 10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, waypoint['color'], 1)
                
                # Draw coordinates
                coord_text = f"({waypoint['world_x']:.1f}, {waypoint['world_y']:.1f})"
                cv2.putText(frame, coord_text, (pixel_x + 10, pixel_y + 10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.3, (150, 150, 150), 1)
    
    def run_adjustment(self, source: str, stream_config: dict = None):
        """Run the waypoint adjustment process"""
        # Open video capture
        cap = open_video_capture(source, stream_config)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open video source: {source}")
        
        # Setup window and mouse callback
        cv2.namedWindow(self.window_name, cv2.WINDOW_NORMAL)
        cv2.setMouseCallback(self.window_name, self.mouse_callback)
        
        print("=== Interactive Waypoint Adjustment ===")
        print("This tool allows you to click and position waypoints exactly where you want them.")
        print()
        print("Controls:")
        print("- Click to position the current waypoint")
        print("- Press 'r' to restart adjustment")
        print("- Press 's' to save changes")
        print("- Press 'q' to quit")
        print()
        print("Press SPACE to start adjusting waypoints...")
        
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                
                # Draw waypoints and instructions
                self.draw_waypoints(frame)
                self.draw_instructions(frame)
                
                cv2.imshow(self.window_name, frame)
                key = cv2.waitKey(1) & 0xFF
                
                if key == ord('q'):
                    break
                elif key == ord(' '):  # Space to start
                    self.adjusting = True
                    self.current_waypoint = 0
                    print("Starting waypoint adjustment...")
                elif key == ord('r'):  # Restart
                    self.adjusting = True
                    self.current_waypoint = 0
                    print("Restarting waypoint adjustment...")
                elif key == ord('s'):  # Save
                    self.save_waypoints()
                    print("Waypoints saved!")
                    
        finally:
            cap.release()
            cv2.destroyWindow(self.window_name)
    
    def save_waypoints(self):
        """Save adjusted waypoints to file"""
        # Remove the 'index' field if it exists
        for waypoint in self.waypoints:
            if 'index' in waypoint:
                del waypoint['index']
        
        # Save to file
        with open("logical_waypoints.json", 'w') as f:
            json.dump(self.waypoints, f, indent=2)
        
        print(f"Waypoints saved to logical_waypoints.json")


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Interactive waypoint adjustment")
    parser.add_argument("--calibration", default="enhanced_calibration.json", 
                       help="Calibration file path")
    parser.add_argument("--waypoints", default="logical_waypoints.json", 
                       help="Waypoints file path")
    parser.add_argument("--source", default="udp://5000", help="Video source")
    parser.add_argument("--use-gstreamer", action="store_true", help="Use GStreamer for UDP streams")
    parser.add_argument("--stream-port", type=int, default=5000, help="UDP stream port")
    parser.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer")
    
    args = parser.parse_args()
    
    # Check if files exist
    if not Path(args.calibration).exists():
        print(f"Error: Calibration file '{args.calibration}' not found!")
        return
    
    if not Path(args.waypoints).exists():
        print(f"Error: Waypoints file '{args.waypoints}' not found!")
        return
    
    # Setup stream configuration
    stream_config = None
    if args.use_gstreamer:
        stream_config = {
            "use_gstreamer": True,
            "port": args.stream_port,
            "latency": args.stream_latency
        }
    
    # Create adjuster
    adjuster = WaypointAdjuster(args.calibration, args.waypoints)
    
    # Run adjustment
    adjuster.run_adjustment(args.source, stream_config)


if __name__ == "__main__":
    main()
