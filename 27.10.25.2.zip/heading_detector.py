#!/usr/bin/env python3
"""
Enhanced YOLO detector that can detect both robot position and heading.
Uses the model_car_heading.pt with 5 heading classes.
"""

import numpy as np
from typing import Optional, Tuple, List, Dict
from ultralytics import YOLO


class HeadingDetector:
    """YOLO detector for robot position and heading detection"""
    
    def __init__(self, model_path: str = "model_car_heading.pt", device: Optional[str] = None):
        self.model = YOLO(model_path)
        self.device = device
        
        # Heading class mapping
        self.heading_classes = {
            'rosmaster_r2_west': 270.0,    # West
            'rosmaster_r2_east': 90.0,     # East  
            'rosmaster_r2_south': 180.0,   # South
            'rosmaster_r2_north': 0.0,     # North
            'rosmaster_r2_rotation': None  # Indifferent/unknown
        }
        
        # Reverse mapping for debugging
        self.class_names = {
            0: 'rosmaster_r2_west',
            1: 'rosmaster_r2_east', 
            2: 'rosmaster_r2_south',
            3: 'rosmaster_r2_north',
            4: 'rosmaster_r2_rotation'
        }
    
    def detect_robot_state(self, frame_bgr: np.ndarray) -> Optional[Dict]:
        """
        Detect robot position and heading from frame
        
        Returns:
            Dict with keys: 'position' (x, y), 'heading' (degrees), 'confidence', 'class_name'
            or None if no detection
        """
        # Run inference
        results = self.model(frame_bgr, verbose=False, device=self.device)
        if not results:
            return None
        
        result = results[0]
        if result.boxes is None or len(result.boxes) == 0:
            return None
        
        # Get the best detection (highest confidence)
        confidences = result.boxes.conf.cpu().numpy()
        best_idx = np.argmax(confidences)
        
        # Get bounding box and class
        x1, y1, x2, y2 = result.boxes.xyxy[best_idx].cpu().numpy()
        class_id = int(result.boxes.cls[best_idx].cpu().numpy())
        confidence = float(confidences[best_idx])
        
        # Calculate centroid
        centroid_x = (x1 + x2) / 2.0
        centroid_y = (y1 + y2) / 2.0
        
        # Get heading from class using model's actual class names
        model_class_name = self.model.names.get(class_id, f'class_{class_id}')
        heading = self.heading_classes.get(model_class_name)
        
        return {
            'position': (centroid_x, centroid_y),
            'heading': heading,
            'confidence': confidence,
            'class_name': model_class_name,
            'bbox': (x1, y1, x2, y2)
        }
    
    def detect_first_centroid(self, frame_bgr: np.ndarray) -> Optional[Tuple[float, float]]:
        """
        Legacy method for compatibility - returns only position
        """
        detection = self.detect_robot_state(frame_bgr)
        if detection:
            return detection['position']
        return None
    
    def get_heading_from_class(self, class_name: str) -> Optional[float]:
        """Get heading angle from class name"""
        return self.heading_classes.get(class_name)
    
    def get_class_from_heading(self, heading: float) -> Optional[str]:
        """Get class name from heading angle (nearest match)"""
        if heading is None:
            return 'rosmaster_r2_rotation'
        
        # Normalize heading to 0-360
        heading = heading % 360
        
        # Find closest heading class
        min_diff = float('inf')
        closest_class = None
        
        for class_name, class_heading in self.heading_classes.items():
            if class_heading is None:
                continue
            
            diff = min(abs(heading - class_heading), abs(heading - class_heading + 360), abs(heading - class_heading - 360))
            if diff < min_diff:
                min_diff = diff
                closest_class = class_name
        
        return closest_class


class MultiHeadingDetector:
    """Detector that can handle multiple robot detections and choose the best one"""
    
    def __init__(self, model_path: str = "model_car_heading.pt", device: Optional[str] = None):
        self.detector = HeadingDetector(model_path, device)
        self.last_heading = None
        self.heading_history = []
        self.max_history = 5
    
    def detect_best_robot(self, frame_bgr: np.ndarray, min_confidence: float = 0.5) -> Optional[Dict]:
        """
        Detect the best robot from multiple detections
        
        Args:
            frame_bgr: Input frame
            min_confidence: Minimum confidence threshold
            
        Returns:
            Best robot detection or None
        """
        # Run inference
        results = self.detector.model(frame_bgr, verbose=False, device=self.detector.device)
        if not results:
            return None
        
        result = results[0]
        if result.boxes is None or len(result.boxes) == 0:
            return None
        
        # Get all detections above confidence threshold
        confidences = result.boxes.conf.cpu().numpy()
        valid_detections = confidences >= min_confidence
        
        if not np.any(valid_detections):
            return None
        
        # Get valid detections
        valid_boxes = result.boxes.xyxy[valid_detections]
        valid_classes = result.boxes.cls[valid_detections].cpu().numpy().astype(int)
        valid_confs = confidences[valid_detections]
        
        # Choose best detection (highest confidence)
        best_idx = np.argmax(valid_confs)
        
        x1, y1, x2, y2 = valid_boxes[best_idx].cpu().numpy()
        class_id = int(valid_classes[best_idx])
        confidence = float(valid_confs[best_idx])
        
        # Calculate centroid
        centroid_x = (x1 + x2) / 2.0
        centroid_y = (y1 + y2) / 2.0
        
        # Get heading from class using model's actual class names
        model_class_name = self.detector.model.names.get(class_id, f'class_{class_id}')
        heading = self.detector.heading_classes.get(model_class_name)
        
        # Debug output
        print(f"DEBUG: class_id={class_id}, model_class_name={model_class_name}, heading={heading}")
        
        # Update heading history for smoothing
        if heading is not None:
            self.heading_history.append(heading)
            if len(self.heading_history) > self.max_history:
                self.heading_history.pop(0)
            
            # Use current heading directly (disable smoothing for debugging)
            self.last_heading = heading
        else:
            # Use last known heading if current detection is unclear
            self.last_heading = self.last_heading
        
        return {
            'position': (centroid_x, centroid_y),
            'heading': self.last_heading,
            'confidence': confidence,
            'class_name': model_class_name,
            'bbox': (x1, y1, x2, y2)
        }
    
    def detect_first_centroid(self, frame_bgr: np.ndarray) -> Optional[Tuple[float, float]]:
        """Legacy method for compatibility"""
        detection = self.detect_best_robot(frame_bgr)
        if detection:
            return detection['position']
        return None
    
    def _angular_mean(self, angles: List[float]) -> float:
        """Calculate the proper angular mean of a list of angles in degrees"""
        if not angles:
            return 0.0
        
        # Convert to radians
        angles_rad = [np.radians(angle) for angle in angles]
        
        # Calculate mean of sin and cos components
        sin_sum = sum(np.sin(angle) for angle in angles_rad)
        cos_sum = sum(np.cos(angle) for angle in angles_rad)
        
        # Calculate mean angle
        mean_angle_rad = np.arctan2(sin_sum, cos_sum)
        
        # Convert back to degrees and normalize to 0-360
        mean_angle_deg = np.degrees(mean_angle_rad)
        if mean_angle_deg < 0:
            mean_angle_deg += 360
        
        return mean_angle_deg


def test_heading_detection():
    """Test function to verify heading detection works"""
    import cv2
    
    detector = HeadingDetector("model_car_heading.pt")
    
    # Test with webcam
    cap = cv2.VideoCapture(0)
    
    print("Testing heading detection...")
    print("Press 'q' to quit")
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        detection = detector.detect_robot_state(frame)
        
        if detection:
            pos = detection['position']
            heading = detection['heading']
            conf = detection['confidence']
            class_name = detection['class_name']
            
            # Draw detection
            cv2.circle(frame, (int(pos[0]), int(pos[1])), 10, (0, 255, 0), -1)
            cv2.putText(frame, f"{class_name}: {heading}°", (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(frame, f"Conf: {conf:.2f}", (10, 60), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        cv2.imshow("Heading Detection Test", frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    test_heading_detection()
