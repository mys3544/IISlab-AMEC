#!/usr/bin/env python3
"""
Movement-based heading detector that determines robot heading based on position changes.
Uses North, South, East, West cardinal directions based on the larger coordinate change.
"""

import numpy as np
from typing import Optional, Tuple, List, Dict
from collections import deque
import math


class MovementHeadingDetector:
    """Detector that determines robot heading based on movement between frames"""
    
    def __init__(self, history_size: int = 5, min_movement_threshold: float = 5.0):
        """
        Initialize movement-based heading detector
        
        Args:
            history_size: Number of previous positions to keep for smoothing
            min_movement_threshold: Minimum movement distance (cm) to consider for heading detection
        """
        self.history_size = history_size
        self.min_movement_threshold = min_movement_threshold
        self.position_history = deque(maxlen=history_size)
        self.last_heading_class = "rosmaster_r2_rotation"  # Default to unknown/rotation
        self.heading_history = deque(maxlen=10)  # Keep history of detected headings
        
        # Heading class mapping (same as original detector)
        self.heading_classes = {
            'rosmaster_r2_west': 270.0,    # West
            'rosmaster_r2_east': 90.0,     # East  
            'rosmaster_r2_south': 180.0,   # South
            'rosmaster_r2_north': 0.0,     # North
            'rosmaster_r2_rotation': None  # Indifferent/unknown
        }
    
    def update_position(self, x: float, y: float) -> Optional[str]:
        """
        Update robot position and determine heading based on movement
        
        Args:
            x: Robot X position in world coordinates (cm)
            y: Robot Y position in world coordinates (cm)
            
        Returns:
            Heading class name or None if insufficient movement
        """
        # Add current position to history
        self.position_history.append((x, y))
        
        # Need at least 2 positions to determine movement
        if len(self.position_history) < 2:
            return None
        
        # Calculate movement from previous position
        prev_x, prev_y = self.position_history[-2]
        dx = x - prev_x
        dy = y - prev_y
        
        # Calculate total movement distance
        movement_distance = math.sqrt(dx**2 + dy**2)
        
        # Debug output
        print(f"DEBUG Movement: dx={dx:.2f}, dy={dy:.2f}, distance={movement_distance:.2f}, threshold={self.min_movement_threshold}")
        
        # Only determine heading if movement is significant
        if movement_distance < self.min_movement_threshold:
            print(f"DEBUG Movement: Insufficient movement ({movement_distance:.2f} < {self.min_movement_threshold}), using last heading: {self.last_heading_class}")
            return self.last_heading_class  # Return last known heading
        
        # Determine heading based on larger coordinate change
        # Use absolute values to determine primary direction
        abs_dx = abs(dx)
        abs_dy = abs(dy)
        
        # Determine cardinal direction based on which coordinate changed more
        # Use a more robust comparison with a small tolerance for near-equal movements
        coordinate_ratio = abs_dx / abs_dy if abs_dy > 0 else float('inf')
        movement_dominance_threshold = 1.2  # Require 20% more movement in one direction
        
        # Handle case where one coordinate change is very small (noise)
        min_coordinate_change = 0.5  # Minimum 0.5cm change to consider a direction
        
        # Check if we have significant movement in at least one direction
        if abs_dx < min_coordinate_change and abs_dy < min_coordinate_change:
            # Both movements are too small - keep last heading
            print(f"DEBUG Movement: Both movements too small (dx={dx:.2f}, dy={dy:.2f}), keeping last heading: {self.last_heading_class}")
            return self.last_heading_class
        
        # Determine primary direction based on which coordinate changed more significantly
        if abs_dx > abs_dy and coordinate_ratio > movement_dominance_threshold:
            # Horizontal movement clearly dominates
            if dx > 0:
                heading_class = "rosmaster_r2_east"   # Moving East (positive X)
            else:
                heading_class = "rosmaster_r2_west"   # Moving West (negative X)
        elif abs_dy > abs_dx and (1.0 / coordinate_ratio) > movement_dominance_threshold:
            # Vertical movement clearly dominates
            if dy > 0:
                heading_class = "rosmaster_r2_north"  # Moving North (positive Y)
            else:
                heading_class = "rosmaster_r2_south"  # Moving South (negative Y)
        else:
            # Movement is roughly equal in both directions - use the larger absolute change
            if abs_dx > abs_dy:
                # Slight horizontal preference
                if dx > 0:
                    heading_class = "rosmaster_r2_east"
                else:
                    heading_class = "rosmaster_r2_west"
            else:
                # Slight vertical preference
                if dy > 0:
                    heading_class = "rosmaster_r2_north"
                else:
                    heading_class = "rosmaster_r2_south"
        
        print(f"DEBUG Movement: Calculated heading: {heading_class} (dx={dx:.2f}, dy={dy:.2f}, abs_dx={abs_dx:.2f}, abs_dy={abs_dy:.2f}, ratio={coordinate_ratio:.2f})")
        
        # Update heading history for smoothing
        self.heading_history.append(heading_class)
        self.last_heading_class = heading_class
        
        return heading_class
    
    def get_heading_from_movement(self, x: float, y: float) -> Optional[float]:
        """
        Get heading angle from movement-based detection
        
        Args:
            x: Robot X position in world coordinates (cm)
            y: Robot Y position in world coordinates (cm)
            
        Returns:
            Heading angle in degrees or None if insufficient movement
        """
        heading_class = self.update_position(x, y)
        if heading_class:
            return self.heading_classes.get(heading_class)
        return None
    
    def get_smoothed_heading_class(self, x: float, y: float) -> str:
        """
        Get smoothed heading class based on movement history
        
        Args:
            x: Robot X position in world coordinates (cm)
            y: Robot Y position in world coordinates (cm)
            
        Returns:
            Smoothed heading class name
        """
        current_heading = self.update_position(x, y)
        
        # Always use the current heading if it's valid (not None and not rotation)
        if current_heading is not None and current_heading != "rosmaster_r2_rotation":
            print(f"DEBUG Movement: Using current heading: {current_heading}")
            return current_heading
        
        # If no current heading, try to get most common from recent history
        if self.heading_history:
            # Use only recent history (last 3 entries) for more responsive changes
            recent_history = list(self.heading_history)[-3:] if len(self.heading_history) >= 3 else list(self.heading_history)
            
            # Count occurrences of each heading class in recent history
            heading_counts = {}
            for heading in recent_history:
                heading_counts[heading] = heading_counts.get(heading, 0) + 1
            
            # Get most common heading from recent history
            if heading_counts:
                most_common = max(heading_counts.items(), key=lambda x: x[1])
                if most_common[1] > 0:  # If we have any recent history
                    print(f"DEBUG Movement: Using recent history heading: {most_common[0]} (count: {most_common[1]})")
                    return most_common[0]
        
        # Fallback to last known heading
        print(f"DEBUG Movement: Using last known heading: {self.last_heading_class}")
        return self.last_heading_class
    
    def get_movement_vector(self) -> Optional[Tuple[float, float]]:
        """
        Get the current movement vector (dx, dy) from recent positions
        
        Returns:
            (dx, dy) movement vector or None if insufficient history
        """
        if len(self.position_history) < 2:
            return None
        
        # Get movement from last two positions
        prev_x, prev_y = self.position_history[-2]
        curr_x, curr_y = self.position_history[-1]
        
        return (curr_x - prev_x, curr_y - prev_y)
    
    def get_movement_speed(self) -> float:
        """
        Get current movement speed in cm/frame
        
        Returns:
            Movement speed in cm/frame
        """
        movement_vector = self.get_movement_vector()
        if movement_vector is None:
            return 0.0
        
        dx, dy = movement_vector
        return math.sqrt(dx**2 + dy**2)
    
    def reset_history(self):
        """Reset position and heading history"""
        self.position_history.clear()
        self.heading_history.clear()
        self.last_heading_class = "rosmaster_r2_rotation"
        print("DEBUG Movement: History reset")
    
    def force_heading_update(self, x: float, y: float) -> str:
        """
        Force a heading update even with small movements (for initial detection)
        
        Args:
            x: Robot X position in world coordinates (cm)
            y: Robot Y position in world coordinates (cm)
            
        Returns:
            Heading class name
        """
        # Temporarily reduce threshold for initial detection
        original_threshold = self.min_movement_threshold
        self.min_movement_threshold = 0.5  # Very low threshold
        
        heading_class = self.update_position(x, y)
        
        # Restore original threshold
        self.min_movement_threshold = original_threshold
        
        return heading_class if heading_class else self.last_heading_class
    
    def get_heading_direction_from_class(self, class_name: str) -> str:
        """Convert heading detector class name to cardinal direction"""
        if class_name == 'rosmaster_r2_north':
            return 'North'
        elif class_name == 'rosmaster_r2_east':
            return 'East'
        elif class_name == 'rosmaster_r2_south':
            return 'South'
        elif class_name == 'rosmaster_r2_west':
            return 'West'
        elif class_name == 'rosmaster_r2_rotation':
            return 'Unknown'
        else:
            return 'Unknown'


class CombinedHeadingDetector:
    """
    Combined detector that can use both YOLO-based and movement-based heading detection
    """
    
    def __init__(self, yolo_detector, movement_detector):
        """
        Initialize combined detector
        
        Args:
            yolo_detector: YOLO-based heading detector
            movement_detector: Movement-based heading detector
        """
        self.yolo_detector = yolo_detector
        self.movement_detector = movement_detector
        self.use_movement_heading = False  # Flag to switch between methods
    
    def set_heading_mode(self, use_movement: bool):
        """Set whether to use movement-based heading detection"""
        self.use_movement_heading = use_movement
    
    def detect_best_robot(self, frame_bgr: np.ndarray, robot_x: float, robot_y: float, 
                         min_confidence: float = 0.5) -> Optional[Dict]:
        """
        Detect robot with combined heading detection methods
        
        Args:
            frame_bgr: Input frame
            robot_x: Robot X position in world coordinates
            robot_y: Robot Y position in world coordinates
            min_confidence: Minimum confidence for YOLO detection
            
        Returns:
            Robot detection with appropriate heading
        """
        # Get YOLO detection for position and basic info
        yolo_detection = self.yolo_detector.detect_best_robot(frame_bgr, min_confidence)
        
        if yolo_detection is None:
            return None
        
        # Determine heading based on selected method
        if self.use_movement_heading:
            # Use movement-based heading
            movement_heading_class = self.movement_detector.get_smoothed_heading_class(robot_x, robot_y)
            movement_heading_angle = self.movement_detector.heading_classes.get(movement_heading_class)
            
            # Update detection with movement-based heading
            yolo_detection['heading'] = movement_heading_angle
            yolo_detection['class_name'] = movement_heading_class
            
            print(f"DEBUG: Using movement-based heading: {movement_heading_class} ({movement_heading_angle}°)")
        else:
            # Use YOLO-based heading (original method)
            print(f"DEBUG: Using YOLO-based heading: {yolo_detection['class_name']} ({yolo_detection['heading']}°)")
        
        return yolo_detection


def test_movement_heading():
    """Test function for movement-based heading detection"""
    import time
    
    detector = MovementHeadingDetector(history_size=5, min_movement_threshold=3.0)
    
    print("Testing movement-based heading detection...")
    print("Simulating robot movement...")
    
    # Simulate robot moving North
    positions = [
        (100.0, 100.0),  # Start
        (100.0, 95.0),   # Move North (negative Y)
        (100.0, 90.0),   # Continue North
        (100.0, 85.0),   # Continue North
        (100.0, 80.0),   # Continue North
    ]
    
    for i, (x, y) in enumerate(positions):
        heading_class = detector.update_position(x, y)
        heading_angle = detector.heading_classes.get(heading_class) if heading_class else None
        
        print(f"Position {i+1}: ({x:.1f}, {y:.1f}) -> {heading_class} ({heading_angle}°)")
        time.sleep(0.1)
    
    print("\nTesting East movement...")
    detector.reset_history()
    
    # Simulate robot moving East
    positions = [
        (100.0, 80.0),   # Start
        (105.0, 80.0),   # Move East (positive X)
        (110.0, 80.0),   # Continue East
        (115.0, 80.0),   # Continue East
        (120.0, 80.0),   # Continue East
    ]
    
    for i, (x, y) in enumerate(positions):
        heading_class = detector.update_position(x, y)
        heading_angle = detector.heading_classes.get(heading_class) if heading_class else None
        
        print(f"Position {i+1}: ({x:.1f}, {y:.1f}) -> {heading_class} ({heading_angle}°)")
        time.sleep(0.1)


if __name__ == "__main__":
    test_movement_heading()
