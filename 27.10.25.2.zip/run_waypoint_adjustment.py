#!/usr/bin/env python3
"""
Simple script to run waypoint adjustment.
This allows you to click and position waypoints exactly where you want them.
"""

import subprocess
import sys
import os

def main():
    # Configuration
    STREAM_PORT = 5000
    CALIBRATION_FILE = "enhanced_calibration.json"
    WAYPOINTS_FILE = "logical_waypoints.json"
    
    print("=== Interactive Waypoint Adjustment ===")
    print("This tool allows you to click and position waypoints exactly where you want them.")
    print()
    print("How it works:")
    print("1. Press SPACE to start adjusting waypoints")
    print("2. Click on the video feed to position each waypoint")
    print("3. The system will guide you through all 10 waypoints")
    print("4. Press 's' to save your changes")
    print()
    print("Controls:")
    print("- SPACE: Start/restart adjustment")
    print("- Click: Position current waypoint")
    print("- 's': Save changes")
    print("- 'r': Restart adjustment")
    print("- 'q': Quit")
    print()
    
    # Check if files exist
    if not os.path.exists(CALIBRATION_FILE):
        print(f"❌ Calibration file '{CALIBRATION_FILE}' not found!")
        print("Please run enhanced calibration first:")
        print("python run_enhanced_calibration.py")
        return
    
    if not os.path.exists(WAYPOINTS_FILE):
        print(f"❌ Waypoints file '{WAYPOINTS_FILE}' not found!")
        print("Please create logical waypoints first:")
        print("python update_waypoints.py")
        return
    
    print(f"✅ Found calibration file: {CALIBRATION_FILE}")
    print(f"✅ Found waypoints file: {WAYPOINTS_FILE}")
    print()
    print("Starting waypoint adjustment...")
    print("Press SPACE when ready to start positioning waypoints!")
    print()
    
    # Run waypoint adjustment
    cmd = [
        "python", "adjust_waypoints.py",
        "--calibration", CALIBRATION_FILE,
        "--waypoints", WAYPOINTS_FILE,
        "--source", f"udp://{STREAM_PORT}",
        "--use-gstreamer",
        "--stream-port", str(STREAM_PORT),
        "--stream-latency", "5"
    ]
    
    print(f"Running: {' '.join(cmd)}")
    print()
    
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print("❌ Waypoint adjustment failed!")
        return
    
    print("✅ Waypoint adjustment completed!")
    print("Your adjusted waypoints have been saved to logical_waypoints.json")
    print()
    print("You can now use the adjusted waypoints with:")
    print("python run_logical_navigation.py")

if __name__ == "__main__":
    main()
