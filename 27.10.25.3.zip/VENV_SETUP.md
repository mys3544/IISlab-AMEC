# Virtual Environment Setup for AMEC

## Why Use a Virtual Environment?

A virtual environment isolates your project's Python packages, making it easy to:
- ✅ **Transfer to new machines** - Just copy the folder and run `pip install -r requirements.txt`
- ✅ **Avoid version conflicts** - Different projects can use different package versions
- ✅ **Keep your system clean** - No global package pollution
- ✅ **Reproducible builds** - Same environment every time

## Quick Setup (Windows)

### Option 1: Automated Setup (Recommended)
```cmd
setup_env.bat
```

This will:
1. Create a virtual environment in `venv/` folder
2. Activate it
3. Install all required dependencies

### Option 2: Manual Setup
```cmd
REM 1. Create virtual environment
python -m venv venv

REM 2. Activate it
venv\Scripts\activate

REM 3. Install dependencies
pip install -r requirements.txt
```

## Quick Setup (Linux/Mac)

### Option 1: Automated Setup (Recommended)
```bash
chmod +x setup_env.sh
./setup_env.sh
```

### Option 2: Manual Setup
```bash
# 1. Create virtual environment
python3 -m venv venv

# 2. Activate it
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt
```

## Using the Virtual Environment

### Activating the Environment

**Windows:**
```cmd
venv\Scripts\activate
```

**Linux/Mac:**
```bash
source venv/bin/activate
```

When activated, your prompt will show `(venv)` prefix.

### Running Your Program

Once the environment is activated:
```cmd
python start.py --fps 10 --target-waypoint Parking_Left --no-object-detection --continuous
```

### Deactivating the Environment

```cmd
deactivate
```

## Transferring to a New Machine

### Method 1: Full Transfer (Recommended)

1. **Copy these files to the new machine:**
   - All `.py` files
   - `requirements.txt`
   - `config.py`
   - Model files (`.pt`)
   - JSON calibration files
   - `setup_env.bat` (Windows) or `setup_env.sh` (Linux/Mac)

2. **On the new machine:**
   ```cmd
   setup_env.bat    # Windows
   # or
   ./setup_env.sh   # Linux/Mac
   ```

3. **Set the AMEC_BASE_DIR environment variable:**
   ```cmd
   set AMEC_BASE_DIR=C:\path\to\your\AMEC\installation
   ```

4. **Install OpenCV and GStreamer DLLs** (required for video processing)
   - See `NEW_MACHINE_SETUP.md` for details

### Method 2: Export Current Environment

If you already have a working environment:

```cmd
REM Activate your virtual environment
venv\Scripts\activate

REM Export requirements
pip freeze > requirements_frozen.txt

REM Copy requirements_frozen.txt to new machine and install
pip install -r requirements_frozen.txt
```

## Updating Dependencies

If `requirements.txt` changes:

```cmd
REM Activate environment
venv\Scripts\activate

REM Update packages
pip install --upgrade -r requirements.txt
```

## File Structure

After setup, your project will look like:
```
AMEC\
├── venv\                    # Virtual environment (don't copy this)
├── *.py                     # Python source files
├── requirements.txt         # Package dependencies
├── setup_env.bat           # Setup script
├── start.py                # Main entry point
├── config.py               # Configuration
└── ... other files ...
```

**Important:** Don't copy the `venv` folder to a new machine - it contains machine-specific paths.

## Troubleshooting

### "pip is not recognized"
- Make sure virtual environment is activated
- Verify Python is installed

### "DLL errors when running"
- This is separate from Python packages
- You need to install OpenCV and GStreamer DLLs
- See `NEW_MACHINE_SETUP.md`

### "Import errors"
- Make sure virtual environment is activated
- Run `pip install -r requirements.txt` again

## Current Python Environment

Your system is using:
- **Python 3.12.7**
- **No virtual environment currently active**

To create and use a virtual environment:
```cmd
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## Benefits for Your Project

With a virtual environment, when you transfer to a new PC:
1. ✅ Python packages are locked to compatible versions
2. ✅ No conflicts with other projects
3. ✅ Easy to recreate the exact same environment
4. ✅ One command setup: `setup_env.bat` or `pip install -r requirements.txt`
