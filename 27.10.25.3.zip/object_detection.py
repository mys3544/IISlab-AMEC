#!/usr/bin/env python3
"""
Object Detection System using YOLO model from best.pt
Detects objects in video stream and sends UDP packets with detection information.
"""

import argparse
import json
import os
import socket
import time
from pathlib import Path
from typing import Optional, List, Dict, Tuple
import numpy as np

# Add OpenCV and GStreamer paths
from config import setup_opencv_gstreamer_paths
setup_opencv_gstreamer_paths()

import cv2

# Import from existing modules
from localization import (
    load_calibration, open_video_capture, perspective_map_pixels_to_world,
    compensate_for_robot_height, send_detection_udp
)


class ObjectDetector:
    """YOLO-based object detection system with UDP output"""
    
    def __init__(self, model_path: str = "best.pt", calibration_file: Optional[str] = None, 
                 device: Optional[str] = None):
        from ultralytics import YOLO
        self.model = YOLO(model_path)
        self.device = device
        
        # Load calibration if provided
        self.calib = None
        self.H = None
        if calibration_file and os.path.exists(calibration_file):
            self.calib = load_calibration(Path(calibration_file))
            self.H = self.calib.homography.astype(float)
            print(f"Loaded calibration from {calibration_file}")
        
        # UDP settings
        self.udp_socket = None
        self.udp_ip = "127.0.0.1"
        self.udp_port = 50003  # Different port from other services
        
        # Detection settings
        self.confidence_threshold = 0.5
        self.nms_threshold = 0.4
        
        # Statistics
        self.detection_count = 0
        self.last_detection_time = 0.0
        
        # Frame counter for UDP sending frequency control
        self.frame_count = 0
        self.udp_send_interval = 30  # Send UDP packets every 30 frames
        
    def setup_udp_socket(self, ip: str = "127.0.0.1", port: int = 50003):
        """Setup UDP socket for sending detection data"""
        self.udp_ip = ip
        self.udp_port = port
        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        print(f"UDP socket created for object detection on {self.udp_ip}:{self.udp_port}")
    
    def pixel_to_world(self, pixel_x: int, pixel_y: int) -> Tuple[float, float]:
        """Convert pixel coordinates to world coordinates using calibration"""
        if self.H is None:
            return float(pixel_x), float(pixel_y)
        
        pixel_point = np.array([[pixel_x, pixel_y]], dtype=np.float64)
        world_point = perspective_map_pixels_to_world(pixel_point, self.H)
        return world_point[0][0], world_point[0][1]
    
    def detect_objects(self, frame: np.ndarray) -> List[Dict]:
        """Detect objects in frame and return detection information"""
        detections = []
        
        # Run YOLO inference
        results = self.model(frame, verbose=False, device=self.device)
        if not results:
            return detections
        
        result = results[0]
        if result.boxes is None or len(result.boxes) == 0:
            return detections
        
        # Get class names
        class_names = result.names if hasattr(result, 'names') else {}
        
        # Process each detection
        for i, box in enumerate(result.boxes):
            confidence = float(box.conf[0])
            if confidence < self.confidence_threshold:
                continue
            
            # Get bounding box coordinates
            x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            
            # Get class information
            class_id = int(box.cls[0]) if hasattr(box, 'cls') and box.cls is not None else 0
            class_name = class_names.get(class_id, f"class_{class_id}")
            
            # Calculate center point
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            
            # Convert to world coordinates if calibration available
            world_x, world_y = self.pixel_to_world(int(center_x), int(center_y))
            
            # Apply height compensation if camera config is available
            if self.calib and self.calib.camera is not None:
                compensated_center = compensate_for_robot_height(
                    (center_x, center_y),
                    self.calib.camera,
                    self.calib.image_width,
                    self.calib.image_height
                )
                world_x, world_y = self.pixel_to_world(int(compensated_center[0]), int(compensated_center[1]))
            
            detection = {
                'id': self.detection_count,
                'class_id': class_id,
                'class_name': class_name,
                'confidence': confidence,
                'bbox': {
                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2
                },
                'center': {
                    'pixel_x': center_x,
                    'pixel_y': center_y,
                    'world_x': world_x,
                    'world_y': world_y
                },
                'timestamp': time.time()
            }
            
            detections.append(detection)
            self.detection_count += 1
        
        self.last_detection_time = time.time()
        return detections
    
    def send_detection_udp(self, detections: List[Dict]):
        """Send all detections in a single UDP packet"""
        if self.udp_socket is None:
            return

        payload = {
            "type": "object_detections",
            "timestamp": time.time(),
            "count": len(detections),
            "detections": []
        }

        for detection in detections:
            payload["detections"].append({
                "detection_id": detection['id'],
                "class_name": detection['class_name'],
                "class_id": detection['class_id'],
                "confidence": detection['confidence'],
                "bbox": detection['bbox'],
                "center_pixel": {
                    "x": detection['center']['pixel_x'],
                    "y": detection['center']['pixel_y']
                },
                "center_world": {
                    "x": detection['center']['world_x'],
                    "y": detection['center']['world_y']
                },
                "detected_at": detection['timestamp']
            })

        try:
            send_detection_udp(payload, self.udp_ip, self.udp_port, self.udp_socket)
            print(f"UDP: sent {len(detections)} detections")
        except Exception as e:
            print(f"UDP send error: {e}")
    
    def draw_detections(self, frame: np.ndarray, detections: List[Dict]) -> np.ndarray:
        """Draw detection bounding boxes and labels on frame"""
        # Avoid unnecessary copy if no detections
        if not detections:
            return frame
        
        frame_copy = frame.copy()
        
        for detection in detections:
            bbox = detection['bbox']
            x1, y1, x2, y2 = bbox['x1'], bbox['y1'], bbox['x2'], bbox['y2']
            class_name = detection['class_name']
            confidence = detection['confidence']
            
            # Draw bounding box
            color = (0, 255, 0)  # Green
            thickness = 2
            cv2.rectangle(frame_copy, (x1, y1), (x2, y2), color, thickness)
            
            # Draw center point
            center_x = int(detection['center']['pixel_x'])
            center_y = int(detection['center']['pixel_y'])
            cv2.circle(frame_copy, (center_x, center_y), 5, (255, 0, 0), -1)
            
            # Draw label
            label = f"{class_name}: {confidence:.2f}"
            label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
            
            # Draw label background
            cv2.rectangle(frame_copy, (x1, y1 - label_size[1] - 10), 
                         (x1 + label_size[0], y1), color, -1)
            
            # Draw label text
            cv2.putText(frame_copy, label, (x1, y1 - 5), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
            
            # Draw world coordinates if available
            if self.H is not None:
                world_x = detection['center']['world_x']
                world_y = detection['center']['world_y']
                coord_text = f"({world_x:.1f}, {world_y:.1f})"
                cv2.putText(frame_copy, coord_text, (x1, y2 + 20), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1)
        
        return frame_copy
    
    def run_detection(self, stream_port: int = 5000, show_video: bool = True, 
                     stream_latency: int = 5, udp_ip: str = "127.0.0.1", 
                     udp_port: int = 50003, confidence: float = 0.5, 
                     udp_send_interval: int = 30):
        """Run object detection with UDP stream"""
        
        # Setup UDP socket
        self.setup_udp_socket(udp_ip, udp_port)
        self.confidence_threshold = confidence
        self.udp_send_interval = udp_send_interval
        
        # Setup stream configuration
        stream_config = {
            "use_gstreamer": True,
            "port": stream_port,
            "latency": stream_latency
        }
        
        # Open UDP video stream
        cap = open_video_capture(f"udp://{stream_port}", stream_config)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open UDP stream on port {stream_port}")
        
        print(f"Starting object detection (port {stream_port})...")
        print(f"DEBUG: Using stream port {stream_port} for object detection")
        print("Features:")
        print("- Real-time object detection using YOLO")
        print("- UDP packet transmission with detection data")
        print("- World coordinate mapping (if calibration available)")
        print("- Visual detection overlay")
        print()
        print("Controls:")
        print("- 'q': Quit")
        print("- 's': Save current frame")
        print("- 'i': Print detection info")
        print()
        
        last_print_time = 0.0
        min_print_interval = 1.0  # Print status every second
        frame_count = 0
        
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    print("Failed to read from UDP stream")
                    break
                
                frame_count += 1
                self.frame_count += 1
                
                # Detect objects
                detections = self.detect_objects(frame)
                
                # Send detections via UDP only every N frames
                if detections and (self.frame_count % self.udp_send_interval == 0):
                    self.send_detection_udp(detections)
                
                # Draw detections on frame
                if show_video:
                    frame_with_detections = self.draw_detections(frame, detections)
                    
                    # Draw status info
                    status_text = f"Detections: {len(detections)}"
                    cv2.putText(frame_with_detections, status_text, (10, 30), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                    
                    # Draw calibration status
                    calib_status = "Calibrated" if self.H is not None else "No Calibration"
                    cv2.putText(frame_with_detections, f"Status: {calib_status}", (10, 60), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
                    
                    cv2.imshow("Object Detection", frame_with_detections)
                    key = cv2.waitKey(1) & 0xFF
                    
                    if key == ord('q'):
                        break
                    elif key == ord('s'):
                        # Save current frame
                        filename = f"detection_frame_{int(time.time())}.jpg"
                        cv2.imwrite(filename, frame_with_detections)
                        print(f"Frame saved as {filename}")
                    elif key == ord('i'):
                        # Print detection info
                        print(f"\n=== Detection Info ===")
                        print(f"Total detections: {self.detection_count}")
                        print(f"Current frame detections: {len(detections)}")
                        for i, det in enumerate(detections):
                            print(f"  {i+1}. {det['class_name']} (conf: {det['confidence']:.2f}) at ({det['center']['world_x']:.1f}, {det['center']['world_y']:.1f})")
                        print("=====================\n")
                
                # Print status periodically
                now = time.time()
                if now - last_print_time >= min_print_interval:
                    print(f"Status: {len(detections)} objects detected, {self.detection_count} total detections")
                    last_print_time = now
                    
        finally:
            cap.release()
            if show_video:
                cv2.destroyAllWindows()
            if self.udp_socket:
                self.udp_socket.close()
                print("UDP socket closed")


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Object detection system using YOLO model")
    parser.add_argument("--model", default="best.pt", help="YOLO model path (default: best.pt)")
    parser.add_argument("--calibration", help="Calibration file path (optional)")
    parser.add_argument("--stream-port", type=int, default=5000, help="UDP stream port (default: 5000)")
    parser.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer (default: 5)")
    parser.add_argument("--udp-ip", default="127.0.0.1", help="UDP target IP (default: 127.0.0.1)")
    parser.add_argument("--udp-port", type=int, default=50003, help="UDP target port (default: 50003)")
    parser.add_argument("--confidence", type=float, default=0.9, help="Detection confidence threshold (default: 0.9)")
    parser.add_argument("--device", help="Inference device (e.g., 'cpu', '0', 'cuda')")
    parser.add_argument("--no-show", action="store_true", help="Don't show video window")
    parser.add_argument("--udp-send-interval", type=int, default=30, 
                       help="Send UDP packets every N frames (default: 30)")
    
    args = parser.parse_args()
    
    # Check if model file exists
    if not os.path.exists(args.model):
        print(f"Error: Model file '{args.model}' not found!")
        return 1
    
    # Check if calibration file exists (if provided)
    if args.calibration and not os.path.exists(args.calibration):
        print(f"Warning: Calibration file '{args.calibration}' not found. Running without calibration.")
        args.calibration = None
    
    # Create object detector
    detector = ObjectDetector(
        model_path=args.model,
        calibration_file=args.calibration,
        device=args.device
    )
    
    # Run detection
    try:
        detector.run_detection(
            stream_port=args.stream_port,
            show_video=not args.no_show,
            stream_latency=args.stream_latency,
            udp_ip=args.udp_ip,
            udp_port=args.udp_port,
            confidence=args.confidence,
            udp_send_interval=args.udp_send_interval
        )
    except KeyboardInterrupt:
        print("\nDetection stopped by user")
    except Exception as e:
        print(f"Error: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
