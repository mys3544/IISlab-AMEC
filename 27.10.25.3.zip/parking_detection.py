#!/usr/bin/env python3
"""
Parking Detection System
Detects cars in calibrated parking locations using UDP stream and localization.
"""

import argparse
import json
import math
import os
import socket
import time
from pathlib import Path
from typing import Optional, List, Tuple, Dict
import numpy as np

# Add OpenCV and GStreamer paths
from config import setup_opencv_gstreamer_paths
setup_opencv_gstreamer_paths()
import cv2

# Import from existing modules
from localization import (
    load_calibration, open_video_capture, YoloDetector, 
    ExponentialMovingAverage, perspective_map_pixels_to_world,
    compensate_for_robot_height, send_detection_udp
)
from heading_detector import MultiHeadingDetector


class ParkingZone:
    """Represents a rectangular parking zone with detection area and status"""
    
    def __init__(self, name: str, x1: float, y1: float, x2: float, y2: float, 
                 color: Tuple[int, int, int] = (0, 255, 0)):
        self.name = name
        self.x1 = min(x1, x2)  # Left edge
        self.y1 = min(y1, y2)  # Top edge  
        self.x2 = max(x1, x2)  # Right edge
        self.y2 = max(y1, y2)  # Bottom edge
        self.color = color
        self.is_occupied = False
        self.detection_confidence = 0.0
        self.last_detection_time = 0.0
        
    @property
    def center_x(self) -> float:
        """Get center X coordinate"""
        return (self.x1 + self.x2) / 2
    
    @property
    def center_y(self) -> float:
        """Get center Y coordinate"""
        return (self.y1 + self.y2) / 2
    
    @property
    def width(self) -> float:
        """Get zone width"""
        return self.x2 - self.x1
    
    @property
    def height(self) -> float:
        """Get zone height"""
        return self.y2 - self.y1
        
    def get_corners(self) -> List[Tuple[float, float]]:
        """Get the four corners of the parking zone in world coordinates"""
        return [
            (self.x1, self.y1),  # Top-left
            (self.x2, self.y1),  # Top-right
            (self.x2, self.y2),  # Bottom-right
            (self.x1, self.y2)   # Bottom-left
        ]
    
    def contains_point(self, x: float, y: float) -> bool:
        """Check if a point (world coordinates) is inside this parking zone"""
        return (self.x1 <= x <= self.x2 and self.y1 <= y <= self.y2)
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return {
            "name": self.name,
            "x1": self.x1,
            "y1": self.y1,
            "x2": self.x2,
            "y2": self.y2,
            "color": self.color
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "ParkingZone":
        """Create from dictionary"""
        return cls(
            name=data["name"],
            x1=data["x1"],
            y1=data["y1"],
            x2=data["x2"],
            y2=data["y2"],
            color=tuple(data["color"])
        )


class ParkingDetector:
    """Main parking detection system"""
    
    def __init__(self, calibration_file: str, model_path: str = "model_car_heading.pt", udp_send_interval: int = 30):
        self.calib = load_calibration(Path(calibration_file))
        # Use the underlying YOLO model directly for car detection
        from ultralytics import YOLO
        self.yolo_model = YOLO(model_path)
        self.ema = ExponentialMovingAverage(alpha=0.3)
        self.H = self.calib.homography.astype(float)
        
        # Parking zones
        self.parking_zones: List[ParkingZone] = []
        self.calibration_mode = False
        self.current_zone_name = ""
        self.drawing_zone = False
        self.zone_start_point = None
        self.zone_end_point = None
        
        # Detection settings
        self.car_confidence_threshold = 0.5
        self.occupancy_timeout = 2.0  # Seconds to consider zone unoccupied after last detection
        
        # UDP settings
        self.udp_socket = None
        self.udp_ip = "127.0.0.1"
        self.udp_port = 50002  # Different port from navigation
        
        # Frame counter for UDP sending frequency control
        self.frame_count = 0
        self.udp_send_interval = udp_send_interval  # Send UDP packets every N frames
        self.last_occupancy_status = {}  # Track last sent status for each zone
        
        # Mouse callback for calibration
        self.mouse_pos = None
        self.calibration_callback_set = False
        
    def add_parking_zone(self, name: str, x1: float, y1: float, x2: float, y2: float) -> ParkingZone:
        """Add a new rectangular parking zone"""
        zone = ParkingZone(name, x1, y1, x2, y2)
        self.parking_zones.append(zone)
        return zone
    
    def remove_parking_zone(self, name: str) -> bool:
        """Remove a parking zone by name"""
        for i, zone in enumerate(self.parking_zones):
            if zone.name == name:
                del self.parking_zones[i]
                return True
        return False
    
    def world_to_pixel_camera_compensated(self, world_x: float, world_y: float, object_height_cm: float = 0.0) -> tuple:
        """Convert world coordinates to pixel coordinates with camera compensation"""
        world_point = np.array([[world_x, world_y]], dtype=np.float64)
        pixel_point = cv2.perspectiveTransform(world_point.reshape(-1, 1, 2), np.linalg.inv(self.H))
        pixel_x, pixel_y = pixel_point.reshape(-1, 2)[0]
        
        # Apply camera compensation if camera config is available
        if self.calib.camera is not None and object_height_cm > 0:
            angle_rad = np.radians(self.calib.camera.angle_degrees)
            focal_length_px = max(self.calib.image_width, self.calib.image_height)
            height_offset_px = (object_height_cm / self.calib.camera.height_cm) * focal_length_px * np.sin(angle_rad)
            pixel_y -= height_offset_px
        
        return int(pixel_x), int(pixel_y)
    
    def pixel_to_world(self, pixel_x: int, pixel_y: int) -> Tuple[float, float]:
        """Convert pixel coordinates to world coordinates"""
        pixel_point = np.array([[pixel_x, pixel_y]], dtype=np.float64)
        world_point = perspective_map_pixels_to_world(pixel_point, self.H)
        return world_point[0][0], world_point[0][1]
    
    def mouse_callback(self, event, x, y, flags, param):
        """Mouse callback for parking zone calibration"""
        if event == cv2.EVENT_LBUTTONDOWN:
            if self.calibration_mode and self.current_zone_name:
                # Convert pixel to world coordinates
                world_x, world_y = self.pixel_to_world(x, y)
                
                if not self.drawing_zone:
                    # Start drawing zone
                    self.zone_start_point = (world_x, world_y)
                    self.drawing_zone = True
                    print(f"Started zone '{self.current_zone_name}' at ({world_x:.1f}, {world_y:.1f}) cm")
                    print("Click again to finish the rectangle")
                else:
                    # Finish drawing zone
                    self.zone_end_point = (world_x, world_y)
                    zone = self.add_parking_zone(
                        self.current_zone_name,
                        self.zone_start_point[0], self.zone_start_point[1],
                        self.zone_end_point[0], self.zone_end_point[1]
                    )
                    print(f"Added rectangular zone '{zone.name}' from ({self.zone_start_point[0]:.1f}, {self.zone_start_point[1]:.1f}) to ({self.zone_end_point[0]:.1f}, {self.zone_end_point[1]:.1f}) cm")
                    
                    # Reset for next zone
                    self.current_zone_name = ""
                    self.drawing_zone = False
                    self.zone_start_point = None
                    self.zone_end_point = None
            elif self.calibration_mode and not self.current_zone_name:
                # Show click position for reference
                world_x, world_y = self.pixel_to_world(x, y)
                print(f"Click position: ({world_x:.1f}, {world_y:.1f}) cm")
                print("Press 'n' to add a new zone")
        
        self.mouse_pos = (x, y)
    
    def setup_udp_socket(self):
        """Setup UDP socket for sending parking status"""
        if self.udp_socket is None:
            self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            print(f"UDP socket created for parking status on {self.udp_ip}:{self.udp_port}")
    
    def send_parking_status_udp(self, zone_name: str, is_occupied: bool, confidence: float = 0.0):
        """Send parking zone status via UDP"""
        if self.udp_socket is None:
            self.setup_udp_socket()
        
        payload = {
            "type": "parking_status",
            "zone_name": zone_name,
            "is_occupied": is_occupied,
            "confidence": confidence,
            "timestamp": time.time()
        }
        
        try:
            message = json.dumps(payload).encode('utf-8')
            self.udp_socket.sendto(message, (self.udp_ip, self.udp_port))
            print(f"UDP: {zone_name} = {'OCCUPIED' if is_occupied else 'AVAILABLE'} (conf: {confidence:.2f})")
        except Exception as e:
            print(f"UDP send error: {e}")
    
    def check_and_send_occupancy_changes(self):
        """Check for occupancy changes and send UDP updates"""
        for zone in self.parking_zones:
            zone_key = zone.name
            current_status = zone.is_occupied
            current_confidence = zone.detection_confidence
            
            # Check if status changed
            if zone_key not in self.last_occupancy_status or \
               self.last_occupancy_status[zone_key] != current_status:
                
                # Send UDP update
                self.send_parking_status_udp(zone.name, current_status, current_confidence)
                
                # Update last known status
                self.last_occupancy_status[zone_key] = current_status
    
    def detect_cars_in_zones(self, frame) -> List[Dict]:
        """Detect cars and check which parking zones are occupied"""
        detections = []
        
        # Run YOLO detection
        results = self.yolo_model(frame, verbose=False)
        if not results:
            return detections
        
        result = results[0]
        if result.boxes is None or len(result.boxes) == 0:
            return detections
        
        # Get class names
        class_names = result.names if hasattr(result, 'names') else {}
        
        # Process detections
        for i, box in enumerate(result.boxes):
            confidence = float(box.conf[0])
            if confidence < self.car_confidence_threshold:
                continue
            
            # Get class information
            class_id = int(box.cls[0]) if hasattr(box, 'cls') and box.cls is not None else 0
            class_name = class_names.get(class_id, f"class_{class_id}")
            
            # For now, detect any object as a potential car
            # You can add specific class filtering here if needed
            # if class_name not in ['car', 'vehicle', 'truck', 'bus']:
            #     continue
                
            # Get bounding box coordinates
            x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            
            # Convert to world coordinates
            world_x, world_y = self.pixel_to_world(center_x, center_y)
            
            # Check which parking zones this detection is in
            for zone in self.parking_zones:
                if zone.contains_point(world_x, world_y):
                    zone.is_occupied = True
                    zone.detection_confidence = confidence
                    zone.last_detection_time = time.time()
                    
                    detections.append({
                        'zone': zone.name,
                        'world_x': world_x,
                        'world_y': world_y,
                        'confidence': confidence,
                        'pixel_x': center_x,
                        'pixel_y': center_y,
                        'class_name': class_name
                    })
        
        # Update occupancy status (mark zones as unoccupied if no recent detections)
        current_time = time.time()
        for zone in self.parking_zones:
            if current_time - zone.last_detection_time > self.occupancy_timeout:
                zone.is_occupied = False
                zone.detection_confidence = 0.0
        
        return detections
    
    def draw_parking_zones(self, frame):
        """Draw parking zones on the frame"""
        for zone in self.parking_zones:
            # Convert zone corners to pixel coordinates
            corners_px = []
            for world_x, world_y in zone.get_corners():
                px, py = self.world_to_pixel_camera_compensated(world_x, world_y, 0.0)
                corners_px.append((px, py))
            
            # Draw zone rectangle
            if len(corners_px) == 4:
                pts = np.array(corners_px, np.int32)
                pts = pts.reshape((-1, 1, 2))
                
                # Choose color based on occupancy
                if zone.is_occupied:
                    color = (0, 0, 255)  # Red for occupied
                    thickness = 3
                else:
                    color = (0, 255, 0)  # Green for available
                    thickness = 2
                
                cv2.polylines(frame, [pts], True, color, thickness)
                
                # Draw zone center
                center_px = self.world_to_pixel_camera_compensated(zone.center_x, zone.center_y, 0.0)
                cv2.circle(frame, center_px, 5, color, -1)
                
                # Draw zone name and status
                label_y = center_px[1] - 10
                if label_y < 20:
                    label_y = center_px[1] + 20
                
                status = "OCCUPIED" if zone.is_occupied else "AVAILABLE"
                confidence_text = f" ({zone.detection_confidence:.2f})" if zone.is_occupied else ""
                
                cv2.putText(frame, f"{zone.name}: {status}{confidence_text}", 
                           (center_px[0] - 50, label_y), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        # Draw current zone being created
        if self.drawing_zone and self.zone_start_point and self.mouse_pos:
            # Convert start point to pixels
            start_px = self.world_to_pixel_camera_compensated(
                self.zone_start_point[0], self.zone_start_point[1], 0.0
            )
            
            # Draw rectangle from start point to mouse position
            cv2.rectangle(frame, start_px, self.mouse_pos, (255, 255, 0), 2)
            
            # Draw start point
            cv2.circle(frame, start_px, 8, (255, 255, 0), -1)
            
            # Draw instruction
            cv2.putText(frame, f"Drawing zone '{self.current_zone_name}' - Click to finish", 
                       (10, frame.shape[0] - 20), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
    
    def draw_detections(self, frame, detections: List[Dict]):
        """Draw car detections on the frame"""
        for detection in detections:
            px = int(detection['pixel_x'])
            py = int(detection['pixel_y'])
            
            # Draw detection circle
            cv2.circle(frame, (px, py), 8, (255, 0, 0), -1)
            cv2.circle(frame, (px, py), 12, (255, 255, 255), 2)
            
            # Draw detection info
            cv2.putText(frame, f"{detection['class_name']} in {detection['zone']}", 
                       (px + 15, py - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
            cv2.putText(frame, f"Conf: {detection['confidence']:.2f}", 
                       (px + 15, py + 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)
    
    def save_parking_zones(self, filename: str):
        """Save parking zones to JSON file"""
        try:
            # Ensure directory exists (only if filename has a directory path)
            dir_path = os.path.dirname(filename)
            if dir_path:  # Only create directory if there's a path component
                os.makedirs(dir_path, exist_ok=True)
            
            data = {
                "parking_zones": [zone.to_dict() for zone in self.parking_zones],
                "settings": {
                    "car_confidence_threshold": self.car_confidence_threshold,
                    "occupancy_timeout": self.occupancy_timeout,
                    "zone_width": self.zone_width,
                    "zone_height": self.zone_height
                }
            }
            
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)
            print(f"Parking zones saved to {filename}")
        except Exception as e:
            print(f"Error saving parking zones: {e}")
    
    def load_parking_zones(self, filename: str):
        """Load parking zones from JSON file"""
        if not os.path.exists(filename):
            print(f"Parking zones file {filename} not found")
            return
        
        with open(filename, 'r') as f:
            data = json.load(f)
        
        self.parking_zones = [ParkingZone.from_dict(zone_data) for zone_data in data["parking_zones"]]
        
        if "settings" in data:
            settings = data["settings"]
            self.car_confidence_threshold = settings.get("car_confidence_threshold", 0.5)
            self.occupancy_timeout = settings.get("occupancy_timeout", 2.0)
            self.zone_width = settings.get("zone_width", 50.0)
            self.zone_height = settings.get("zone_height", 30.0)
        
        print(f"Loaded {len(self.parking_zones)} parking zones from {filename}")
    
    def run_detection(self, stream_port: int = 5000, show_video: bool = True, 
                     stream_latency: int = 5, zones_file: str = "parking_zones.json",
                     udp_ip: str = "127.0.0.1", udp_port: int = 50002):
        """Run parking detection with UDP stream"""
        
        # Load existing parking zones if available
        self.load_parking_zones(zones_file)
        
        # Setup UDP settings
        self.udp_ip = udp_ip
        self.udp_port = udp_port
        
        # Setup stream configuration
        stream_config = {
            "use_gstreamer": True,
            "port": stream_port,
            "latency": stream_latency
        }
        
        # Open UDP video stream
        cap = open_video_capture(f"udp://{stream_port}", stream_config)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open UDP stream on port {stream_port}")
        
        print(f"Starting parking detection (port {stream_port})...")
        print("Features:")
        print("- Real-time car detection in rectangular parking zones")
        print("- Visual indicators for zone occupancy")
        print("- Calibratable rectangular parking zones")
        print()
        print("Controls:")
        print("- 'c': Enter/exit calibration mode")
        print("- 'n': Add new rectangular zone (auto-named, click twice)")
        print("- 'e': Edit last zone name")
        print("- 's': Save parking zones")
        print("- 'l': Load parking zones")
        print("- 'r': Reset all zones")
        print("- 'q': Quit")
        print()
        
        if not self.calibration_callback_set:
            cv2.namedWindow("Parking Detection")
            cv2.setMouseCallback("Parking Detection", self.mouse_callback)
            self.calibration_callback_set = True
        
        last_print_time = 0.0
        min_print_interval = 1.0  # Print status every second
        
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    print("Failed to read from UDP stream")
                    break
                
                # Increment frame counter
                self.frame_count += 1
                
                # Detect cars in parking zones
                detections = self.detect_cars_in_zones(frame)
                
                # Check for occupancy changes and send UDP updates only every 30 frames
                if self.frame_count % self.udp_send_interval == 0:
                    self.check_and_send_occupancy_changes()
                
                # Draw visual elements
                self.draw_parking_zones(frame)
                self.draw_detections(frame, detections)
                
                # Print status periodically
                now = time.time()
                if now - last_print_time >= min_print_interval:
                    occupied_zones = [zone for zone in self.parking_zones if zone.is_occupied]
                    print(f"Status: {len(occupied_zones)}/{len(self.parking_zones)} zones occupied")
                    for zone in occupied_zones:
                        print(f"  - {zone.name}: {zone.detection_confidence:.2f} confidence")
                    last_print_time = now
                
                if show_video:
                    # Draw calibration mode indicator
                    if self.calibration_mode:
                        if self.current_zone_name:
                            if self.drawing_zone:
                                cv2.putText(frame, f"CALIBRATION MODE - Drawing zone '{self.current_zone_name}' - Click to finish", 
                                           (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
                            else:
                                cv2.putText(frame, f"CALIBRATION MODE - Click to start zone '{self.current_zone_name}'", 
                                           (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                        else:
                            cv2.putText(frame, "CALIBRATION MODE - Press 'n' to add new zone", 
                                       (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                    
                    # Draw mouse position
                    if self.mouse_pos:
                        cv2.circle(frame, self.mouse_pos, 5, (255, 255, 0), -1)
                    
                    cv2.imshow("Parking Detection", frame)
                    key = cv2.waitKey(1) & 0xFF
                    
                    if key == ord('q'):
                        break
                    elif key == ord('c'):
                        self.calibration_mode = not self.calibration_mode
                        if not self.calibration_mode:
                            # Reset drawing state when exiting calibration mode
                            self.current_zone_name = ""
                            self.drawing_zone = False
                            self.zone_start_point = None
                            self.zone_end_point = None
                        print(f"Calibration mode: {'ON' if self.calibration_mode else 'OFF'}")
                    elif key == ord('s'):
                        self.save_parking_zones(zones_file)
                    elif key == ord('l'):
                        self.load_parking_zones(zones_file)
                    elif key == ord('r'):
                        self.parking_zones.clear()
                        self.current_zone_name = ""
                        self.drawing_zone = False
                        self.zone_start_point = None
                        self.zone_end_point = None
                        print("All parking zones cleared")
                    elif key == ord('n'):
                        if self.calibration_mode:
                            # Generate automatic zone name
                            zone_count = len(self.parking_zones) + 1
                            self.current_zone_name = f"Zone_{zone_count}"
                            self.drawing_zone = False
                            self.zone_start_point = None
                            self.zone_end_point = None
                            print(f"Click to start drawing zone '{self.current_zone_name}'")
                        else:
                            print("Enter calibration mode first (press 'c')")
                    elif key == ord('e'):
                        if self.parking_zones:
                            # Cycle through common zone names
                            last_zone = self.parking_zones[-1]
                            common_names = ["Parking_1", "Parking_2", "Parking_3", "Zone_1", "Zone_2", "Zone_3", 
                                          "Spot_A", "Spot_B", "Spot_C", "Area_1", "Area_2", "Area_3"]
                            
                            # Find current name in list or add it
                            if last_zone.name in common_names:
                                current_index = common_names.index(last_zone.name)
                                next_index = (current_index + 1) % len(common_names)
                            else:
                                next_index = 0
                            
                            last_zone.name = common_names[next_index]
                            print(f"Zone renamed to '{last_zone.name}' (press 'e' to cycle through names)")
                        else:
                            print("No zones to edit")
                
        finally:
            cap.release()
            if show_video:
                cv2.destroyAllWindows()
            if self.udp_socket:
                self.udp_socket.close()
                print("UDP socket closed")


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Parking detection system with UDP stream")
    parser.add_argument("--calibration", required=True, help="Calibration file path")
    parser.add_argument("--model", default="model_car_heading.pt", help="YOLO model path")
    parser.add_argument("--stream-port", type=int, default=5000, help="UDP stream port")
    parser.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer")
    parser.add_argument("--zones-file", default="parking_zones.json", help="Parking zones file")
    parser.add_argument("--confidence", type=float, default=0.9, help="Car detection confidence threshold")
    parser.add_argument("--udp-ip", default="127.0.0.1", help="UDP target IP for parking status")
    parser.add_argument("--udp-port", type=int, default=50002, help="UDP target port for parking status")
    parser.add_argument("--no-show", action="store_true", help="Don't show video window")
    parser.add_argument("--udp-send-interval", type=int, default=30,
                       help="Send UDP packets every N frames (default: 30)")
    
    args = parser.parse_args()
    
    # Create parking detector
    detector = ParkingDetector(args.calibration, args.model, args.udp_send_interval)
    detector.car_confidence_threshold = args.confidence
    
    # Run detection
    detector.run_detection(
        stream_port=args.stream_port,
        show_video=not args.no_show,
        stream_latency=args.stream_latency,
        zones_file=args.zones_file,
        udp_ip=args.udp_ip,
        udp_port=args.udp_port
    )


if __name__ == "__main__":
    main()
