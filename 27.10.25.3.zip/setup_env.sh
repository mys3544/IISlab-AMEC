#!/bin/bash
# Setup script for AMEC virtual environment (Linux/Mac)

echo "============================================================"
echo "Setting up AMEC Python Virtual Environment"
echo "============================================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 is not installed"
    echo "Please install Python 3.8 or higher"
    exit 1
fi

echo "[1/4] Creating virtual environment..."
if [ -d "venv" ]; then
    echo "Virtual environment already exists"
    echo ""
else
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to create virtual environment"
        exit 1
    fi
    echo "[OK] Virtual environment created"
fi

echo "[2/4] Activating virtual environment..."
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo "[ERROR] Failed to activate virtual environment"
    exit 1
fi

echo "[3/4] Upgrading pip..."
python -m pip install --upgrade pip

echo "[4/4] Installing dependencies..."
pip install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "[ERROR] Failed to install dependencies"
    echo "Please check requirements.txt and try again"
    exit 1
fi

echo ""
echo "============================================================"
echo "[OK] Setup complete!"
echo "============================================================"
echo ""
echo "Virtual environment created at: venv"
echo ""
echo "To activate the virtual environment, run:"
echo "  source venv/bin/activate"
echo ""
echo "Then run your program with:"
echo "  python start.py [options]"
echo ""
echo "To deactivate:"
echo "  deactivate"
echo ""
