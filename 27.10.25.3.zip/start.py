#!/usr/bin/env python3
"""
Run AMEC applications simultaneously including object detection.
This script starts the stream multiplier and then runs navigation, parking detection, and object detection.
"""

import subprocess
import sys
import os
import time
import argparse
from pathlib import Path

def run_command(cmd, name, log_file=None):
    """Run a command in a separate process and log output"""
    print(f"[INFO] Starting {name}...")
    print(f"Command: {' '.join(cmd)}")
    
    if log_file:
        with open(log_file, 'w') as f:
            process = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT, text=True)
    else:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    
    return process

def main():
    parser = argparse.ArgumentParser(description="Run AMEC applications simultaneously with object detection")
    parser.add_argument("--source-port", type=int, default=5000,
                       help="Source UDP stream port (default: 5000)")
    parser.add_argument("--object-source-port", type=int, default=6000,
                       help="Object detection source UDP stream port (default: 6000) - separate from navigation stream")
    parser.add_argument("--nav-port", type=int, default=5001,
                       help="Navigation stream port (default: 5001)")
    parser.add_argument("--parking-port", type=int, default=5002,
                       help="Parking detection stream port (default: 5002)")
    parser.add_argument("--object-port", type=int, default=5003,
                       help="Object detection stream port (default: 5003)")
    parser.add_argument("--latency", type=int, default=5,
                       help="Stream latency in milliseconds (default: 5)")
    parser.add_argument("--calibration", default="enhanced_calibration.json",
                       help="Calibration file (default: enhanced_calibration.json)")
    parser.add_argument("--waypoints", default="logical_waypoints.json",
                       help="Waypoints file (default: logical_waypoints.json)")
    parser.add_argument("--model", default="model_car_heading.pt",
                       help="YOLO model file for navigation/parking (default: model_car_heading.pt)")
    parser.add_argument("--object-model", default="best.pt",
                       help="YOLO model file for object detection (default: best.pt)")
    parser.add_argument("--zones-file", default="parking_zones.json",
                       help="Parking zones file (default: parking_zones.json)")
    parser.add_argument("--confidence", type=float, default=0.9,
                       help="Detection confidence threshold (default: 0.9)")
    parser.add_argument("--nav-udp-ip", default="127.0.0.1",
                       help="Navigation UDP IP address (default: 127.0.0.1)")
    parser.add_argument("--nav-udp-port", type=int, default=50001,
                       help="Navigation UDP port (default: 50001)")
    parser.add_argument("--parking-udp-ip", default="127.0.0.1",
                       help="Parking detection UDP IP address (default: 127.0.0.1)")
    parser.add_argument("--parking-udp-port", type=int, default=50002,
                       help="Parking detection UDP port (default: 50002)")
    parser.add_argument("--object-udp-ip", default="127.0.0.1",
                       help="Object detection UDP IP address (default: 127.0.0.1)")
    parser.add_argument("--object-udp-port", type=int, default=50003,
                       help="Object detection UDP port (default: 50003)")
    parser.add_argument("--log-dir", default="logs",
                       help="Directory for log files (default: logs)")
    parser.add_argument("--target-waypoint", default="Parking_Left",
                       help="Target waypoint for navigation (default: Parking_Left)")
    parser.add_argument("--bitrate", type=int, default=4000,
                       help="Video bitrate in kbps (default: 4000)")
    parser.add_argument("--no-object-detection", action="store_true",
                       help="Skip object detection (run only navigation and parking)")
    parser.add_argument("--udp-send-interval", type=int, default=1,
                       help="Send UDP packets every N frames (default: 30)")
    parser.add_argument("--fps", type=int, default=10,
                       help="Stream frame rate in FPS (default: 10)")
    parser.add_argument("--continuous", action="store_true",
                       help="Enable continuous navigation mode for demo - robot will cycle through waypoints without stopping")
    parser.add_argument("--use-yolo-heading", action="store_true", dest="use_yolo_heading", default=False,
                       help="Use YOLO-based heading detection instead of movement-based (default: movement-based)")
    
    args = parser.parse_args()
    
    print("=== AMEC Simultaneous Execution with Object Detection ===")
    print("This runs multiple AMEC applications simultaneously.")
    print("Navigation and parking use stream multiplier, object detection uses separate stream.")
    print()
    print("Configuration:")
    print(f"  Source stream port: {args.source_port}")
    print(f"  Object detection source port: {args.object_source_port}")
    print(f"  Navigation stream port: {args.nav_port}")
    print(f"  Parking detection stream port: {args.parking_port}")
    print(f"  Object detection stream port: {args.object_port}")
    print(f"  Stream latency: {args.latency}ms")
    print(f"  Calibration file: {args.calibration}")
    print(f"  Waypoints file: {args.waypoints}")
    print(f"  Navigation model: {args.model}")
    print(f"  Object detection model: {args.object_model}")
    print(f"  Parking zones file: {args.zones_file}")
    print(f"  Detection confidence: {args.confidence}")
    print(f"  Navigation UDP: {args.nav_udp_ip}:{args.nav_udp_port}")
    print(f"  Parking UDP: {args.parking_udp_ip}:{args.parking_udp_port}")
    print(f"  Object detection UDP: {args.object_udp_ip}:{args.object_udp_port}")
    print(f"  Video resolution: Original (preserved from source)")
    print(f"  Video bitrate: {args.bitrate} kbps")
    print(f"  Frame rate: {args.fps} FPS (synchronized across all systems)")
    print(f"  Log directory: {args.log_dir}")
    if args.continuous:
        print(f"  Navigation mode: CONTINUOUS (demo mode - cycles through waypoints)")
    else:
        print(f"  Navigation mode: NORMAL (stops at target waypoint)")
    if not args.use_yolo_heading:
        print(f"  Heading detection: MOVEMENT-BASED (North/South/East/West from robot movement)")
    else:
        print(f"  Heading detection: YOLO-BASED (model-based heading detection)")
    print()
    
    # Check if required files exist
    required_files = [args.calibration, args.waypoints, args.model]
    if not args.no_object_detection:
        required_files.append(args.object_model)
    
    for file_path in required_files:
        if not os.path.exists(file_path):
            print(f"[ERROR] Required file not found: {file_path}")
            return 1
    
    print("[OK] All required files found")
    print()
    
    # Create log directory
    log_dir = Path(args.log_dir)
    log_dir.mkdir(exist_ok=True)
    
    # Start processes
    processes = {}
    
    try:
        # 1. Start stream multiplier
        print("1. Starting Stream Multiplier...")
        output_ports = [str(args.nav_port), str(args.parking_port), str(args.object_port)]
        print(f"DEBUG: Stream multiplier will output to ports: {output_ports}")
        # Object detection will now get its stream from the multiplier for FPS synchronization
        
        multiplier_cmd = [
            "python", "stream_multiplier.py",
            "--source-port", str(args.source_port),
            "--output-ports"] + output_ports + [
            "--latency", str(args.latency),
            "--bitrate", str(args.bitrate),
            "--fps", str(args.fps)
        ]
        processes['multiplier'] = run_command(
            multiplier_cmd, 
            "Stream Multiplier", 
            log_dir / "stream_multiplier.log"
        )
        
        # Wait a bit for stream multiplier to start
        print("[INFO] Waiting for stream multiplier to initialize...")
        time.sleep(3)
        
        # 2. Start navigation
        print("2. Starting Waypoint Navigation...")
        nav_cmd = [
            "python", "system_navigation.py",
            "--stream-port", str(args.nav_port),
            "--calibration", args.calibration,
            "--waypoints", args.waypoints,
            "--model", args.model,
            "--target-waypoint", args.target_waypoint,
            "--udp-ip", args.nav_udp_ip,
            "--udp-port", str(args.nav_udp_port),
            "--udp-send-interval", str(args.udp_send_interval)
        ]
        
        # Add continuous flag if enabled
        if args.continuous:
            nav_cmd.append("--continuous")
        
        # Add movement heading flag if enabled (default: enabled)
        if not args.use_yolo_heading:
            nav_cmd.append("--use-movement-heading")
        processes['navigation'] = run_command(
            nav_cmd,
            "Waypoint Navigation",
            log_dir / "navigation.log"
        )
        
        # Wait a bit for navigation to start
        time.sleep(2)
        
        # 3. Start parking detection
        print("3. Starting Parking Detection...")
        parking_cmd = [
            "python", "system_parking.py",
            "--stream-port", str(args.parking_port),
            "--calibration", args.calibration,
            "--model", args.model,
            "--zones-file", args.zones_file,
            "--confidence", str(args.confidence),
            "--udp-ip", args.parking_udp_ip,
            "--udp-port", str(args.parking_udp_port),
            "--udp-send-interval", str(args.udp_send_interval)
        ]
        processes['parking'] = run_command(
            parking_cmd,
            "Parking Detection",
            log_dir / "parking.log"
        )
        
        # Wait a bit for parking detection to start
        time.sleep(2)
        
        # 4. Start object detection (if enabled)
        if not args.no_object_detection:
            print("4. Starting Object Detection...")
            print(f"DEBUG: Object detection will use separate stream port {args.object_source_port}")
            object_cmd = [
                "python", "object_detection.py",
                "--stream-port", str(args.object_source_port),
                "--calibration", args.calibration,
                "--model", args.object_model,
                "--confidence", str(args.confidence),
                "--udp-ip", args.object_udp_ip,
                "--udp-port", str(args.object_udp_port),
                "--udp-send-interval", str(args.udp_send_interval)
            ]
            processes['object_detection'] = run_command(
                object_cmd,
                "Object Detection",
                log_dir / "object_detection.log"
            )
        
        print()
        print("[OK] All applications started successfully!")
        print()
        print("Applications running:")
        print(f"  [STREAM] Stream Multiplier (PID: {processes['multiplier'].pid})")
        print(f"  [NAV] Waypoint Navigation (PID: {processes['navigation'].pid})")
        print(f"  [PARK] Parking Detection (PID: {processes['parking'].pid})")
        if not args.no_object_detection:
            print(f"  [OBJ] Object Detection (PID: {processes['object_detection'].pid})")
        print()
        print("Log files:")
        print(f"  [LOG] Stream Multiplier: {log_dir / 'stream_multiplier.log'}")
        print(f"  [LOG] Navigation: {log_dir / 'navigation.log'}")
        print(f"  [LOG] Parking Detection: {log_dir / 'parking.log'}")
        if not args.no_object_detection:
            print(f"  [LOG] Object Detection: {log_dir / 'object_detection.log'}")
        print()
        print("UDP Endpoints:")
        print(f"  [UDP] Navigation: {args.nav_udp_ip}:{args.nav_udp_port}")
        print(f"  [UDP] Parking: {args.parking_udp_ip}:{args.parking_udp_port}")
        if not args.no_object_detection:
            print(f"  [UDP] Object Detection: {args.object_udp_ip}:{args.object_udp_port}")
        print()
        print("Press Ctrl+C to stop all applications...")
        print()
        
        # Monitor processes
        while True:
            time.sleep(1)
            
            # Check if any process has died
            for name, process in processes.items():
                if process.poll() is not None:
                    print(f"[WARNING] {name} has stopped unexpectedly (exit code: {process.returncode})")
                    print("Stopping all applications...")
                    raise KeyboardInterrupt()
    
    except KeyboardInterrupt:
        print("\n[INFO] Stopping all applications...")
        
        # Stop all processes
        for name, process in processes.items():
            if process.poll() is None:  # Still running
                print(f"Stopping {name}...")
                process.terminate()
                try:
                    process.wait(timeout=5)
                    print(f"[OK] {name} stopped")
                except subprocess.TimeoutExpired:
                    print(f"[WARNING] {name} didn't stop gracefully, forcing...")
                    process.kill()
                    process.wait()
                    print(f"[OK] {name} force stopped")
        
        print("[OK] All applications stopped")
    
    except Exception as e:
        print(f"[ERROR] Error: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
