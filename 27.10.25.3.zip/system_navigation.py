#!/usr/bin/env python3
"""
Simple script to run waypoint-based navigation.
This uses your calibrated logical waypoints for path planning - no numbered intermediate points!
"""

import subprocess
import sys
import os
import argparse

def main():
    parser = argparse.ArgumentParser(description="Run waypoint-based navigation")
    parser.add_argument("--stream-port", type=int, default=5001,
                       help="UDP stream port to use (default: 5001)")
    parser.add_argument("--calibration", default="enhanced_calibration.json",
                       help="Calibration file (default: enhanced_calibration.json)")
    parser.add_argument("--waypoints", default="logical_waypoints.json",
                       help="Waypoints file (default: logical_waypoints.json)")
    parser.add_argument("--model", default="model_car_heading.pt",
                       help="YOLO model file (default: model_car_heading.pt)")
    parser.add_argument("--target-waypoint", default=None,
                       help="Target waypoint name or number (default: prompt user)")
    parser.add_argument("--udp-ip", default="127.0.0.1", help="UDP target IP for robot commands")
    parser.add_argument("--udp-port", type=int, default=50001, help="UDP target port for robot commands")
    parser.add_argument("--udp-send-interval", type=int, default=30,
                       help="Send UDP packets every N frames (default: 30)")
    parser.add_argument("--continuous", action="store_true",
                       help="Enable continuous navigation mode for demo - robot will cycle through waypoints without stopping")
    parser.add_argument("--use-movement-heading", action="store_true",
                       help="Use movement-based heading detection instead of YOLO-based heading detection")
    
    args = parser.parse_args()
    
    # Configuration
    STREAM_PORT = args.stream_port
    CALIBRATION_FILE = args.calibration
    WAYPOINTS_FILE = args.waypoints
    MODEL_PATH = args.model
    TARGET_WAYPOINT = args.target_waypoint
    UDP_IP = args.udp_ip
    UDP_PORT = args.udp_port
    UDP_SEND_INTERVAL = args.udp_send_interval
    CONTINUOUS = args.continuous
    USE_MOVEMENT_HEADING = args.use_movement_heading
    
    print("=== Waypoint-Based Navigation (No Turn-on-Spot) ===")
    print("This uses your calibrated logical waypoints for path planning.")
    print("Robot will go to nearest waypoint in its heading direction first.")
    print("No numbered intermediate points - only your actual waypoints!")
    if CONTINUOUS:
        print("CONTINUOUS MODE ENABLED: Robot will cycle through all waypoints for demo presentation")
    if USE_MOVEMENT_HEADING:
        print("MOVEMENT-BASED HEADING ENABLED: Robot heading determined by movement direction (North/South/East/West)")
    else:
        print("YOLO-BASED HEADING ENABLED: Robot heading determined by YOLO model detection")
    print()
    print("Available waypoints:")
    print()
    print("Outer Corners (4):")
    print("  1. Outer_TopLeft")
    print("  2. Outer_TopRight") 
    print("  3. Outer_BottomRight")
    print("  4. Outer_BottomLeft")
    print()
    print("Intersections (5):")
    print("  5. Intersection_Top")
    print("  6. Intersection_Center")
    print("  7. Intersection_Bottom")
    print("  8. Intersection_Left")
    print("  9. Intersection_Right")
    print()
    print("Parking (1):")
    print(" 10. Parking_Left")
    print()
    
    # Check if files exist
    if not os.path.exists(CALIBRATION_FILE):
        print(f"[ERROR] Calibration file '{CALIBRATION_FILE}' not found!")
        print("Please run enhanced calibration first:")
        print("python run_enhanced_calibration.py")
        return
    
    if not os.path.exists(WAYPOINTS_FILE):
        print(f"[ERROR] Waypoints file '{WAYPOINTS_FILE}' not found!")
        print("Please create logical waypoints first:")
        print("python update_waypoints.py")
        return
    
    print(f"[OK] Found calibration file: {CALIBRATION_FILE}")
    print(f"[OK] Found waypoints file: {WAYPOINTS_FILE}")
    print()
    
    # Get target waypoint from user or command line
    waypoint_names = [
        "Outer_TopLeft", "Outer_TopRight", "Outer_BottomRight", "Outer_BottomLeft",
        "Intersection_Top", "Intersection_Center", "Intersection_Bottom", 
        "Intersection_Left", "Intersection_Right", "Parking_Left"
    ]
    
    if TARGET_WAYPOINT is not None:
        # Use command line argument
        target_choice = TARGET_WAYPOINT
    else:
        # Prompt user
        print("Choose target waypoint:")
        target_choice = input("Enter waypoint number (1-10) or name: ").strip()
    
    # Convert number to waypoint name
    if target_choice.isdigit():
        waypoint_num = int(target_choice)
        if 1 <= waypoint_num <= 10:
            target_waypoint = waypoint_names[waypoint_num - 1]
        else:
            print("[ERROR] Invalid waypoint number!")
            return
    else:
        target_waypoint = target_choice
    
    print(f"Target waypoint: {target_waypoint}")
    print()
    print("Starting waypoint-based navigation...")
    print("You will see:")
    print("- All your calibrated waypoints (colored circles with names)")
    print("- Path lines connecting waypoints (magenta)")
    print("- Robot position (red circle)")
    print("- Target waypoint (green circle with crosshairs)")
    print("- NO numbered intermediate points!")
    print()
    print("Press 'q' to quit, 'r' to replan path")
    print()
    
    # Run waypoint-based navigation
    cmd = [
        "python", "navigation.py",
        "--calibration", CALIBRATION_FILE,
        "--waypoints", WAYPOINTS_FILE,
        "--target-waypoint", target_waypoint,
        "--stream-port", str(STREAM_PORT),
        "--stream-latency", "5",
        "--model", MODEL_PATH,
        "--udp-ip", UDP_IP,
        "--udp-port", str(UDP_PORT),
        "--udp-send-interval", str(UDP_SEND_INTERVAL),
        "--heading-tolerance", "22.5"  # 22.5° tolerance for waypoint selection
    ]
    
    # Add continuous flag if enabled
    if CONTINUOUS:
        cmd.append("--continuous")
    
    # Add movement heading flag if enabled
    if USE_MOVEMENT_HEADING:
        cmd.append("--use-movement-heading")
    
    print(f"Running: {' '.join(cmd)}")
    print()
    
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print("[ERROR] Navigation failed!")
        return
    
    print("[OK] Navigation completed!")

if __name__ == "__main__":
    main()
