#!/usr/bin/env python3
"""
Run AMEC applications with custom object detection port and separate UDP destinations.
This script allows you to:
- Use a custom input port for object detection (different from nav/parking)
- Send navigation+parking data to one IP/port
- Send object detection data to a different IP/port
"""

import subprocess
import sys
import os
import time
import argparse
from pathlib import Path

def run_command(cmd, name, log_file=None):
    """Run a command in a separate process and log output"""
    print(f"[INFO] Starting {name}...")
    print(f"Command: {' '.join(cmd)}")
    
    if log_file:
        with open(log_file, 'w') as f:
            process = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT, text=True)
    else:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    
    return process

def main():
    parser = argparse.ArgumentParser(description="Run AMEC applications with custom object detection configuration")
    
    # Stream configuration
    parser.add_argument("--source-port", type=int, default=5000,
                       help="Source UDP stream port for nav/parking (default: 5000)")
    parser.add_argument("--object-source-port", type=int, default=5004,
                       help="Custom source UDP stream port for object detection (default: 5004)")
    parser.add_argument("--nav-port", type=int, default=5001,
                       help="Navigation stream port (default: 5001)")
    parser.add_argument("--parking-port", type=int, default=5002,
                       help="Parking detection stream port (default: 5002)")
    parser.add_argument("--object-port", type=int, default=5003,
                       help="Object detection stream port (default: 5003)")
    
    # UDP destination configuration
    parser.add_argument("--nav-udp-ip", default="127.0.0.1",
                       help="Navigation UDP destination IP (default: 127.0.0.1)")
    parser.add_argument("--nav-udp-port", type=int, default=50001,
                       help="Navigation UDP destination port (default: 50001)")
    parser.add_argument("--parking-udp-ip", default="127.0.0.1",
                       help="Parking UDP destination IP (default: 127.0.0.1)")
    parser.add_argument("--parking-udp-port", type=int, default=50002,
                       help="Parking UDP destination port (default: 50002)")
    parser.add_argument("--object-udp-ip", default="192.168.1.100",
                       help="Object detection UDP destination IP (default: 192.168.1.100)")
    parser.add_argument("--object-udp-port", type=int, default=50003,
                       help="Object detection UDP destination port (default: 50003)")
    
    # General configuration
    parser.add_argument("--latency", type=int, default=5,
                       help="Stream latency in milliseconds (default: 5)")
    parser.add_argument("--calibration", default="enhanced_calibration.json",
                       help="Calibration file (default: enhanced_calibration.json)")
    parser.add_argument("--waypoints", default="logical_waypoints.json",
                       help="Waypoints file (default: logical_waypoints.json)")
    parser.add_argument("--model", default="model_car_heading.pt",
                       help="YOLO model file for navigation/parking (default: model_car_heading.pt)")
    parser.add_argument("--object-model", default="best.pt",
                       help="YOLO model file for object detection (default: best.pt)")
    parser.add_argument("--zones-file", default="parking_zones.json",
                       help="Parking zones file (default: parking_zones.json)")
    parser.add_argument("--confidence", type=float, default=0.9,
                       help="Detection confidence threshold (default: 0.9)")
    parser.add_argument("--log-dir", default="logs",
                       help="Directory for log files (default: logs)")
    parser.add_argument("--target-waypoint", default="Parking_Left",
                       help="Target waypoint for navigation (default: Parking_Left)")
    parser.add_argument("--bitrate", type=int, default=4000,
                       help="Video bitrate in kbps (default: 4000)")
    parser.add_argument("--no-object-detection", action="store_true",
                       help="Skip object detection (run only navigation and parking)")
    parser.add_argument("--no-nav-parking", action="store_true",
                       help="Skip navigation and parking (run only object detection)")
    
    args = parser.parse_args()
    
    print("=== AMEC Custom Object Detection Configuration ===")
    print("This runs AMEC applications with custom port and UDP destination configuration.")
    print()
    print("Stream Configuration:")
    print(f"  Nav/Parking source port: {args.source_port}")
    print(f"  Object detection source port: {args.object_source_port}")
    print(f"  Navigation stream port: {args.nav_port}")
    print(f"  Parking detection stream port: {args.parking_port}")
    print(f"  Object detection stream port: {args.object_port}")
    print()
    print("UDP Destinations:")
    print(f"  Navigation: {args.nav_udp_ip}:{args.nav_udp_port}")
    print(f"  Parking: {args.parking_udp_ip}:{args.parking_udp_port}")
    if not args.no_object_detection:
        print(f"  Object Detection: {args.object_udp_ip}:{args.object_udp_port}")
    print()
    print("General Configuration:")
    print(f"  Stream latency: {args.latency}ms")
    print(f"  Calibration file: {args.calibration}")
    print(f"  Waypoints file: {args.waypoints}")
    print(f"  Navigation model: {args.model}")
    if not args.no_object_detection:
        print(f"  Object detection model: {args.object_model}")
    print(f"  Parking zones file: {args.zones_file}")
    print(f"  Detection confidence: {args.confidence}")
    print(f"  Video bitrate: {args.bitrate} kbps")
    print(f"  Log directory: {args.log_dir}")
    print()
    
    # Check if required files exist
    required_files = []
    if not args.no_nav_parking:
        required_files.extend([args.calibration, args.waypoints, args.model])
    if not args.no_object_detection:
        required_files.append(args.object_model)
    
    for file_path in required_files:
        if not os.path.exists(file_path):
            print(f"[ERROR] Required file not found: {file_path}")
            return 1
    
    print("[OK] All required files found")
    print()
    
    # Create log directory
    log_dir = Path(args.log_dir)
    log_dir.mkdir(exist_ok=True)
    
    # Start processes
    processes = {}
    
    try:
        # 1. Start stream multiplier for nav/parking (if needed)
        if not args.no_nav_parking:
            print("1. Starting Stream Multiplier for Nav/Parking...")
            nav_parking_ports = [str(args.nav_port), str(args.parking_port)]
            
            multiplier_cmd = [
                "python", "stream_multiplier.py",
                "--source-port", str(args.source_port),
                "--output-ports"] + nav_parking_ports + [
                "--latency", str(args.latency),
                "--bitrate", str(args.bitrate)
            ]
            processes['nav_parking_multiplier'] = run_command(
                multiplier_cmd, 
                "Nav/Parking Stream Multiplier", 
                log_dir / "nav_parking_multiplier.log"
            )
            
            # Wait a bit for stream multiplier to start
            print("[INFO] Waiting for nav/parking stream multiplier to initialize...")
            time.sleep(3)
        
        # 2. Start object detection stream multiplier (if needed)
        if not args.no_object_detection:
            print("2. Starting Stream Multiplier for Object Detection...")
            object_multiplier_cmd = [
                "python", "stream_multiplier.py",
                "--source-port", str(args.object_source_port),
                "--output-ports", str(args.object_port),
                "--latency", str(args.latency),
                "--bitrate", str(args.bitrate)
            ]
            processes['object_multiplier'] = run_command(
                object_multiplier_cmd, 
                "Object Detection Stream Multiplier", 
                log_dir / "object_multiplier.log"
            )
            
            # Wait a bit for object stream multiplier to start
            print("[INFO] Waiting for object detection stream multiplier to initialize...")
            time.sleep(3)
        
        # 3. Start navigation (if needed)
        if not args.no_nav_parking:
            print("3. Starting Waypoint Navigation...")
            nav_cmd = [
                "python", "system_navigation.py",
                "--stream-port", str(args.nav_port),
                "--calibration", args.calibration,
                "--waypoints", args.waypoints,
                "--model", args.model,
                "--target-waypoint", args.target_waypoint,
                "--udp-ip", args.nav_udp_ip,
                "--udp-port", str(args.nav_udp_port)
            ]
            processes['navigation'] = run_command(
                nav_cmd,
                "Waypoint Navigation",
                log_dir / "navigation.log"
            )
            
            # Wait a bit for navigation to start
            time.sleep(2)
        
        # 4. Start parking detection (if needed)
        if not args.no_nav_parking:
            print("4. Starting Parking Detection...")
            parking_cmd = [
                "python", "system_parking.py",
                "--stream-port", str(args.parking_port),
                "--calibration", args.calibration,
                "--model", args.model,
                "--zones-file", args.zones_file,
                "--confidence", str(args.confidence),
                "--udp-ip", args.parking_udp_ip,
                "--udp-port", str(args.parking_udp_port)
            ]
            processes['parking'] = run_command(
                parking_cmd,
                "Parking Detection",
                log_dir / "parking.log"
            )
            
            # Wait a bit for parking detection to start
            time.sleep(2)
        
        # 5. Start object detection (if needed)
        if not args.no_object_detection:
            print("5. Starting Object Detection...")
            object_cmd = [
                "python", "object_detection.py",
                "--stream-port", str(args.object_port),
                "--calibration", args.calibration,
                "--model", args.object_model,
                "--confidence", str(args.confidence),
                "--udp-ip", args.object_udp_ip,
                "--udp-port", str(args.object_udp_port)
            ]
            processes['object_detection'] = run_command(
                object_cmd,
                "Object Detection",
                log_dir / "object_detection.log"
            )
        
        print()
        print("[OK] All applications started successfully!")
        print()
        print("Applications running:")
        if not args.no_nav_parking:
            print(f"  [STREAM] Nav/Parking Stream Multiplier (PID: {processes['nav_parking_multiplier'].pid})")
            print(f"  [NAV] Waypoint Navigation (PID: {processes['navigation'].pid})")
            print(f"  [PARK] Parking Detection (PID: {processes['parking'].pid})")
        if not args.no_object_detection:
            print(f"  [STREAM] Object Detection Stream Multiplier (PID: {processes['object_multiplier'].pid})")
            print(f"  [OBJ] Object Detection (PID: {processes['object_detection'].pid})")
        print()
        print("Log files:")
        if not args.no_nav_parking:
            print(f"  [LOG] Nav/Parking Stream Multiplier: {log_dir / 'nav_parking_multiplier.log'}")
            print(f"  [LOG] Navigation: {log_dir / 'navigation.log'}")
            print(f"  [LOG] Parking Detection: {log_dir / 'parking.log'}")
        if not args.no_object_detection:
            print(f"  [LOG] Object Detection Stream Multiplier: {log_dir / 'object_multiplier.log'}")
            print(f"  [LOG] Object Detection: {log_dir / 'object_detection.log'}")
        print()
        print("UDP Destinations:")
        if not args.no_nav_parking:
            print(f"  [UDP] Navigation: {args.nav_udp_ip}:{args.nav_udp_port}")
            print(f"  [UDP] Parking: {args.parking_udp_ip}:{args.parking_udp_port}")
        if not args.no_object_detection:
            print(f"  [UDP] Object Detection: {args.object_udp_ip}:{args.object_udp_port}")
        print()
        print("Press Ctrl+C to stop all applications...")
        print()
        
        # Monitor processes
        while True:
            time.sleep(1)
            
            # Check if any process has died
            for name, process in processes.items():
                if process.poll() is not None:
                    print(f"[WARNING] {name} has stopped unexpectedly (exit code: {process.returncode})")
                    print("Stopping all applications...")
                    raise KeyboardInterrupt()
    
    except KeyboardInterrupt:
        print("\n[INFO] Stopping all applications...")
        
        # Stop all processes
        for name, process in processes.items():
            if process.poll() is None:  # Still running
                print(f"Stopping {name}...")
                process.terminate()
                try:
                    process.wait(timeout=5)
                    print(f"[OK] {name} stopped")
                except subprocess.TimeoutExpired:
                    print(f"[WARNING] {name} didn't stop gracefully, forcing...")
                    process.kill()
                    process.wait()
                    print(f"[OK] {name} force stopped")
        
        print("[OK] All applications stopped")
    
    except Exception as e:
        print(f"[ERROR] Error: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
