#!/usr/bin/env python3
"""
Simple script to run parking detection system.
This detects cars in calibrated parking locations using UDP stream and localization.
"""

import subprocess
import sys
import os
import argparse

def main():
    parser = argparse.ArgumentParser(description="Run parking detection system")
    parser.add_argument("--stream-port", type=int, default=5002,
                       help="UDP stream port to use (default: 5002)")
    parser.add_argument("--calibration", default="enhanced_calibration.json",
                       help="Calibration file (default: enhanced_calibration.json)")
    parser.add_argument("--model", default="model_car_heading.pt",
                       help="YOLO model file (default: model_car_heading.pt)")
    parser.add_argument("--zones-file", default="parking_zones.json",
                       help="Parking zones file (default: parking_zones.json)")
    parser.add_argument("--confidence", type=float, default=0.9,
                       help="Detection confidence threshold (default: 0.9)")
    parser.add_argument("--udp-ip", default="127.0.0.1",
                       help="UDP IP for status reporting (default: 127.0.0.1)")
    parser.add_argument("--udp-port", type=int, default=50002,
                       help="UDP port for status reporting (default: 50002)")
    parser.add_argument("--udp-send-interval", type=int, default=30,
                       help="Send UDP packets every N frames (default: 30)")
    
    args = parser.parse_args()
    
    # Configuration
    STREAM_PORT = args.stream_port
    CALIBRATION_FILE = args.calibration
    MODEL_PATH = args.model
    ZONES_FILE = args.zones_file
    CONFIDENCE_THRESHOLD = args.confidence
    UDP_IP = args.udp_ip
    UDP_PORT = args.udp_port
    UDP_SEND_INTERVAL = args.udp_send_interval
    
    print("=== Parking Detection System ===")
    print("This detects cars in calibrated parking locations.")
    print("Uses UDP stream with localization for real-time detection.")
    print()
    print("Features:")
    print("- Real-time car detection in rectangular parking zones")
    print("- Visual indicators for zone occupancy")
    print("- Calibratable rectangular parking zones (click twice to draw)")
    print("- Automatic zone management")
    print("- UDP status reporting (sends occupancy changes)")
    print()
    print("Controls:")
    print("- 'c': Enter/exit calibration mode")
    print("- 'n': Add new rectangular zone (auto-named, click twice)")
    print("- 'e': Edit last zone name (cycle through names)")
    print("- 's': Save parking zones")
    print("- 'l': Load parking zones")
    print("- 'r': Reset all zones")
    print("- 'q': Quit")
    print()
    
    # Check if files exist
    if not os.path.exists(CALIBRATION_FILE):
        print(f"[ERROR] Calibration file '{CALIBRATION_FILE}' not found!")
        print("Please run enhanced calibration first:")
        print("python run_enhanced_calibration.py")
        return
    
    if not os.path.exists(MODEL_PATH):
        print(f"[ERROR] Model file '{MODEL_PATH}' not found!")
        print("Please ensure your YOLO model is available.")
        return
    
    print(f"[OK] Found calibration file: {CALIBRATION_FILE}")
    print(f"[OK] Found model file: {MODEL_PATH}")
    print()
    
    # Check if parking zones file exists
    if os.path.exists(ZONES_FILE):
        print(f"[OK] Found existing parking zones: {ZONES_FILE}")
        print("You can add more zones or modify existing ones during detection.")
    else:
        print(f"[INFO] No existing parking zones found. Starting with empty zones.")
        print("Use calibration mode ('c') to add parking zones by clicking.")
    
    print()
    print("Starting parking detection...")
    print("You will see:")
    print("- Real-time video stream with localization")
    print("- Parking zones (green=available, red=occupied)")
    print("- Car detections with confidence scores")
    print("- Zone occupancy status in terminal")
    print("- UDP status messages when occupancy changes")
    print()
    print("Press 'c' to enter calibration mode, then 'n' to add rectangular zones")
    print("Press 'e' to rename the last created zone")
    print("Press 'q' to quit")
    print()
    
    # Run parking detection
    cmd = [
        "python", "parking_detection.py",
        "--calibration", CALIBRATION_FILE,
        "--model", MODEL_PATH,
        "--stream-port", str(STREAM_PORT),
        "--stream-latency", "5",
        "--zones-file", ZONES_FILE,
        "--confidence", str(CONFIDENCE_THRESHOLD),
        "--udp-ip", UDP_IP,
        "--udp-port", str(UDP_PORT),
        "--udp-send-interval", str(UDP_SEND_INTERVAL)
    ]
    
    print(f"Running: {' '.join(cmd)}")
    print()
    
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print("[ERROR] Parking detection failed!")
        return
    
    print("[OK] Parking detection completed!")

if __name__ == "__main__":
    main()
