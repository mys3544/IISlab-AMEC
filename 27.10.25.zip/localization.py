import argparse
import json
import os
import socket
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

os.add_dll_directory(r"C:\Users\Mys\Desktop\AMEC\AMEC\opencv-4.12.0\build\install\x64\vc17\bin")
os.add_dll_directory(r"C:\Users\Mys\Desktop\AMEC\AMEC\gstreamer\1.0\msvc_x86_64\bin")
import cv2
import numpy as np


# ==========================
# Data structures
# ==========================


@dataclass
class WorldConfig:
    world_width_cm: float
    world_height_cm: float
    origin: str = "bottom_left"  # fixed per user requirement


@dataclass
class CameraConfig:
    height_cm: float  # Camera height above ground
    angle_degrees: float  # Camera angle from vertical (0 = looking straight down)
    robot_height_cm: float  # Height of the robot being tracked


@dataclass
class Calibration:
    homography: np.ndarray
    image_width: int
    image_height: int
    world: WorldConfig
    camera: Optional[CameraConfig] = None

    def to_dict(self) -> dict:
        result = {
            "homography": self.homography.tolist(),
            "image_width": self.image_width,
            "image_height": self.image_height,
            "world": {
                "world_width_cm": self.world.world_width_cm,
                "world_height_cm": self.world.world_height_cm,
                "origin": self.world.origin,
            },
        }
        if self.camera is not None:
            result["camera"] = {
                "height_cm": self.camera.height_cm,
                "angle_degrees": self.camera.angle_degrees,
                "robot_height_cm": self.camera.robot_height_cm,
            }
        return result

    @staticmethod
    def from_dict(data: dict) -> "Calibration":
        H = np.array(data["homography"], dtype=np.float64)
        world = WorldConfig(
            world_width_cm=float(data["world"]["world_width_cm"]),
            world_height_cm=float(data["world"]["world_height_cm"]),
            origin=str(data["world"].get("origin", "bottom_left")),
        )
        
        camera = None
        if "camera" in data:
            camera = CameraConfig(
                height_cm=float(data["camera"]["height_cm"]),
                angle_degrees=float(data["camera"]["angle_degrees"]),
                robot_height_cm=float(data["camera"]["robot_height_cm"]),
            )
        
        return Calibration(
            homography=H,
            image_width=int(data["image_width"]),
            image_height=int(data["image_height"]),
            world=world,
            camera=camera,
        )


# ==========================
# Utility functions
# ==========================


def open_video_capture(source: str, stream_config: Optional[dict] = None) -> cv2.VideoCapture:
    # Handle GStreamer pipeline for UDP streams
    if source.startswith("udp://") or (stream_config and stream_config.get("use_gstreamer", False)):
        if stream_config:
            port = stream_config.get("port", 5000)
            latency = stream_config.get("latency", 5)
        else:
            # Extract port from udp:// format
            port = source.split("://")[1] if "://" in source else "5000"
            latency = 5
            
        gst_pipeline = (
            f'udpsrc port={port} '
            'caps="application/x-rtp, media=video, encoding-name=H264, payload=96, clock-rate=90000" ! '
            f'rtpjitterbuffer latency={latency} ! '
            'rtph264depay ! h264parse ! avdec_h264 ! '
            'videoconvert ! video/x-raw,format=BGR ! '
            'appsink drop=false sync=false'
        )
        cap = cv2.VideoCapture(gst_pipeline, cv2.CAP_GSTREAMER)
    else:
        # Handle regular camera/file sources
        try:
            source_index = int(source)
            cap = cv2.VideoCapture(source_index)
        except ValueError:
            cap = cv2.VideoCapture(source)
    
    if not cap.isOpened():
        raise RuntimeError(f"Unable to open video source: {source}")
    return cap


def save_calibration(calib: Calibration, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(calib.to_dict(), f, indent=2)


def load_calibration(path: Path) -> Calibration:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    return Calibration.from_dict(data)


def compute_homography_from_corners(
    image_points: List[Tuple[float, float]],
    world_width_cm: float,
    world_height_cm: float,
) -> np.ndarray:
    if len(image_points) != 4:
        raise ValueError("Exactly 4 image points are required: BL, BR, TR, TL")

    # World coordinates in centimeters with origin at bottom-left
    world_points = np.array(
        [
            [0.0, 0.0],
            [world_width_cm, 0.0],
            [world_width_cm, world_height_cm],
            [0.0, world_height_cm],
        ],
        dtype=np.float64,
    )

    img_pts = np.array(image_points, dtype=np.float64)
    H, status = cv2.findHomography(img_pts, world_points, method=cv2.RANSAC)
    if H is None:
        raise RuntimeError("Homography computation failed")
    return H


def perspective_map_pixels_to_world(points_px: np.ndarray, H: np.ndarray) -> np.ndarray:
    points_px = points_px.reshape(-1, 1, 2).astype(np.float64)
    points_world = cv2.perspectiveTransform(points_px, H)
    return points_world.reshape(-1, 2)


def get_centroid_from_bbox_xyxy(x1: float, y1: float, x2: float, y2: float) -> Tuple[float, float]:
    cx = (x1 + x2) * 0.5
    cy = (y1 + y2) * 0.5
    return cx, cy


def compensate_for_robot_height(
    centroid_px: Tuple[float, float], 
    camera_config: CameraConfig,
    image_width: int,
    image_height: int
) -> Tuple[float, float]:
    """
    Compensate for robot height by adjusting the bounding box center to represent
    the ground position instead of the center of the 3D bounding box.
    
    Args:
        centroid_px: (x, y) pixel coordinates of bounding box center
        camera_config: Camera configuration with height and angle info
        image_width: Image width in pixels
        image_height: Image height in pixels
    
    Returns:
        Adjusted (x, y) pixel coordinates representing ground position
    """
    if camera_config is None:
        return centroid_px
    
    cx, cy = centroid_px
    
    # Convert angle to radians
    angle_rad = np.radians(camera_config.angle_degrees)
    
    # Calculate the vertical offset due to robot height
    # This is a simplified model assuming the camera is looking down at an angle
    # The actual calculation would depend on the specific camera geometry
    
    # For a camera looking down at an angle, the robot height causes a shift
    # in the image plane. The shift is proportional to the robot height and
    # the camera angle.
    
    # Calculate the effective focal length (approximate)
    # This is a rough estimate - in practice you'd want to calibrate this
    focal_length_px = max(image_width, image_height)  # Rough approximation
    
    # Calculate the vertical shift due to robot height
    # The robot height causes the bounding box center to appear higher in the image
    # than the actual ground position
    height_offset_px = (camera_config.robot_height_cm / camera_config.height_cm) * focal_length_px * np.sin(angle_rad)
    
    # Adjust the y-coordinate to move the center down to ground level
    adjusted_cy = cy + height_offset_px
    
    return cx, adjusted_cy


def send_detection_udp(payload: dict, target_ip: str, target_port: int, udp_sock: socket.socket) -> None:
    """Send detection data via UDP"""
    try:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        udp_sock.sendto(data, (target_ip, target_port))
    except Exception as e:
        print(f"[UDP] send error: {e}")


# ==========================
# Calibration via manual clicks
# ==========================


class ClickCollector:
    def __init__(self, required_points: int) -> None:
        self.required_points = required_points
        self.collected: List[Tuple[int, int]] = []

    def mouse_callback(self, _event, x, y, flags, param) -> None:  # type: ignore[override]
        if _event == cv2.EVENT_LBUTTONDOWN:
            self.collected.append((x, y))


def calibrate_corners_interactive(
    source: str,
    world_width_cm: float,
    world_height_cm: float,
    stream_config: Optional[dict] = None,
    camera_height_cm: Optional[float] = None,
    camera_angle_degrees: Optional[float] = None,
    robot_height_cm: Optional[float] = None,
) -> Calibration:
    cap = open_video_capture(source, stream_config)
    ok, frame = cap.read()
    if not ok:
        cap.release()
        raise RuntimeError("Failed to capture initial frame for calibration")

    window_name = "Select corners: BL, BR, TR, TL (ESC to cancel)"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    collector = ClickCollector(required_points=4)
    cv2.setMouseCallback(window_name, collector.mouse_callback)

    while True:
        frame_copy = frame.copy()
        # draw any collected points
        for idx, (px, py) in enumerate(collector.collected):
            cv2.circle(frame_copy, (px, py), 6, (0, 255, 0), -1)
            cv2.putText(
                frame_copy,
                str(idx + 1),
                (px + 8, py - 8),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),
                2,
                cv2.LINE_AA,
            )
        cv2.imshow(window_name, frame_copy)
        key = cv2.waitKey(20) & 0xFF
        if key == 27:  # ESC
            cap.release()
            cv2.destroyWindow(window_name)
            raise KeyboardInterrupt("Calibration cancelled")
        if len(collector.collected) >= 4:
            break

    cv2.destroyWindow(window_name)
    cap.release()

    image_points = [tuple(map(float, p)) for p in collector.collected[:4]]
    H = compute_homography_from_corners(image_points, world_width_cm, world_height_cm)
    h, w = frame.shape[:2]
    
    # Create camera config if parameters are provided
    camera_config = None
    if all(param is not None for param in [camera_height_cm, camera_angle_degrees, robot_height_cm]):
        camera_config = CameraConfig(
            height_cm=camera_height_cm,
            angle_degrees=camera_angle_degrees,
            robot_height_cm=robot_height_cm
        )
    
    return Calibration(
        homography=H, 
        image_width=w, 
        image_height=h, 
        world=WorldConfig(world_width_cm, world_height_cm),
        camera=camera_config
    )


# ==========================
# YOLO runner (Ultralytics)
# ==========================


class YoloDetector:
    def __init__(self, model_path: str, target_class: Optional[str] = None, device: Optional[str] = None) -> None:
        from ultralytics import YOLO  # lazy import

        self.model = YOLO(model_path)
        self.target_class = target_class
        self.device = device

    def detect_first_centroid(self, frame_bgr: np.ndarray) -> Optional[Tuple[float, float]]:
        # Run inference; stream=False for single image
        results = self.model(frame_bgr, verbose=False, device=self.device)
        if not results:
            return None
        result = results[0]

        if result.boxes is None or len(result.boxes) == 0:
            return None

        b = result.boxes
        classes = None
        if hasattr(b, "cls") and b.cls is not None:
            try:
                classes = b.cls.cpu().numpy().astype(int)
            except Exception:
                classes = None

        names = result.names if hasattr(result, "names") else {}

        # Choose the first box matching the target class (if provided), else the most confident
        best_index = None
        if self.target_class is not None and classes is not None:
            for i, c in enumerate(classes):
                class_name = names.get(int(c), str(int(c)))
                if class_name == self.target_class:
                    best_index = i
                    break

        if best_index is None:
            # fallback to highest confidence
            conf = b.conf.cpu().numpy() if hasattr(b, "conf") and b.conf is not None else None
            best_index = int(np.argmax(conf)) if conf is not None else 0

        x1, y1, x2, y2 = b.xyxy[best_index].cpu().numpy().tolist()
        return get_centroid_from_bbox_xyxy(x1, y1, x2, y2)


# ==========================
# Smoothing
# ==========================


class ExponentialMovingAverage:
    def __init__(self, alpha: float) -> None:
        self.alpha = float(alpha)
        self.value: Optional[np.ndarray] = None

    def update(self, new_value: np.ndarray) -> np.ndarray:
        if self.value is None:
            self.value = new_value.astype(np.float64)
        else:
            self.value = self.alpha * new_value + (1.0 - self.alpha) * self.value
        return self.value


# ==========================
# Commands
# ==========================


def cmd_calibrate(args: argparse.Namespace) -> None:
    if args.method != "corners":
        raise NotImplementedError("Only 'corners' calibration is implemented in this version")

    # Setup stream configuration
    stream_config = None
    if args.use_gstreamer:
        stream_config = {
            "use_gstreamer": True,
            "port": args.stream_port,
            "latency": args.stream_latency
        }

    calib = calibrate_corners_interactive(
        source=args.source,
        world_width_cm=args.map_width_cm,
        world_height_cm=args.map_height_cm,
        stream_config=stream_config,
        camera_height_cm=getattr(args, 'camera_height_cm', None),
        camera_angle_degrees=getattr(args, 'camera_angle_degrees', None),
        robot_height_cm=getattr(args, 'robot_height_cm', None),
    )
    save_calibration(calib, Path(args.out))
    print(f"Saved calibration to {args.out}")


def cmd_run(args: argparse.Namespace) -> None:
    calib = load_calibration(Path(args.calib))
    
    # Setup stream configuration
    stream_config = None
    if args.use_gstreamer:
        stream_config = {
            "use_gstreamer": True,
            "port": args.stream_port,
            "latency": args.stream_latency
        }
    
    cap = open_video_capture(args.source, stream_config)

    detector = YoloDetector(model_path=args.model, target_class=args.cls, device=args.device)
    ema = ExponentialMovingAverage(alpha=args.ema_alpha) if args.ema_alpha is not None else None

    H = calib.homography.astype(np.float64)

    # Setup UDP socket if enabled
    udp_sock = None
    if args.udp_enabled:
        udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    last_print_time = 0.0
    min_print_interval = 0.02  # 20 ms

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        # Get all detections for better visualization
        results = detector.model(frame, verbose=False)
        if not results:
            if args.show:
                cv2.imshow("localization", frame)
                if (cv2.waitKey(1) & 0xFF) == 27:
                    break
            continue
            
        result = results[0]
        centroid_px = detector.detect_first_centroid(frame)
        
        # Apply height compensation if camera config is available
        if centroid_px is not None and calib.camera is not None:
            centroid_px = compensate_for_robot_height(
                centroid_px, 
                calib.camera, 
                calib.image_width, 
                calib.image_height
            )
        
        # Send UDP data if enabled
        if args.udp_enabled and udp_sock:
            sent_any = False
            if result.boxes is not None and len(result.boxes) > 0:
                for box in result.boxes:
                    conf = float(box.conf[0])
                    if conf < args.confidence_threshold:
                        continue
                    
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    label = detector.model.names[int(box.cls[0])]
                    
                    # Calculate world coordinates for this detection
                    box_centroid = get_centroid_from_bbox_xyxy(x1, y1, x2, y2)
                    
                    # Apply height compensation if camera config is available
                    if calib.camera is not None:
                        box_centroid = compensate_for_robot_height(
                            box_centroid, 
                            calib.camera, 
                            calib.image_width, 
                            calib.image_height
                        )
                    
                    px_box = np.array([[box_centroid[0], box_centroid[1]]], dtype=np.float64)
                    world_xy_box = perspective_map_pixels_to_world(px_box, H)[0]
                    
                    payload = {
                        "x1": x1, "y1": y1, "x2": x2, "y2": y2,
                        "label": label,
                        "confidence": conf,
                        "world_x": float(world_xy_box[0]),
                        "world_y": float(world_xy_box[1])
                    }
                    send_detection_udp(payload, args.udp_ip, args.udp_port, udp_sock)
                    sent_any = True
                    
                    # Draw bounding box
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(frame, f"{label} {conf:.2f}", (x1, max(y1 - 10, 20)),
                              cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            
            if not sent_any:
                payload = {
                    "x1": 0, "y1": 0, "x2": 0, "y2": 0,
                    "label": "Nothing",
                    "confidence": 0.0,
                    "world_x": 0.0,
                    "world_y": 0.0
                }
                send_detection_udp(payload, args.udp_ip, args.udp_port, udp_sock)

        if centroid_px is None:
            # Nothing detected this frame
            if args.show:
                cv2.imshow("localization", frame)
                if (cv2.waitKey(1) & 0xFF) == 27:
                    break
            continue

        px = np.array([[centroid_px[0], centroid_px[1]]], dtype=np.float64)
        world_xy = perspective_map_pixels_to_world(px, H)[0]
        if ema is not None:
            world_xy = ema.update(world_xy)

        now = time.time()
        if now - last_print_time >= min_print_interval:
            print(f"X={world_xy[0]:.1f} cm, Y={world_xy[1]:.1f} cm")
            last_print_time = now

        if args.show:
            x_cm, y_cm = float(world_xy[0]), float(world_xy[1])
            cv2.circle(frame, (int(centroid_px[0]), int(centroid_px[1])), 6, (0, 0, 255), -1)
            cv2.putText(
                frame,
                f"({x_cm:.1f}, {y_cm:.1f}) cm",
                (int(centroid_px[0]) + 8, int(centroid_px[1]) - 8),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
            cv2.imshow("localization", frame)
            if (cv2.waitKey(1) & 0xFF) == 27:
                break

    cap.release()
    if udp_sock:
        udp_sock.close()
    if args.show:
        cv2.destroyAllWindows()


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Camera-to-map localization tool (YOLO + homography)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    # calibrate
    p_cal = sub.add_parser("calibrate", help="Run calibration")
    p_cal.add_argument("--source", default="0", help="Video source (index, URL, or udp://port). Default: 0")
    p_cal.add_argument("--method", choices=["corners", "pose"], default="corners", help="Calibration method")
    p_cal.add_argument("--map-width-cm", type=float, required=True, dest="map_width_cm")
    p_cal.add_argument("--map-height-cm", type=float, required=True, dest="map_height_cm")
    p_cal.add_argument("--out", default="calibration.json", help="Output calibration file path")
    p_cal.add_argument("--use-gstreamer", action="store_true", help="Use GStreamer for UDP streams")
    p_cal.add_argument("--stream-port", type=int, default=5000, help="UDP stream port (default: 5000)")
    p_cal.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer (default: 5)")
    
    # Camera configuration for height compensation
    p_cal.add_argument("--camera-height-cm", type=float, help="Camera height above ground in cm (for height compensation)")
    p_cal.add_argument("--camera-angle-degrees", type=float, help="Camera angle from vertical in degrees (for height compensation)")
    p_cal.add_argument("--robot-height-cm", type=float, help="Robot height in cm (for height compensation)")
    
    p_cal.set_defaults(func=cmd_calibrate)

    # run
    p_run = sub.add_parser("run", help="Run localization")
    p_run.add_argument("--source", default="0", help="Video source (index, URL, or udp://port). Default: 0")
    p_run.add_argument("--calib", default="calibration.json", help="Calibration file path")
    p_run.add_argument("--model", default="model_car_heading.pt", help="Ultralytics YOLO model path")
    p_run.add_argument("--cls", default=None, help="Target class name to filter (optional)")
    p_run.add_argument("--device", default=None, help="Inference device, e.g. 'cpu', '0'")
    p_run.add_argument("--ema-alpha", type=float, default=0.3, dest="ema_alpha", help="EMA smoothing factor (0-1). 0 disables")
    p_run.add_argument("--show", action="store_true", help="Show visualization window")
    
    # Streaming options
    p_run.add_argument("--use-gstreamer", action="store_true", help="Use GStreamer for UDP streams")
    p_run.add_argument("--stream-port", type=int, default=5000, help="UDP stream port (default: 5000)")
    p_run.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer (default: 5)")
    
    # UDP sending options
    p_run.add_argument("--udp-enabled", action="store_true", help="Enable UDP data transmission")
    p_run.add_argument("--udp-ip", default="147.232.73.238", help="UDP target IP address")
    p_run.add_argument("--udp-port", type=int, default=50000, help="UDP target port")
    p_run.add_argument("--confidence-threshold", type=float, default=0.8, help="Minimum confidence for detections")
    
    p_run.set_defaults(func=cmd_run)

    return parser


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()

    if hasattr(args, "ema_alpha") and args.ema_alpha is not None and args.ema_alpha <= 0.0:
        args.ema_alpha = None

    args.func(args)


if __name__ == "__main__":
    main()

