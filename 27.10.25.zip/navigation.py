#!/usr/bin/env python3
"""
Waypoint-based navigation that uses your calibrated logical waypoints for path planning.
This eliminates the numbered path waypoints and uses your actual waypoints instead.
"""

import argparse
import json
import math
import os
import socket
import time
from pathlib import Path
from typing import Optional, List, Tuple
import numpy as np

# Add OpenCV and GStreamer paths
os.add_dll_directory(r"C:\Users\Mys\Desktop\AMEC\AMEC\opencv-4.12.0\build\install\x64\vc17\bin")
os.add_dll_directory(r"C:\Users\Mys\Desktop\AMEC\AMEC\gstreamer\1.0\msvc_x86_64\bin")
import cv2

# Import from existing modules
from localization import (
    load_calibration, open_video_capture, YoloDetector, 
    ExponentialMovingAverage, perspective_map_pixels_to_world,
    compensate_for_robot_height, send_detection_udp
)
from heading_detector import MultiHeadingDetector
from movement_heading_detector import MovementHeadingDetector, CombinedHeadingDetector


class WaypointBasedNavigation:
    """Navigation system that uses logical waypoints for path planning"""
    
    def __init__(self, calibration_file: str, waypoints_file: str, model_path: str = "model_car_heading.pt", 
                 heading_tolerance: float = 22.5, udp_ip: str = "127.0.0.1", udp_port: int = 50001, 
                 udp_send_interval: int = 30, continuous_navigation: bool = False, 
                 use_movement_heading: bool = False):
        self.calib = load_calibration(Path(calibration_file))
        self.detector = MultiHeadingDetector(model_path=model_path)
        self.movement_detector = MovementHeadingDetector(history_size=5, min_movement_threshold=1.0)
        self.combined_detector = CombinedHeadingDetector(self.detector, self.movement_detector)
        self.use_movement_heading = use_movement_heading
        self.combined_detector.set_heading_mode(use_movement_heading)
        self.ema = ExponentialMovingAverage(alpha=0.3)
        self.waypoints = self.load_waypoints(waypoints_file)
        self.H = self.calib.homography.astype(float)
        
        # Navigation state
        self.target_waypoint = None
        self.current_path = []
        self.current_action_index = 0
        self.running = False
        self.heading_tolerance = heading_tolerance  # Degrees tolerance for waypoint selection
        self.continuous_navigation = continuous_navigation  # Demo mode - keep running after reaching target
        self.waypoint_cycle_index = 0  # For cycling through waypoints in continuous mode
        
        # Enhanced navigation state for approach direction tracking
        self.approach_directions = {}  # Track approach direction for each waypoint
        self.previous_waypoint = None  # Track previous waypoint to prevent backtracking
        self.robot_approach_heading = None  # Track robot's heading when approaching waypoint
        
        # Heading history for fallback when heading is unknown
        self.last_valid_heading_class = "rosmaster_r2_rotation"  # Default to rotation/unknown
        self.heading_history = []
        
        # Command history for debugging and display
        self.command_history = []
        self.max_command_history = 5  # Store recent heading classes for smoothing
        
        # UDP settings
        self.udp_ip = udp_ip
        self.udp_port = udp_port
        self.udp_socket = None
        
        # Frame counter for UDP sending frequency control
        self.frame_count = 0
        self.udp_send_interval = udp_send_interval  # Send UDP packets every N frames
        
        # Waypoint lookup
        self.waypoint_lookup = {wp['name']: i for i, wp in enumerate(self.waypoints)}
        
        # Define connections between waypoints (road network)
        self.connections = [
            
            # Cross connections (intersections to outer corners)
            (0, 4), (4,0), (4, 1), (1, 4), # Top cross
            (1, 8), (8, 1), (8, 2), (2, 8),  # Right cross  
            (2, 6), (6, 2), (6, 3), (3, 6),  # Bottom cross
            (3, 7), (7, 3), (7, 0), (0, 7),  # Left cross
            
            # Center connections
            (4, 5), (5, 6), (6, 5), (5, 4),  # Top-Center-Bottom
            (7, 9), (5, 8), (8, 5), (9, 7), (9, 5), (5, 9),# Left-Center-Right
            
        ]
    
    def load_waypoints(self, waypoints_file: str) -> List[dict]:
        """Load waypoints from JSON file"""
        with open(waypoints_file, 'r') as f:
            return json.load(f)
    
    def world_to_pixel_camera_compensated(self, world_x: float, world_y: float, object_height_cm: float = 0.0) -> tuple:
        """Convert world coordinates to pixel coordinates with camera compensation"""
        world_point = np.array([[world_x, world_y]], dtype=np.float64)
        pixel_point = cv2.perspectiveTransform(world_point.reshape(-1, 1, 2), np.linalg.inv(self.H))
        pixel_x, pixel_y = pixel_point.reshape(-1, 2)[0]
        
        # Apply camera compensation if camera config is available
        if self.calib.camera is not None and object_height_cm > 0:
            angle_rad = np.radians(self.calib.camera.angle_degrees)
            focal_length_px = max(self.calib.image_width, self.calib.image_height)
            height_offset_px = (object_height_cm / self.calib.camera.height_cm) * focal_length_px * np.sin(angle_rad)
            pixel_y -= height_offset_px
        
        return int(pixel_x), int(pixel_y)
    
    def get_waypoint_by_name(self, name: str) -> Optional[dict]:
        """Get waypoint by name"""
        if name in self.waypoint_lookup:
            return self.waypoints[self.waypoint_lookup[name]]
        return None
    
    def find_closest_waypoint(self, robot_x: float, robot_y: float) -> int:
        """Find closest waypoint to robot position"""
        min_distance = float('inf')
        closest_idx = 0
        
        for i, wp in enumerate(self.waypoints):
            distance = math.sqrt((robot_x - wp['world_x'])**2 + (robot_y - wp['world_y'])**2)
            if distance < min_distance:
                min_distance = distance
                closest_idx = i
        
        return closest_idx
    
    def find_waypoint_in_heading_direction(self, robot_x: float, robot_y: float, robot_heading_class: str) -> int:
        """Find the closest waypoint that is within 45° of the robot's heading direction using categorical heading"""
        min_distance = float('inf')
        best_idx = 0
        best_score = float('inf')
        
        # Convert robot heading class to cardinal direction
        robot_direction = self.get_heading_direction_from_class(robot_heading_class)
        
        for i, wp in enumerate(self.waypoints):
            # Calculate distance to waypoint
            distance = math.sqrt((robot_x - wp['world_x'])**2 + (robot_y - wp['world_y'])**2)
            
            # Calculate direction from robot to waypoint
            dx = wp['world_x'] - robot_x
            dy = wp['world_y'] - robot_y
            waypoint_direction = self.get_direction_to_waypoint(dx, dy)
            
            # Check if waypoint is in the robot's heading direction
            if self.is_waypoint_in_heading_direction(robot_direction, waypoint_direction):
                # Score based on distance (closer is better)
                score = distance
                if score < best_score:
                    best_score = score
                    best_idx = i
                    min_distance = distance
        
        # If no waypoint found in heading direction, fall back to closest waypoint
        if best_score == float('inf'):
            print(f"No waypoint found in {robot_direction} direction, using closest waypoint")
            return self.find_closest_waypoint(robot_x, robot_y)
        
        print(f"Selected waypoint {best_idx} at {min_distance:.1f}cm in {robot_direction} direction (within 45° angle)")
        return best_idx
    
    def find_waypoint_path(self, start_idx: int, goal_idx: int, robot_heading_class: str = "rosmaster_r2_rotation") -> Optional[List[int]]:
        """Find path through waypoint network using heading-aware pathfinding"""
        if start_idx == goal_idx:
            return [start_idx]
        
        # Use Dijkstra-like algorithm with turn cost consideration
        import heapq
        
        # Priority queue: (total_cost, current_idx, path, current_heading)
        queue = [(0, start_idx, [start_idx], robot_heading_class)]
        visited = {}  # (waypoint_idx, heading_class) -> cost

        # Determine the index of the waypoint that is "behind" the robot at start and mark as visited
        # "Behind" is the opposite direction from the robot's heading
        
        # Only do this for the starting node
        behind_idx = None
        # Get robot's current direction
        current_direction = self.get_heading_direction_from_class(robot_heading_class)
        # Opposite direction mapping
        opposite_dir = {
            'North': 'South',
            'South': 'North',
            'East': 'West',
            'West': 'East',
            'Unknown': 'Unknown'
        }
        if current_direction != 'Unknown':
            # Find the waypoint most directly "behind" the robot, i.e., the closest waypoint that lies in the "opposite" direction
            min_dist = float('inf')
            for idx, wp in enumerate(self.waypoints):
                if idx == start_idx:
                    continue
                dx = wp['world_x'] - self.waypoints[start_idx]['world_x']
                dy = wp['world_y'] - self.waypoints[start_idx]['world_y']
                dir_to_wp = self.get_direction_to_waypoint(dx, dy)
                if dir_to_wp == opposite_dir[current_direction]:
                    dist = (dx ** 2 + dy ** 2) ** 0.5
                    if dist < min_dist:
                        min_dist = dist
                        behind_idx = idx
            # If found, mark this (behind_idx, robot_heading_class) as visited with infinite cost,
            # so the planner cannot go backwards at the very start
            if behind_idx is not None:
                visited[(behind_idx, robot_heading_class)] = float('inf')
        
        while queue:
            total_cost, current_idx, path, current_heading = heapq.heappop(queue)
            
            # Check if we've reached the goal
            if current_idx == goal_idx:
                return path
            
            # Skip if we've visited this state with better cost
            state = (current_idx, current_heading)
            if state in visited and visited[state] <= total_cost:
                continue
            visited[state] = total_cost
            
            # Check all connected waypoints
            for connection in self.connections:
                if connection[0] == current_idx:
                    next_idx = connection[1]
                    
                    # Calculate turn cost to reach next waypoint
                    turn_cost = self.calculate_turn_cost(current_idx, next_idx, current_heading)
                    new_cost = total_cost + 1 + turn_cost  # Base cost + turn cost
                    
                    # Get heading after turn
                    next_heading = self.get_heading_after_turn(current_idx, next_idx, current_heading)
                    
                    # Add to queue if not visited or better cost
                    new_state = (next_idx, next_heading)
                    if new_state not in visited or visited[new_state] > new_cost:
                        heapq.heappush(queue, (new_cost, next_idx, path + [next_idx], next_heading))
        
        return None
    def start_navigation_to_waypoint(self, target_waypoint_name: str):
        """Start navigation to a named waypoint"""
        target_wp = self.get_waypoint_by_name(target_waypoint_name)
        if not target_wp:
            print(f"Error: Waypoint '{target_waypoint_name}' not found!")
            return False
        
        self.target_waypoint = target_wp
        self.running = True
        self.current_action_index = 0
        
        # Setup UDP socket for sending commands
        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        print(f"Navigation started to waypoint: {target_waypoint_name}")
        print(f"Target position: ({target_wp['world_x']:.1f}, {target_wp['world_y']:.1f}) cm")
        print(f"UDP target: {self.udp_ip}:{self.udp_port}")
        if self.continuous_navigation:
            print("CONTINUOUS MODE: Robot will cycle through waypoints for demo presentation")
        return True
    
    def get_next_waypoint_for_continuous_mode(self) -> str:
        """Get next waypoint for continuous navigation cycling"""
        if not self.waypoints:
            return None
        
        # Cycle through waypoints in order
        waypoint_name = self.waypoints[self.waypoint_cycle_index]['name']
        self.waypoint_cycle_index = (self.waypoint_cycle_index + 1) % len(self.waypoints)
        return waypoint_name
    
    def update_robot_position(self, robot_x: float, robot_y: float, heading_class: str = "rosmaster_r2_rotation"):
        """Update robot position and plan path with approach direction validation"""
        if not self.running or not self.target_waypoint:
            return
        
        # Find waypoint in robot's heading direction using categorical heading
        start_idx = self.find_waypoint_in_heading_direction(robot_x, robot_y, heading_class)
        target_idx = self.waypoint_lookup[self.target_waypoint['name']]
        
        # Plan path through waypoint network with heading awareness
        path_indices = self.find_waypoint_path(start_idx, target_idx, heading_class)
        if not path_indices:
            print("No path found to target waypoint!")
            return
        
        # Convert to world coordinates
        self.current_path = []
        for idx in path_indices:
            wp = self.waypoints[idx]
            self.current_path.append((wp['world_x'], wp['world_y']))
        
        # Add robot's current position as first point
        self.current_path.insert(0, (robot_x, robot_y))
        
        # Store approach direction for the starting waypoint
        if start_idx < len(self.waypoints):
            start_wp = self.waypoints[start_idx]
            approach_dir = self.get_heading_direction_from_class(heading_class)
            self.approach_directions[start_wp['name']] = approach_dir
            self.robot_approach_heading = heading_class
        
        print(f"Path planned through {len(self.current_path)} waypoints")
        print(f"Starting from waypoint: {self.waypoints[start_idx]['name']} (heading-constrained)")
        print(f"Approach direction: {self.approach_directions.get(self.waypoints[start_idx]['name'], 'unknown')}")
    
    def get_next_command(self, robot_x: float, robot_y: float, robot_heading_class: str) -> Optional[dict]:
        """Get next navigation command - only determines turn direction at waypoints"""
        if not self.current_path or self.current_action_index >= len(self.current_path) - 1:
            return None
        
        current_point = self.current_path[self.current_action_index]
        next_point = self.current_path[self.current_action_index + 1]
        
        # Calculate distance to next waypoint
        distance = math.sqrt((next_point[0] - robot_x)**2 + (next_point[1] - robot_y)**2)
        
        # Debug: Show distance to next waypoint
        print(f"DEBUG: Distance to next waypoint: {distance:.1f}cm (threshold: 15cm)")
        
        # Check if we're at the final target waypoint
        is_final_target = (self.current_action_index == len(self.current_path) - 2 and 
                          self.target_waypoint and 
                          abs(next_point[0] - self.target_waypoint['world_x']) < 0.1 and 
                          abs(next_point[1] - self.target_waypoint['world_y']) < 0.1)
        
        # If we're at the final target and within 15cm, handle based on mode
        if is_final_target and distance < 15.0:
            if self.continuous_navigation:
                # In continuous mode, move to next waypoint
                next_waypoint_name = self.get_next_waypoint_for_continuous_mode()
                if next_waypoint_name:
                    print(f"TARGET REACHED: Moving to next waypoint '{next_waypoint_name}' for continuous demo")
                    # Start navigation to next waypoint
                    self.start_navigation_to_waypoint(next_waypoint_name)
                    # Return direction command for next waypoint
                    return {"action": "straight"}
                else:
                    print("No more waypoints available for continuous mode")
                    return {"action": "stop"}
            else:
                print(f"STOP: Robot reached target - stopping navigation")
                self.running = False  # Stop navigation
                return {"action": "stop"}
        
        # Check if we're close to current waypoint (15cm threshold)
        if distance < 15.0:
            # Update previous waypoint tracking
            if self.current_action_index > 0:
                # Find the waypoint we just reached
                for i, wp in enumerate(self.waypoints):
                    if (abs(wp['world_x'] - current_point[0]) < 5.0 and 
                        abs(wp['world_y'] - current_point[1]) < 5.0):
                        self.previous_waypoint = wp['name']
                        break
            
            self.current_action_index += 1
            if self.current_action_index < len(self.current_path) - 1:
                # At waypoint - determine turn direction to next waypoint
                return self.get_turn_command_at_waypoint(robot_x, robot_y, robot_heading_class)
            else:
                # At final waypoint (target) - send Stop action
                return {"action": "stop"}
        else:
            # Not at waypoint yet - provide driving command based on direction
            return self.get_driving_command_to_waypoint(robot_x, robot_y, robot_heading_class, next_point)
    
    def get_driving_command_to_waypoint(self, robot_x: float, robot_y: float, robot_heading_class: str, next_point: tuple) -> dict:
        """Determine driving command when robot is far from waypoint"""
        # Calculate direction to next waypoint
        dx = next_point[0] - robot_x
        dy = next_point[1] - robot_y
        required_direction = self.get_direction_to_waypoint(dx, dy)
        
        # Get robot's current direction
        robot_direction = self.get_heading_direction_from_class(robot_heading_class)
        
        # Calculate distance to next waypoint
        distance = math.sqrt(dx**2 + dy**2)
        
        # If robot is facing the right direction, go straight
        if robot_direction == required_direction:
            return {"action": "straight"}
        
        # If robot needs to turn, determine turn direction
        action = self.get_turn_command_from_directions(robot_direction, required_direction)
        
        print(f"Driving to waypoint: Robot facing {robot_direction}, need to go {required_direction}, distance: {distance:.1f}cm, command: {action}")
        return {"action": action}
    
    def get_turn_command_at_waypoint(self, robot_x: float, robot_y: float, robot_heading_class: str) -> dict:
        """Determine turn command when robot reaches a waypoint using categorical heading"""
        if self.current_action_index >= len(self.current_path) - 1:
            return {"action": "stop"}
        
        current_point = self.current_path[self.current_action_index]
        next_point = self.current_path[self.current_action_index + 1]
        
        # Calculate direction to next waypoint
        dx = next_point[0] - current_point[0]
        dy = next_point[1] - current_point[1]
        required_direction = self.get_direction_to_waypoint(dx, dy)
        
        # Get robot's current direction
        robot_direction = self.get_heading_direction_from_class(robot_heading_class)
        
        # Determine turn command based on direction change needed
        action = self.get_turn_command_from_directions(robot_direction, required_direction)
        
        print(f"At waypoint: Robot facing {robot_direction}, need to go {required_direction}, command: {action}")
        return {"action": action}
    
    def normalize_angle(self, angle: float) -> float:
        """Normalize angle to [-180, 180]"""
        while angle > 180:
            angle -= 360
        while angle < -180:
            angle += 360
        return angle
    
    def get_approach_direction(self, robot_x: float, robot_y: float, robot_heading: float, 
                              waypoint_x: float, waypoint_y: float) -> str:
        """
        Determine the approach direction of robot to waypoint based on position and heading.
        Returns: 'north', 'south', 'east', 'west', or 'unknown'
        """
        # Calculate vector from robot to waypoint
        dx = waypoint_x - robot_x
        dy = waypoint_y - robot_y
        
        # Calculate angle from robot to waypoint (0° = North, 90° = East, etc.)
        angle_to_waypoint = math.degrees(math.atan2(dx, dy))
        if angle_to_waypoint < 0:
            angle_to_waypoint += 360
        
        # Determine approach direction based on angle (using 4 cardinal directions only)
        if 315 <= angle_to_waypoint or angle_to_waypoint < 45:
            return 'north'
        elif 45 <= angle_to_waypoint < 135:
            return 'east'
        elif 135 <= angle_to_waypoint < 225:
            return 'south'
        elif 225 <= angle_to_waypoint < 315:
            return 'west'
        else:
            return 'unknown'
    
    def get_heading_direction(self, heading: float) -> str:
        """Convert heading angle to direction string (4 cardinal directions only)"""
        if heading is None:
            return 'unknown'
        
        # Normalize heading to 0-360
        heading = heading % 360
        
        # Map to 4 cardinal directions only
        if 315 <= heading or heading < 45:
            return 'north'
        elif 45 <= heading < 135:
            return 'east'
        elif 135 <= heading < 225:
            return 'south'
        elif 225 <= heading < 315:
            return 'west'
        else:
            return 'unknown'
    
    def get_heading_direction_from_class(self, class_name: str) -> str:
        """Convert heading detector class name to cardinal direction"""
        if class_name == 'rosmaster_r2_north':
            return 'North'
        elif class_name == 'rosmaster_r2_east':
            return 'East'
        elif class_name == 'rosmaster_r2_south':
            return 'South'
        elif class_name == 'rosmaster_r2_west':
            return 'West'
        elif class_name == 'rosmaster_r2_rotation':
            return 'Unknown'
        else:
            return 'Unknown'
    
    def get_direction_to_waypoint(self, dx: float, dy: float) -> str:
        """Calculate cardinal direction from robot to waypoint"""
        if abs(dx) < abs(dy):
            if dy > 0:
                return 'North'  # Fixed: positive Y is North
            else:
                return 'South'  # Fixed: negative Y is South
        else:
            if dx > 0:
                return 'East'
            else:
                return 'West'
    
    def is_waypoint_in_heading_direction(self, robot_direction: str, waypoint_direction: str) -> bool:
        """Check if waypoint is within 45° (half of 90°) of the robot's heading direction"""
        if robot_direction == 'Unknown' or waypoint_direction == 'Unknown':
            return True  # Allow any direction if unknown
        
        # Define direction angles (0° = North, 90° = East, 180° = South, 270° = West)
        direction_angles = {
            'North': 0,
            'East': 90,
            'South': 180,
            'West': 270
        }
        
        robot_angle = direction_angles.get(robot_direction, 0)
        waypoint_angle = direction_angles.get(waypoint_direction, 0)
        
        # Calculate angle difference (accounting for 360° wrap-around)
        angle_diff = abs(robot_angle - waypoint_angle)
        if angle_diff > 180:
            angle_diff = 360 - angle_diff
        
        # Allow waypoints within heading tolerance of robot heading (more precise selection)
        is_within_tolerance = angle_diff <= self.heading_tolerance
        if not is_within_tolerance:
            print(f"DEBUG: Waypoint rejected - angle difference {angle_diff:.1f}° > tolerance {self.heading_tolerance}°")
        return is_within_tolerance
    
    def get_turn_command_from_directions(self, current_direction: str, target_direction: str) -> str:
        """Determine turn command based on current and target directions"""
        if current_direction == 'Unknown' or target_direction == 'Unknown':
            return "straight"  # Default to straight if unknown
        
        if current_direction == target_direction:
            return "straight"
        
        # Define turn relationships
        turn_map = {
            'North': {'East': 'right', 'West': 'left', 'South': 'right'},  # South could be right or left, defaulting to right
            'East': {'South': 'right', 'North': 'left', 'West': 'right'},  # West could be right or left, defaulting to right
            'South': {'West': 'right', 'East': 'left', 'North': 'right'},  # North could be right or left, defaulting to right
            'West': {'North': 'right', 'South': 'left', 'East': 'right'}   # East could be right or left, defaulting to right
        }
        
        return turn_map.get(current_direction, {}).get(target_direction, "straight")
    
    def get_command_icon(self, action: str) -> str:
        """Get visual icon for command action"""
        icon_map = {
            'stop': '⏹',
            'straight': '↑',
            'left': '←',
            'right': '→'
        }
        return icon_map.get(action, '●')
    
    def update_command_history(self, command: dict):
        """Update command history for display - DISABLED"""
        # Command history updates disabled per user request
        pass
    
    def draw_command_history(self, frame):
        """Draw recent command history on frame - DISABLED"""
        # Command history drawing removed per user request
        pass
    
    def get_best_heading_class(self, current_heading_class: str) -> str:
        """Get the best available heading class, using last valid if current is unknown"""
        # If current heading is valid (not rotation/unknown), use it and update history
        if current_heading_class != "rosmaster_r2_rotation":
            self.last_valid_heading_class = current_heading_class
            # Add to history for smoothing
            self.heading_history.append(current_heading_class)
            if len(self.heading_history) > 10:  # Keep last 10 headings
                self.heading_history.pop(0)
            return current_heading_class
        
        # If current heading is unknown, use last valid heading
        if self.last_valid_heading_class != "rosmaster_r2_rotation":
            print(f"WARNING: Heading unknown, using last valid heading: {self.last_valid_heading_class}")
            return self.last_valid_heading_class
        else:
            # If no valid heading history, try to get most common from history
            if self.heading_history:
                most_common = max(set(self.heading_history), key=self.heading_history.count)
                print(f"WARNING: No valid heading, using most common from history: {most_common}")
                return most_common
            else:
                print("WARNING: No heading history available, using default rotation")
                return "rosmaster_r2_rotation"
    
    def calculate_turn_cost(self, from_idx: int, to_idx: int, current_heading_class: str) -> float:
        """Calculate the cost of turning from current heading to reach next waypoint"""
        if from_idx >= len(self.waypoints) or to_idx >= len(self.waypoints):
            return 0.0
        
        # Get waypoint positions
        from_wp = self.waypoints[from_idx]
        to_wp = self.waypoints[to_idx]
        
        # Calculate direction to next waypoint
        dx = to_wp['world_x'] - from_wp['world_x']
        dy = to_wp['world_y'] - from_wp['world_y']
        required_direction = self.get_direction_to_waypoint(dx, dy)
        
        # Get current robot direction
        current_direction = self.get_heading_direction_from_class(current_heading_class)
        
        # Calculate turn cost based on direction change
        if current_direction == 'Unknown' or required_direction == 'Unknown':
            return 0.5  # Moderate cost for unknown directions
        
        if current_direction == required_direction:
            return 0.0  # No turn needed
        
        # Calculate turn cost based on angle difference
        turn_cost_map = {
            'North': {'East': 1.0, 'West': 1.0, 'South': 20.0},  # 180° turn is expensive
            'East': {'South': 1.0, 'North': 1.0, 'West': 20.0},
            'South': {'West': 1.0, 'East': 1.0, 'North': 20.0},
            'West': {'North': 1.0, 'South': 1.0, 'East': 20.0}
        }
        
        return turn_cost_map.get(current_direction, {}).get(required_direction, 1.0)
    
    def get_heading_after_turn(self, from_idx: int, to_idx: int, current_heading_class: str) -> str:
        """Get the heading class after turning to face the next waypoint"""
        if from_idx >= len(self.waypoints) or to_idx >= len(self.waypoints):
            return current_heading_class
        
        # Get waypoint positions
        from_wp = self.waypoints[from_idx]
        to_wp = self.waypoints[to_idx]
        
        # Calculate direction to next waypoint
        dx = to_wp['world_x'] - from_wp['world_x']
        dy = to_wp['world_y'] - from_wp['world_y']
        required_direction = self.get_direction_to_waypoint(dx, dy)
        
        # Convert back to heading class
        direction_to_class = {
            'North': 'rosmaster_r2_north',
            'East': 'rosmaster_r2_east',
            'South': 'rosmaster_r2_south',
            'West': 'rosmaster_r2_west',
            'Unknown': 'rosmaster_r2_rotation'
        }
        
        return direction_to_class.get(required_direction, current_heading_class)
    
    def calculate_optimal_exit_direction(self, approach_direction: str, next_waypoint_direction: str) -> str:
        """
        Calculate the optimal exit direction from current waypoint to next waypoint
        considering the approach direction to prevent backtracking.
        Uses only 4 cardinal directions.
        """
        # Define direction mappings for 4 cardinal directions only
        direction_map = {
            'north': 0, 'east': 90, 'south': 180, 'west': 270
        }
        
        # Get angle values
        approach_angle = direction_map.get(approach_direction, 0)
        next_angle = direction_map.get(next_waypoint_direction, 0)
        
        # Calculate the optimal exit direction
        # We want to go towards the next waypoint, but avoid going back the same way
        angle_diff = next_angle - approach_angle
        
        # Normalize angle difference
        while angle_diff > 180:
            angle_diff -= 360
        while angle_diff < -180:
            angle_diff += 360
        
        # Calculate exit direction
        exit_angle = (approach_angle + angle_diff) % 360
        
        # Convert back to direction string (4 cardinal directions only)
        if 315 <= exit_angle or exit_angle < 45:
            return 'north'
        elif 45 <= exit_angle < 135:
            return 'east'
        elif 135 <= exit_angle < 225:
            return 'south'
        elif 225 <= exit_angle < 315:
            return 'west'
        else:
            return next_waypoint_direction  # Fallback
    
    def is_backtracking(self, current_waypoint_idx: int, next_waypoint_idx: int) -> bool:
        """Check if the robot is trying to go back to the previous waypoint"""
        if self.previous_waypoint is None:
            return False
        
        # Get waypoint names for comparison
        current_wp_name = self.waypoints[current_waypoint_idx]['name']
        next_wp_name = self.waypoints[next_waypoint_idx]['name']
        
        return next_wp_name == self.previous_waypoint
    
    def validate_approach_direction(self, robot_x: float, robot_y: float, robot_heading: float, 
                                   waypoint_idx: int) -> bool:
        """
        Validate that the robot is approaching the waypoint from a reasonable direction.
        Returns True if approach is valid, False if robot should replan.
        """
        if waypoint_idx >= len(self.waypoints):
            return True
        
        waypoint = self.waypoints[waypoint_idx]
        approach_dir = self.get_approach_direction(robot_x, robot_y, robot_heading, 
                                                  waypoint['world_x'], waypoint['world_y'])
        
        # Check if this is a backtracking situation
        if self.is_backtracking(waypoint_idx, waypoint_idx):
            print(f"WARNING: Robot attempting to backtrack to {waypoint['name']}")
            return False
        
        # Store approach direction for this waypoint
        self.approach_directions[waypoint['name']] = approach_dir
        
        print(f"Robot approaching {waypoint['name']} from {approach_dir}")
        return True
    
    def calculate_direction_progress(self, robot_direction: str, target_direction: str) -> float:
        """
        Calculate how much progress the robot is making towards the target direction.
        Returns a value between 0.0 (no progress) and 1.0 (perfect alignment).
        Uses only 4 cardinal directions.
        """
        if robot_direction == 'unknown' or target_direction == 'unknown':
            return 0.5  # Neutral progress for unknown directions
        
        # Define direction mappings for 4 cardinal directions only
        direction_map = {
            'north': 0, 'east': 90, 'south': 180, 'west': 270
        }
        
        robot_angle = direction_map.get(robot_direction, 0)
        target_angle = direction_map.get(target_direction, 0)
        
        # Calculate angle difference
        angle_diff = abs(robot_angle - target_angle)
        if angle_diff > 180:
            angle_diff = 360 - angle_diff
        
        # Convert to progress (0-1 scale)
        # 0° difference = 1.0 progress, 180° difference = 0.0 progress
        progress = 1.0 - (angle_diff / 180.0)
        
        return max(0.0, min(1.0, progress))
    
    def run_with_udp_stream(self, stream_port: int = 5000, show_video: bool = True, 
                           stream_latency: int = 5, confidence_threshold: float = 0.5):
        """Run waypoint-based navigation using UDP video stream"""
        
        # Setup stream configuration
        stream_config = {
            "use_gstreamer": True,
            "port": stream_port,
            "latency": stream_latency
        }
        
        # Open UDP video stream
        cap = open_video_capture(f"udp://{stream_port}", stream_config)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open UDP stream on port {stream_port}")
        
        print(f"Starting waypoint-based navigation (port {stream_port})...")
        print("Features:")
        print("- Uses your calibrated logical waypoints for path planning")
        print("- No numbered path waypoints - only your actual waypoints")
        print("- Real-time robot detection and tracking")
        if self.continuous_navigation:
            print("- CONTINUOUS MODE: Will cycle through all waypoints for demo")
        print()
        print("Press 'q' to quit, 'r' to replan path")
        
        last_print_time = 0.0
        min_print_interval = 0.02  # 20 ms
        
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    print("Failed to read from UDP stream")
                    break
                
                # Increment frame counter
                self.frame_count += 1
                
                # Detect robot position using YOLO
                detection = self.detector.detect_best_robot(frame, min_confidence=0.5)
                
                if detection is not None:
                    centroid_px = detection['position']
                    confidence = detection['confidence']
                    
                    # Apply height compensation if available
                    if self.calib.camera is not None:
                        centroid_px = compensate_for_robot_height(
                            centroid_px, 
                            self.calib.camera, 
                            self.calib.image_width, 
                            self.calib.image_height
                        )
                    
                    # Convert to world coordinates
                    px = np.array([[centroid_px[0], centroid_px[1]]], dtype=np.float64)
                    world_xy = perspective_map_pixels_to_world(px, self.H)[0]
                    
                    # Apply smoothing
                    world_xy = self.ema.update(world_xy)
                    
                    # Store last known position for movement-based heading fallback
                    self.last_known_position = world_xy
                    
                    # Determine heading based on selected method
                    if self.use_movement_heading:
                        # Use ONLY movement-based heading detection
                        movement_heading_class = self.movement_detector.get_smoothed_heading_class(world_xy[0], world_xy[1])
                        movement_heading_angle = self.movement_detector.heading_classes.get(movement_heading_class)
                        
                        print(f"DEBUG Navigation: Movement detector returned: {movement_heading_class} -> {movement_heading_angle}°")
                        
                        # Override detection with movement-based heading
                        detection['heading'] = movement_heading_angle
                        detection['class_name'] = movement_heading_class
                        heading = movement_heading_angle
                        class_name = movement_heading_class
                        
                        print(f"DEBUG: Using movement-based heading ONLY: {movement_heading_class} ({movement_heading_angle}°)")
                    else:
                        # Use YOLO-based heading detection
                        heading = detection['heading']
                        class_name = detection['class_name']
                        print(f"DEBUG: Using YOLO-based heading: {class_name} ({heading}°)")
                    
                    # Print location and heading to terminal
                    now = time.time()
                    if now - last_print_time >= min_print_interval:
                        heading_str = f"{heading:.1f}°" if heading is not None else "unknown"
                        print(f"X={world_xy[0]:.1f} cm, Y={world_xy[1]:.1f} cm, Heading={heading_str} ({class_name})")
                        last_print_time = now
                    
                    # Get best available heading class (use last valid if current is unknown)
                    best_heading_class = self.get_best_heading_class(class_name)
                    
                    # Update navigation with heading class
                    self.update_robot_position(world_xy[0], world_xy[1], best_heading_class)
                    
                    # Get next command
                    command = self.get_next_command(world_xy[0], world_xy[1], best_heading_class)
                    
                    # DEBUG: Always print debug info
                    heading_str = f"{heading:.1f}°" if heading is not None else "unknown"
                    print(f"DEBUG: Robot at ({world_xy[0]:.1f}, {world_xy[1]:.1f}), heading={heading_str}")
                    print(f"DEBUG: Using heading class: {best_heading_class} (detected: {class_name})")
                    print(f"DEBUG: Current path length: {len(self.current_path) if self.current_path else 0}")
                    print(f"DEBUG: Action index: {self.current_action_index}")
                    print(f"DEBUG: Running: {self.running}, Target: {self.target_waypoint['name'] if self.target_waypoint else 'None'}")
                    
                    if command:
                        # Update command history
                        self.update_command_history(command)
                        
                        # Simple debug output for turn commands only
                        print(f"Command: {command['action']}")
                        
                        # Send command via UDP only every 30 frames
                        if self.udp_socket and (self.frame_count % self.udp_send_interval == 0):
                            # Determine status based on command type
                            if command['action'] == "stop":
                                status = "stopped"
                            else:
                                status = "navigating"
                            
                            # Convert heading to cardinal direction
                            heading_direction = self.get_heading_direction_from_class(class_name)
                            
                            payload = {
                                "type": "navigation_status",
                                "robot_position": {"x": world_xy[0], "y": world_xy[1]},
                                "heading": heading_direction,
                                "command": command['action']
                            }
                            send_detection_udp(payload, self.udp_ip, self.udp_port, self.udp_socket)
                    else:
                        print("DEBUG: No command generated - check path planning and waypoint setup")
                        # Still send status information even when no command
                        if self.udp_socket and (self.frame_count % self.udp_send_interval == 0):
                            # Determine status based on navigation state
                            if not self.running:
                                status = "stopped"
                            else:
                                status = "idle"
                            
                            # Convert heading to cardinal direction
                            heading_direction = self.get_heading_direction_from_class(class_name)
                            
                            payload = {
                                "type": "navigation_status",
                                "robot_position": {"x": world_xy[0], "y": world_xy[1]},
                                "heading": heading_direction,
                                "command": None
                            }
                            send_detection_udp(payload, self.udp_ip, self.udp_port, self.udp_socket)
                            
                    
                    # Draw robot position and heading
                    cv2.circle(frame, (int(centroid_px[0]), int(centroid_px[1])), 8, (0, 0, 255), -1)
                    
                    # Draw heading arrow
                    if heading is not None:
                        arrow_length = 30
                        end_x = int(centroid_px[0] + arrow_length * np.sin(np.radians(heading)))
                        end_y = int(centroid_px[1] - arrow_length * np.cos(np.radians(heading)))
                        cv2.arrowedLine(frame, (int(centroid_px[0]), int(centroid_px[1])), 
                                      (end_x, end_y), (0, 255, 0), 3, tipLength=0.3)
                    
                    # Draw robot info
                    heading_str = f"{heading:.1f}°" if heading is not None else "unknown"
                    cv2.putText(
                        frame,
                        f"Robot: ({world_xy[0]:.1f}, {world_xy[1]:.1f}) cm",
                        (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 0, 255),
                        2
                    )
                    cv2.putText(
                        frame,
                        f"Heading: {heading_str} ({class_name})",
                        (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 255, 0),
                        2
                    )
                    
                    # Draw current command with enhanced display
                    if command:
                        # Create command display with action text only (no icon)
                        command_text = command['action'].upper()
                        
                        # Choose color and background based on command type
                        if command['action'] == 'stop':
                            text_color = (255, 255, 255)  # White text
                            bg_color = (0, 0, 255)  # Red background
                            border_color = (0, 0, 200)  # Darker red border
                        elif command['action'] == 'straight':
                            text_color = (0, 0, 0)  # Black text
                            bg_color = (0, 255, 0)  # Green background
                            border_color = (0, 200, 0)  # Darker green border
                        elif command['action'] in ['left', 'right']:
                            text_color = (0, 0, 0)  # Black text
                            bg_color = (255, 255, 0)  # Yellow background
                            border_color = (200, 200, 0)  # Darker yellow border
                        else:
                            text_color = (255, 255, 255)  # White text
                            bg_color = (128, 128, 128)  # Gray background
                            border_color = (100, 100, 100)  # Darker gray border
                        
                        # Draw command background with border
                        text_size = cv2.getTextSize(command_text, cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2)[0]
                        padding = 10
                        x1, y1 = 10, 90
                        x2, y2 = x1 + text_size[0] + 2*padding, y1 + text_size[1] + 2*padding
                        
                        # Draw border
                        cv2.rectangle(frame, (x1-2, y1-2), (x2+2, y2+2), border_color, -1)
                        # Draw background
                        cv2.rectangle(frame, (x1, y1), (x2, y2), bg_color, -1)
                        # Draw text
                        cv2.putText(
                            frame,
                            command_text,
                            (x1 + padding, y1 + text_size[1] + padding),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            1.0,
                            text_color,
                            2
                        )
                        
                        # Removed: Additional command description
                        # Removed: Status indicator display
                    else:
                        # No command - show idle status
                        idle_text = "⏸ IDLE - No Command"
                        cv2.putText(
                            frame,
                            idle_text,
                            (10, 90),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.8,
                            (128, 128, 128),
                            2
                        )
                else:
                    # No YOLO detection - but if using movement heading, try to continue with last known position
                    if self.use_movement_heading and hasattr(self, 'last_known_position'):
                        # Use last known position for movement-based heading
                        world_xy = self.last_known_position
                        movement_heading_class = self.movement_detector.get_smoothed_heading_class(world_xy[0], world_xy[1])
                        movement_heading_angle = self.movement_detector.heading_classes.get(movement_heading_class)
                        
                        # Create a minimal detection object for movement-based heading
                        detection = {
                            'position': (0, 0),  # Dummy position since we don't have visual detection
                            'heading': movement_heading_angle,
                            'class_name': movement_heading_class,
                            'confidence': 0.0
                        }
                        heading = movement_heading_angle
                        class_name = movement_heading_class
                        
                        print(f"DEBUG: No YOLO detection - using movement-based heading: {movement_heading_class} ({movement_heading_angle}°)")
                        
                        # Continue with navigation using movement-based heading
                        # (The rest of the navigation logic will be executed below)
                    else:
                        # No detection and not using movement heading - show no detection status
                        if show_video:
                            self.draw_static_elements(frame)
                            
                            # Draw no detection status
                            no_detection_text = "⚠ NO DETECTION - Waiting for robot"
                            cv2.putText(
                                frame,
                                no_detection_text,
                                (10, 90),
                                cv2.FONT_HERSHEY_SIMPLEX,
                                0.8,
                                (0, 0, 255),  # Red text
                                2
                            )
                            
                            cv2.imshow("Waypoint-Based Navigation", frame)
                            if (cv2.waitKey(1) & 0xFF) == 27:
                                break
                        continue
                
                # Draw all visual elements
                self.draw_static_elements(frame)
                self.draw_waypoint_path(frame)
                
                if show_video:
                    cv2.imshow("Waypoint-Based Navigation", frame)
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord('q'):
                        break
                    elif key == ord('r'):
                        # Replan path
                        if self.running:
                            self.current_action_index = 0
                            print("Path replanned!")
                
        finally:
            cap.release()
            if show_video:
                cv2.destroyAllWindows()
            if self.udp_socket:
                self.udp_socket.close()
    
    def draw_static_elements(self, frame):
        """Draw static elements (waypoints, target)"""
        # Draw all waypoints
        for i, waypoint in enumerate(self.waypoints):
            pixel_x, pixel_y = self.world_to_pixel_camera_compensated(
                waypoint['world_x'], waypoint['world_y'], 0.0
            )
            
            if 0 <= pixel_x < frame.shape[1] and 0 <= pixel_y < frame.shape[0]:
                # Draw waypoint circle
                cv2.circle(frame, (pixel_x, pixel_y), 8, waypoint['color'], -1)
                cv2.circle(frame, (pixel_x, pixel_y), 4, (255, 255, 255), -1)
                
                # Draw waypoint number
                cv2.putText(frame, str(i + 1), (pixel_x - 5, pixel_y + 5), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2)
                
                # Draw waypoint name
                cv2.putText(frame, waypoint['name'], (pixel_x + 10, pixel_y - 10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, waypoint['color'], 1)
        
        # Draw target if set
        if self.target_waypoint:
            target_px = self.world_to_pixel_camera_compensated(
                self.target_waypoint['world_x'], self.target_waypoint['world_y'], 0.0
            )
            
            if 0 <= target_px[0] < frame.shape[1] and 0 <= target_px[1] < frame.shape[0]:
                # Draw target marker (large green circle)
                cv2.circle(frame, target_px, 15, (0, 255, 0), -1)
                cv2.circle(frame, target_px, 8, (255, 255, 255), -1)
                
                # Draw crosshairs
                cv2.line(frame, 
                       (target_px[0] - 20, target_px[1]), 
                       (target_px[0] + 20, target_px[1]), 
                       (0, 255, 0), 2)
                cv2.line(frame, 
                       (target_px[0], target_px[1] - 20), 
                       (target_px[0], target_px[1] + 20), 
                       (0, 255, 0), 2)
                
                # Draw target label
                cv2.putText(frame, "TARGET", (target_px[0] + 20, target_px[1]), 
                          cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    
    def draw_waypoint_path(self, frame):
        """Draw path through waypoints (no numbered intermediate points)"""
        if len(self.current_path) > 1:
            path_points_px = []
            for world_x, world_y in self.current_path:
                pixel_x, pixel_y = self.world_to_pixel_camera_compensated(world_x, world_y, 0.0)
                if 0 <= pixel_x < frame.shape[1] and 0 <= pixel_y < frame.shape[0]:
                    path_points_px.append((pixel_x, pixel_y))
            
            # Draw path lines (magenta)
            for i in range(len(path_points_px) - 1):
                cv2.line(frame, path_points_px[i], path_points_px[i + 1], (255, 0, 255), 3)
            
            # Draw waypoints on path (only the actual waypoints, no numbers)
            for i, (px, py) in enumerate(path_points_px):
                if i == 0:  # Robot position
                    cv2.circle(frame, (px, py), 6, (0, 0, 255), -1)  # Red for robot
                elif i == len(path_points_px) - 1:  # Target
                    cv2.circle(frame, (px, py), 6, (0, 255, 0), -1)  # Green for target
                else:  # Intermediate waypoints
                    cv2.circle(frame, (px, py), 6, (255, 255, 0), -1)  # Yellow for intermediate


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Waypoint-based navigation for robots that can't turn on the spot")
    parser.add_argument("--calibration", required=True, help="Calibration file path")
    parser.add_argument("--waypoints", required=True, help="Waypoints file path")
    parser.add_argument("--target-waypoint", required=True, help="Target waypoint name")
    parser.add_argument("--stream-port", type=int, default=5000, help="UDP stream port")
    parser.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer")
    parser.add_argument("--model", default="model_car_heading.pt", help="YOLO model path")
    parser.add_argument("--udp-ip", default="127.0.0.1", help="UDP target IP for robot commands")
    parser.add_argument("--udp-port", type=int, default=50001, help="UDP target port for robot commands")
    parser.add_argument("--no-show", action="store_true", help="Don't show video window")
    parser.add_argument("--heading-tolerance", type=float, default=22.5, 
                       help="Heading tolerance in degrees for waypoint selection (default: 22.5°)")
    parser.add_argument("--udp-send-interval", type=int, default=30,
                       help="Send UDP packets every N frames (default: 30)")
    parser.add_argument("--continuous", action="store_true",
                       help="Enable continuous navigation mode for demo - robot will cycle through waypoints without stopping")
    parser.add_argument("--use-movement-heading", action="store_true",
                       help="Use movement-based heading detection instead of YOLO-based heading detection")
    
    args = parser.parse_args()
    
    # Create navigation runner with heading tolerance and UDP settings
    runner = WaypointBasedNavigation(args.calibration, args.waypoints, args.model, args.heading_tolerance, args.udp_ip, args.udp_port, args.udp_send_interval, args.continuous, args.use_movement_heading)
    
    print(f"Using heading tolerance: {args.heading_tolerance}°")
    print(f"Waypoints must be within {args.heading_tolerance}° of robot heading to be selected")
    print("Robot will go to nearest waypoint in its heading direction first")
    if args.use_movement_heading:
        print("MOVEMENT-BASED HEADING ENABLED: Robot heading determined by movement direction (North/South/East/West)")
    else:
        print("YOLO-BASED HEADING ENABLED: Robot heading determined by YOLO model detection")
    if args.continuous:
        print("CONTINUOUS MODE ENABLED: Robot will cycle through all waypoints for demo presentation")
    
    # Start navigation to waypoint
    if runner.start_navigation_to_waypoint(args.target_waypoint):
        # Run with UDP stream
        runner.run_with_udp_stream(
            stream_port=args.stream_port,
            show_video=not args.no_show,
            stream_latency=args.stream_latency
        )


if __name__ == "__main__":
    main()
