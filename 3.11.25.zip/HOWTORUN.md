# ====================================================================================================
# SETUP GUIDE - GETTING STARTED ON A NEW MACHINE
# ====================================================================================================

## Platform-Specific Setup Guides

- **Windows**: Follow instructions below (setup_env.bat)
- **Mac (M-series / Apple Silicon)**: See **[MAC_M_SERIES_SETUP.md](MAC_M_SERIES_SETUP.md)** for detailed installation guide
  - Quick start: Run `./install_mac_prerequisites.sh` then `./setup_env.sh`
  - Includes ARM64 optimization, MPS GPU acceleration, and troubleshooting
- **Linux**: Use `setup_env.sh` (similar to Mac)

## Quick Start: Python Environment Setup

### Windows

**First time setup (recommended): Use a virtual environment to isolate dependencies**

```cmd
# Create and activate virtual environment
setup_env.bat

# This will:
# 1. Create a virtual environment (venv/)
# 2. Install all required packages
# 3. Make your setup portable to new machines

# For detailed instructions, see VENV_SETUP.md
```

After virtual environment is created, activate it before running:
```cmd
venv\Scripts\activate

# Then run your commands normally
python start.py [options]
```

**Already have a virtual environment?**
```cmd
# Just activate it
venv\Scripts\activate
```

### Mac / Linux

```bash
# First, install prerequisites (Mac only - includes Homebrew, GStreamer, etc.)
./install_mac_prerequisites.sh  # Mac only

# Then setup virtual environment
./setup_env.sh

# Activate virtual environment
source venv/bin/activate

# Run your program
python start.py [options]
```

# ====================================================================================================
# Setting Up OpenCV and GStreamer DLL Paths
# ====================================================================================================

When running on a new machine, you need to configure the OpenCV and GStreamer DLL paths.

### Option 1: Set Environment Variable (Recommended)
```bash
# Set the AMEC base directory environment variable
set AMEC_BASE_DIR=C:\path\to\your\AMEC\installation
# Example:
set AMEC_BASE_DIR=C:\Users\igombala\Desktop\AMEC\AMEC
```

Or set it permanently in Windows:
1. Open System Properties → Environment Variables
2. Add `AMEC_BASE_DIR` with your AMEC installation path

### Option 2: Auto-Detection (Fallback)
The system will automatically try to detect common locations:
- Original location: `C:\Users\Mys\Desktop\AMEC\AMEC`
- New user location: `C:\Users\igombala\Desktop\AMEC\AMEC`
- Relative paths from the script directory

### Option 3: Modify config.py
Edit `config.py` and update the default base directory:

```python
base_dir = r'C:\Users\igombala\Desktop\AMEC\AMEC'  # Change this to your path
```

### Verify Setup
The system will print messages indicating whether DLL paths were found:
- `[OK] Added OpenCV DLL path: ...` - Success
- `[WARNING] OpenCV DLL path not found: ...` - Needs configuration

# ====================================================================================================
# CALIBRATION GUIDE - HOW TO CALIBRATE WHEN TRAVELING TO NEW LOCATIONS
# ====================================================================================================

## Quick Calibration for New Location

### 1. Enhanced Calibration (Better Accuracy)
```bash
python localization.py calibrate \
    --source udp://5000 \
    --use-gstreamer \
    --map-width-cm 305.0 \
    --map-height-cm 268.0 \
    --camera-height-cm 195.0 \
    --camera-angle-degrees 42.0 \
    --robot-height-cm 5.0 \
    --out enhanced_calibration.json
```
OR (single line version)
```bash
python localization.py calibrate --source udp://5000 --use-gstreamer --map-width-cm 305.0 --map-height-cm 268.0 --camera-height-cm 195.0     --camera-angle-degrees 42.0 --robot-height-cm 5.0 --out enhanced_calibration.json
```

**Steps:**
1. A window opens showing your camera feed
2. Click 4 corners **in this exact order**: Bottom-Left, Bottom-Right, Top-Right, Top-Left
3. As you click, each point will be numbered (1, 2, 3, 4) on the screen
4. After clicking all 4 corners, calibration completes automatically and saves to the output file
5. Press **ESC** to cancel if needed

**Note:** The corners define the mapping between camera pixels and real-world coordinates. Make sure to click the actual corners of your track/arena boundaries.



### 2. Adjust Waypoints for New Arena

Waypoint calibration is built into the navigation system. Run navigation and use interactive calibration:

```bash
python start.py --nav-only --fps 10 --target-waypoint Parking --nav-udp-ip 127.0.0.1 --nav-udp-port 50001
```

**Steps:**
1. A window opens showing your camera feed with navigation system
2. Press **'c'** to enter waypoint calibration mode
3. Click on each waypoint position in the window (system cycles through waypoints automatically)
4. After all waypoints are adjusted (you'll see a completion message), press **'s'** to save
5. Press **'c'** again to exit calibration mode
6. Press **'q'** to quit

**Additional Navigation Controls:**
- **'m'** - Enter/exit map corners calibration mode (adjusts the 4 corner points for homography)
- **'T'** - Target change mode (click to set new navigation target)
- **'s'** - Save current calibration (waypoints or map corners)
- **'q'** - Quit

**Note:** Waypoints are automatically saved to your calibration file (`enhanced_calibration.json`). The system cycles through all waypoints in order and automatically saves when you complete a full cycle.


### 3. Verify Calibration
```bash
python start.py --target-waypoint Parking
```

### 4. Parking Zone Calibration

Parking zones are calibrated using the parking detection system:

```bash
python parking_detection.py --calibration enhanced_calibration.json --stream-port 5002 --stream-latency 5
```

OR using start.py:
```bash
python start.py --parking-only --fps 10 --parking-udp-ip 127.0.0.1 --parking-udp-port 50002
```

**Steps:**
1. A window opens showing your camera feed with parking detection
2. Press **'c'** to enter calibration mode
3. Press **'n'** to add a new parking zone (auto-named as Zone_1, Zone_2, etc.)
4. Click **twice** to define the rectangular zone:
   - First click: Start point (one corner of the rectangle)
   - Second click: End point (opposite corner of the rectangle)
5. Repeat steps 3-4 to add more zones
6. Press **'e'** to edit/rename the last added zone (cycles through common names)
7. Press **'s'** to save all parking zones to calibration file
8. Press **'c'** again to exit calibration mode
9. Press **'q'** to quit

**Additional Parking Controls:**
- **'r'** - Reset all parking zones (clears all zones from memory)
- **'l'** - Reload parking zones from calibration file
- **'s'** - Save parking zones to calibration file (`enhanced_calibration.json`)

**Note:** Parking zones are saved as rectangular areas defined by two corner points in world coordinates. The zones are automatically detected for car occupancy during normal operation.


## Important Parameters:
- `--map-width-cm`: Physical width of your track in cm (e.g., 305.0)
- `--map-height-cm`: Physical height of your track in cm (e.g., 268.0)
- `--source`: `udp://PORT` for UDP stream, `0` for webcam
- `--use-gstreamer`: Required for UDP streams (use with `--source udp://PORT`)
- `--camera-height-cm`: Camera height above ground in cm (for height compensation, e.g., 195.0)
- `--camera-angle-degrees`: Camera tilt angle from vertical (e.g., 42.0)
- `--robot-height-cm`: Robot height in cm (for height compensation, e.g., 5.0)
- `--out`: Output calibration file path (default: `calibration.json`, use `enhanced_calibration.json` for full system)

## Calibration File Structure

The unified calibration file (`enhanced_calibration.json`) contains:
- **Homography matrix**: Maps image pixels to world coordinates (from corner calibration)
- **Camera configuration**: Height, angle, robot height (for height compensation)
- **Waypoints**: Navigation waypoints with names and world coordinates (from waypoint calibration)
- **Parking zones**: Rectangular parking zones with names and world coordinates (from parking calibration)

All calibration data is stored in a single file, making it easy to transfer between locations.

# ====================================================================================================
# RUNNING COMMANDS
# ====================================================================================================

## Default Command (27.10.25 Updated)

**Full system (Navigation + Parking, without Object Detection):**
```bash
python start.py --fps 10 --udp-send-interval 10 --source-port 5000 --object-source-port 6000 --nav-port 5001 --parking-port 5002 --object-port 5003 --nav-udp-ip 192.168.0.105 --nav-udp-port 50001 --parking-udp-ip 192.168.0.105 --parking-udp-port 50002 --object-udp-ip 192.168.0.105 --object-udp-port 50003 --confidence 0.9 --target-waypoint Parking --no-object-detection --continuous
```

**Full system with all modules (Navigation + Parking + Object Detection):**
```bash
python start.py --fps 10 --udp-send-interval 10 --source-port 5000 --object-source-port 6000 --nav-port 5001 --parking-port 5002 --object-port 5003 --nav-udp-ip 192.168.0.105 --nav-udp-port 50001 --parking-udp-ip 192.168.0.105 --parking-udp-port 50002 --object-udp-ip 192.168.0.105 --object-udp-port 50003 --confidence 0.9 --target-waypoint Parking --continuous
```

## Running Individual Systems (Updated 27.10.25)

You can now run individual systems independently. This is useful for testing or when you only need specific functionality:

**Navigation only:**
```bash
python start.py --nav-only --fps 10 --target-waypoint Parking --nav-udp-ip 192.168.0.105 --nav-udp-port 50001 --continuous
```

**Parking detection only:**
```bash
python start.py --parking-only --fps 10 --parking-udp-ip 192.168.0.105 --parking-udp-port 50002
```

**Object detection only:**
```bash
python start.py --object-only --fps 10 --object-source-port 6000 --object-udp-ip 192.168.0.105 --object-udp-port 50003
```

**Note:** 
- When using `--object-only`, object detection uses the `--object-source-port` for its input stream (separate from navigation stream)
- When running combined systems, navigation and parking share the same source stream via the stream multiplier
- Object detection can either use the multiplier output (when running with nav/parking) or its own separate source (when using `--object-only`)

## start.py Flags Reference

**Stream Configuration (stream multiplicator settings, NOT INPUT STREAM SETTINGS FROM RASPBERRY):**
- `--source-port` - UDP stream source port (default: 5000)
- `--object-source-port` - Object detection source UDP stream port when running in `--object-only` mode (default: 6000) - separate from navigation stream
- `--nav-port` - Navigation stream port (default: 5001)
- `--parking-port` - Parking detection stream port (default: 5002)
- `--object-port` - Object detection stream port (default: 5003)
- `--fps` - Stream frame rate (default: 10)
- `--latency` - Stream latency in ms (default: 5)
- `--bitrate` - Video bitrate in kbps (default: 6000)
- `--udp-send-interval` - Send UDP packets every N frames (default: 1)

**UDP Output Configuration:**
- `--nav-udp-ip` / `--nav-udp-port` - Navigation UDP output
- `--parking-udp-ip` / `--parking-udp-port` - Parking detection UDP output
- `--object-udp-ip` / `--object-udp-port` - Object detection UDP output

**Model & Data Files:**
- `--calibration` - Calibration file (default: enhanced_calibration.json) - contains waypoints and parking zones
- `--model` - Navigation/parking YOLO model (default: model_car_heading.pt)
- `--object-model` - Object detection YOLO model (default: best.pt)

**System Selection:**
- `--nav-only` - Run only navigation system (skip parking and object detection)
- `--parking-only` - Run only parking detection (skip navigation and object detection)
- `--object-only` - Run only object detection (skip navigation and parking)
- `--no-object-detection` - Skip object detection (DEPRECATED - use `--nav-only` or `--parking-only` instead)

**Behavior:**
- `--target-waypoint` - Target waypoint for navigation (default: Parking)
- `--confidence` - Detection confidence threshold (default: 0.9)
- `--continuous` - Enable continuous navigation mode for demo (robot cycles through waypoints without stopping)
- `--heading-tolerance` - Heading tolerance in degrees for waypoint selection in navigation (default: 22.5) - passed to navigation.py internally
- `--log-dir` - Log directory (default: logs)

## Key System Features (Updated 27.10.25)

**Heading Detection:**
- Movement-based heading detection is **always enabled** - no flag needed
- Determines robot heading (North/South/East/West) from position changes
- Uses `MovementHeadingDetector` class for robust heading estimation
- Navigation uses `--heading-tolerance` (default: 22.5 degrees) for waypoint selection

**Navigation System:**
- Uses waypoint-based path planning from calibration file
- Supports continuous navigation mode (`--continuous`) for demos
- Integrates movement-based heading with waypoint navigation
- UDP output on configurable IP/port for robot control

**Parking Detection:**
- Detects cars in calibrated parking zones
- Uses same YOLO model as navigation (`model_car_heading.pt`)
- Parking zones defined in calibration file (`enhanced_calibration.json`)
- Sends occupancy status via UDP

**Object Detection:**
- Separate YOLO model (`best.pt`) for general object detection
- Can run independently or alongside navigation/parking
- Sends detection data via UDP with configurable confidence threshold

**Stream Management:**
- `stream_multiplier.py` splits single UDP stream to multiple consumers
- Reduces bandwidth usage by sharing stream across systems
- Configurable FPS, bitrate, and latency
- Object detection can use separate source stream when running independently


