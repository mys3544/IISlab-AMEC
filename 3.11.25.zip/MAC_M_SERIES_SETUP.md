# AMEC Installation Guide for Mac (M-series / Apple Silicon)

This guide provides step-by-step instructions for installing and running AMEC on Mac computers with M1, M2, M3, or later Apple Silicon chips.

## Prerequisites

- **macOS** 12.0 (Monterey) or later
- **Apple Silicon** (M1/M2/M3/M4) Mac
- **Xcode Command Line Tools** (for compiling some dependencies)
- **Homebrew** (recommended package manager)

## Quick Start

```bash
# 1. Install prerequisites
./install_mac_prerequisites.sh

# 2. Setup Python environment
./setup_env.sh

# 3. Activate and run
source venv/bin/activate
python start.py [options]
```

---

## Detailed Installation Steps

### Step 1: Install Homebrew (if not installed)

Homebrew is the easiest way to install system dependencies on Mac:

```bash
# Check if Homebrew is installed
which brew

# If not installed, run:
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Add Homebrew to your PATH (for Apple Silicon)
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
eval "$(/opt/homebrew/bin/brew shellenv)"
```

### Step 2: Install System Dependencies

```bash
# Install Python 3.11+ (recommended for compatibility)
brew install python@3.11

# Install GStreamer (required for UDP video streams)
brew install gstreamer gst-plugins-base gst-plugins-good gst-plugins-bad gst-plugins-ugly

# Install OpenCV via Homebrew (optional - alternative to pip version)
# Note: The pip version (opencv-python) usually works, but Homebrew version is more stable
brew install opencv

# Install Xcode Command Line Tools (required for some Python packages)
xcode-select --install
```

### Step 3: Verify Python Installation

```bash
# Check Python version (should be 3.8+)
python3 --version

# Verify it's running on ARM64 (Apple Silicon native)
python3 -c "import platform; print(f'Architecture: {platform.machine()}')"
# Should output: Architecture: arm64
```

**Important:** Ensure Python is running natively on ARM64, not under Rosetta (x86_64).

### Step 4: Setup Virtual Environment

```bash
# Navigate to AMEC project directory
cd /path/to/AMEC/27.10.25

# Run the setup script
chmod +x setup_env.sh
./setup_env.sh

# The script will:
# - Create a virtual environment
# - Install all Python dependencies
# - Handle Apple Silicon specific configurations
```

### Step 5: Install Python Dependencies (ARM64 Native)

The setup script will automatically install dependencies. However, if you encounter issues, you may need to install PyTorch separately:

#### Install PyTorch with MPS (Metal Performance Shaders) Support

PyTorch with MPS allows GPU acceleration on Apple Silicon:

```bash
# Activate virtual environment
source venv/bin/activate

# Install PyTorch with MPS support (recommended for Apple Silicon)
pip install torch torchvision torchaudio

# Verify MPS is available
python3 -c "import torch; print(f'MPS available: {torch.backends.mps.is_available()}')"
```

**Note:** Ultralytics will automatically use PyTorch if available. MPS support enables GPU acceleration on M-series chips.

### Step 6: Verify Installation

```bash
# Activate virtual environment
source venv/bin/activate

# Test imports
python3 -c "import cv2; print(f'OpenCV version: {cv2.__version__}')"
python3 -c "import numpy; print(f'NumPy version: {numpy.__version__}')"
python3 -c "from ultralytics import YOLO; print('Ultralytics OK')"
python3 -c "import torch; print(f'PyTorch version: {torch.__version__}')"
```

### Step 7: Configure GStreamer Path (if needed)

On Mac, GStreamer is typically installed via Homebrew at `/opt/homebrew/` (Apple Silicon) or `/usr/local/` (Intel).

The system should auto-detect, but if you encounter issues:

```bash
# Check GStreamer installation
brew list gstreamer

# Set environment variable if needed (add to ~/.zprofile or ~/.zshrc)
export GST_PLUGIN_PATH=/opt/homebrew/lib/gstreamer-1.0
export PATH="/opt/homebrew/bin:$PATH"
```

---

## Apple Silicon Specific Considerations

### Architecture Detection

The setup script automatically detects Apple Silicon and installs ARM64-native packages. Check your Python is running natively:

```bash
# Should show 'arm64'
uname -m
python3 -c "import platform; print(platform.machine())"
```

### PyTorch MPS (GPU Acceleration)

Apple Silicon Macs support GPU acceleration via Metal Performance Shaders (MPS). This can significantly speed up YOLO inference:

```python
# Ultralytics will automatically use MPS if available
from ultralytics import YOLO
model = YOLO("model.pt")
results = model(frame, device="mps")  # Use MPS for GPU acceleration
```

**Note:** MPS support was added in PyTorch 1.12+. Ensure you have a recent version.

### Performance Tips

1. **Use MPS for GPU acceleration** (if supported):
   - Faster YOLO inference
   - Better for real-time video processing
   - Automatically enabled if available

2. **Native ARM64 packages**:
   - All packages should be ARM64-native for best performance
   - Avoid Rosetta (x86_64) compatibility mode when possible

3. **Memory considerations**:
   - M-series chips have unified memory
   - May experience better performance with unified memory architecture

### Common Issues and Solutions

#### Issue: "Package not available for arm64"

**Solution:** Some packages may not have ARM64 builds. Use Rosetta only as last resort:

```bash
# Install Rosetta (only if absolutely necessary)
softwareupdate --install-rosetta

# Run Python under Rosetta (not recommended)
arch -x86_64 python3 ...
```

**Better solution:** Wait for ARM64 builds or use alternatives that support ARM64.

#### Issue: "OpenCV/GStreamer not found"

**Solution 1:** Install via Homebrew:
```bash
brew install opencv gstreamer
```

**Solution 2:** Verify paths:
```bash
# Check if OpenCV is in PATH
brew list opencv

# Check GStreamer
which gst-launch-1.0
```

#### Issue: "PyTorch MPS not available"

**Solution:** Update PyTorch to latest version:
```bash
pip install --upgrade torch torchvision torchaudio
```

#### Issue: "NumPy compatibility warnings"

**Solution:** Install NumPy compiled for ARM64:
```bash
pip install --upgrade numpy
# Verify it's ARM64 native
python3 -c "import numpy; import numpy.core._multiarray_umath; print('ARM64 NumPy')"
```

#### Issue: "GStreamer plugins not found"

**Solution:** Install all GStreamer plugins:
```bash
brew install gst-plugins-base gst-plugins-good gst-plugins-bad gst-plugins-ugly
export GST_PLUGIN_PATH=/opt/homebrew/lib/gstreamer-1.0
```

---

## Running AMEC on Mac

After installation, running AMEC is the same as on other platforms:

```bash
# Activate virtual environment
source venv/bin/activate

# Run navigation system
python start.py --nav-only --fps 10 --target-waypoint Parking

# Run full system
python start.py --fps 10 --target-waypoint Parking --continuous
```

### Mac-Specific Notes

1. **Video Display**: OpenCV windows work natively on macOS
2. **Keyboard Controls**: Same as other platforms (q=quit, etc.)
3. **Performance**: M-series chips typically provide excellent performance for computer vision tasks
4. **Terminal**: Use Terminal.app or iTerm2 - both work fine

---

## Verification Checklist

Before running AMEC, verify:

- [ ] Python 3.8+ installed (`python3 --version`)
- [ ] Running on ARM64 (`uname -m` shows `arm64`)
- [ ] Virtual environment created (`ls venv/` exists)
- [ ] Dependencies installed (`pip list` shows opencv-python, numpy, ultralytics)
- [ ] PyTorch with MPS available (optional but recommended)
- [ ] GStreamer installed (`gst-launch-1.0 --version`)
- [ ] OpenCV working (`python3 -c "import cv2; print(cv2.__version__)"`)

---

## Performance Benchmarks (M-series)

Expected performance on M-series Macs:

- **M1**: Good performance, can handle 10-15 FPS video processing
- **M1 Pro/Max**: Excellent performance, 15-30 FPS
- **M2/M2 Pro/M2 Max**: Excellent performance, 20-30+ FPS
- **M3/M3 Pro/M3 Max**: Excellent performance, 25-30+ FPS

**Note:** Actual FPS depends on:
- Model size (YOLO model)
- Video resolution
- Number of concurrent systems running
- Whether MPS (GPU) acceleration is enabled

---

## Troubleshooting

### Check Python Architecture

```bash
# Should output 'arm64'
python3 -c "import platform; print(platform.machine())"
```

### Check Installed Packages

```bash
source venv/bin/activate
pip list | grep -E "(opencv|numpy|ultralytics|torch)"
```

### Test GStreamer

```bash
# Test GStreamer installation
gst-launch-1.0 --version

# Test pipeline (should output video info)
gst-launch-1.0 videotestsrc ! video/x-raw ! fakesink
```

### Test OpenCV with GStreamer

```bash
python3 -c "import cv2; print(f'OpenCV: {cv2.__version__}'); print(f'GStreamer: {cv2.getBuildInformation().count(\"GStreamer\") > 0}')"
```

---

## Additional Resources

- [PyTorch on Apple Silicon](https://developer.apple.com/metal/pytorch/)
- [Homebrew Documentation](https://docs.brew.sh/)
- [GStreamer macOS Installation](https://gstreamer.freedesktop.org/documentation/installing/on-mac-osx.html)

---

## Summary

Installation on Mac M-series is straightforward:

1. ✅ Install Homebrew and system dependencies
2. ✅ Create virtual environment with `setup_env.sh`
3. ✅ Install Python packages (automatically ARM64-native)
4. ✅ Run AMEC as normal

The system automatically detects Apple Silicon and installs appropriate packages. Most issues are resolved by ensuring ARM64-native packages are installed.

---

**Last Updated:** 2025-01-27  
**Tested on:** macOS 14.0+ (Sonoma), M1/M2/M3 Macs

