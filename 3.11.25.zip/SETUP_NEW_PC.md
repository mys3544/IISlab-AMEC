# Setting Up AMEC on the New PC (igombala machine)

## Quick Setup Guide

Your code is now pre-configured for the new machine. Here's what you need to do:

## 1. Python Virtual Environment Setup

**First time on the new machine:**

```cmd
# Navigate to the AMEC project directory
cd C:\Users\igombala\Desktop\AMEC\27.10.25

# Run the setup script
setup_env.bat

# This creates venv/ and installs all Python packages
```

## 2. Directory Structure on New Machine

Make sure your directory structure looks like this:

```
C:\Users\igombala\Desktop\AMEC\
├── opencv-4.12.0\
│   └── build\
│       └── install\
│           └── x64\
│               └── vc17\
│                   └── bin\    (OpenCV DLLs here)
├── gstreamer\
│   └── 1.0\
│       └── msvc_x86_64\
│           └── bin\            (GStreamer DLLs here)
└── 27.10.25\                    (Your AMEC code)
    ├── *.py files
    ├── requirements.txt
    ├── venv\
    └── ...
```

## 3. Activation & Running

**Every time you want to run AMEC:**

```cmd
# Activate virtual environment
venv\Scripts\activate

# Run your program
python start.py --fps 10 --target-waypoint Parking --no-object-detection --continuous

# When done
deactivate
```

## What Was Changed?

✅ **config.py** - Updated to automatically look for DLLs at:
- `C:\Users\igombala\Desktop\AMEC` (primary)
- `C:\Users\igombala\Desktop\AMEC\AMEC` (fallback)
- And several other auto-detection paths

✅ **requirements.txt** - Created with all Python dependencies

✅ **setup_env.bat** - Automated setup script for virtual environment

## No Manual Configuration Needed!

The code will automatically:
1. ✅ Look for OpenCV in `C:\Users\igombala\Desktop\AMEC\opencv-4.12.0\...`
2. ✅ Look for GStreamer in `C:\Users\igombala\Desktop\AMEC\gstreamer\...`
3. ✅ Print messages showing what it found

## Expected Output

When you run the program, you should see:

```
[INFO] Auto-detected AMEC base directory: C:\Users\igombala\Desktop\AMEC
[OK] Added OpenCV DLL path: C:\Users\igombala\Desktop\AMEC\opencv-4.12.0\build\install\x64\vc17\bin
[OK] Added GStreamer DLL path: C:\Users\igombala\Desktop\AMEC\gstreamer\1.0\msvc_x86_64\bin
```

If you see warnings instead of `[OK]` messages, check that the DLL folders exist at those paths.

## Troubleshooting

**Q: "DLL not found" error?**  
A: Make sure OpenCV and GStreamer are installed at `C:\Users\igombala\Desktop\AMEC\`

**Q: Different user name?**  
A: Option 1: Set environment variable:
```cmd
set AMEC_BASE_DIR=C:\Your\Path\Here\AMEC
```
Option 2: Edit `config.py` line 42:
```python
base_dir = r'C:\Your\Path\Here\AMEC'
```

**Q: Multiple AMEC installations?**  
A: The code checks multiple locations in this order:
1. `C:\Users\igombala\Desktop\AMEC`
2. `C:\Users\igombala\Desktop\AMEC\AMEC`
3. `C:\Users\Mys\Desktop\AMEC\AMEC`
4. Relative paths

## Summary

On the new machine, you only need to:
1. ✅ Run `setup_env.bat` once (creates virtual environment)
2. ✅ Activate with `venv\Scripts\activate` before running
3. ✅ Run your program - it will auto-detect everything!

No manual path configuration needed! 🎉
