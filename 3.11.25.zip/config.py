#!/usr/bin/env python3
"""
Configuration management for AMEC system.
Handles OpenCV and GStreamer DLL path setup for portability across machines.
"""

import os
from pathlib import Path


def setup_opencv_gstreamer_paths():
    """
    Setup OpenCV and GStreamer paths from environment or config.
    This allows the code to work on different machines without hardcoded paths.
    """
    # Try to get base directory from environment variable
    # If not set, attempt to find it relative to the current script location
    base_dir = os.getenv('AMEC_BASE_DIR')
    
    if not base_dir:
        # Try to auto-detect common locations
        script_dir = Path(__file__).parent.absolute()
        
        # Check if we're in a parent AMEC directory structure
        potential_paths = [
            Path("C:\\Users\\igombala\\Desktop\\AMEC"),  # New user location (primary)
            Path("C:\\Users\\igombala\\Desktop\\AMEC\\AMEC"),  # New user location with subfolder
            Path("C:\\Users\\Mys\\Desktop\\AMEC\\AMEC"),  # Original location
            script_dir.parent.parent,  # Try relative to script (../../AMEC)
            Path("AMEC"),  # Check for AMEC folder in current directory
        ]
        
        for path in potential_paths:
            opencv_check = path / 'opencv-4.12.0' / 'build' / 'install' / 'x64' / 'vc17' / 'bin'
            if opencv_check.exists():
                base_dir = str(path)
                print(f"[INFO] Auto-detected AMEC base directory: {base_dir}")
                break
    
    if not base_dir:
        # Default fallback location (updated for new machine)
        base_dir = r'C:\Users\igombala\Desktop\AMEC'
        print(f"[WARNING] Using default base directory: {base_dir}")
        print("[INFO] To override, set environment variable: AMEC_BASE_DIR")
    
    # Construct DLL paths
    base = Path(base_dir)
    opencv_dll = base / 'opencv-4.12.0' / 'build' / 'install' / 'x64' / 'vc17' / 'bin'
    gst_dll = base / 'gstreamer' / '1.0' / 'msvc_x86_64' / 'bin'
    
    # Add DLL directories if they exist
    if opencv_dll.exists():
        os.add_dll_directory(str(opencv_dll))
        print(f"[OK] Added OpenCV DLL path: {opencv_dll}")
    else:
        print(f"[WARNING] OpenCV DLL path not found: {opencv_dll}")
        print(f"[INFO] To fix: Set environment variable AMEC_BASE_DIR to your AMEC installation directory")
    
    if gst_dll.exists():
        os.add_dll_directory(str(gst_dll))
        print(f"[OK] Added GStreamer DLL path: {gst_dll}")
    else:
        print(f"[WARNING] GStreamer DLL path not found: {gst_dll}")
        print(f"[INFO] To fix: Set environment variable AMEC_BASE_DIR to your AMEC installation directory")
