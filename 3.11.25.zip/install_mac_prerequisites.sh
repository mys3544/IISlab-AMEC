#!/bin/bash
# Prerequisites installation script for Mac (Apple Silicon)

echo "============================================================"
echo "AMEC Mac Prerequisites Installation (Apple Silicon)"
echo "============================================================"
echo ""

# Check if running on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "[ERROR] This script is for macOS only"
    exit 1
fi

# Detect architecture
ARCH=$(uname -m)
echo "[INFO] Detected architecture: $ARCH"

if [[ "$ARCH" != "arm64" ]]; then
    echo "[WARNING] Not running on Apple Silicon (arm64)"
    echo "[WARNING] This script is optimized for M-series Macs"
    echo "[WARNING] Some packages may need Intel (x86_64) versions"
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Check for Homebrew
if ! command -v brew &> /dev/null; then
    echo "[INFO] Homebrew not found. Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    
    # Add Homebrew to PATH for Apple Silicon
    if [[ "$ARCH" == "arm64" ]]; then
        echo "[INFO] Adding Homebrew to PATH..."
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
else
    echo "[OK] Homebrew is installed"
    brew --version
fi

# Check for Python 3
if ! command -v python3 &> /dev/null; then
    echo "[INFO] Python 3 not found. Installing via Homebrew..."
    brew install python@3.11
else
    PYTHON_VERSION=$(python3 --version)
    echo "[OK] Python 3 is installed: $PYTHON_VERSION"
    
    # Verify it's ARM64
    PYTHON_ARCH=$(python3 -c "import platform; print(platform.machine())" 2>/dev/null)
    if [[ "$PYTHON_ARCH" == "arm64" ]]; then
        echo "[OK] Python is running natively on ARM64"
    else
        echo "[WARNING] Python is not running on ARM64 (detected: $PYTHON_ARCH)"
        echo "[WARNING] Performance may be suboptimal. Consider reinstalling Python."
    fi
fi

# Check for Xcode Command Line Tools
if ! xcode-select -p &> /dev/null; then
    echo "[INFO] Xcode Command Line Tools not found. Installing..."
    xcode-select --install
    echo "[INFO] Please complete the Xcode Command Line Tools installation in the dialog that opened"
    read -p "Press Enter after completing Xcode Command Line Tools installation..."
else
    echo "[OK] Xcode Command Line Tools are installed"
fi

# Install GStreamer
if ! command -v gst-launch-1.0 &> /dev/null; then
    echo "[INFO] GStreamer not found. Installing via Homebrew..."
    brew install gstreamer gst-plugins-base gst-plugins-good gst-plugins-bad gst-plugins-ugly
else
    echo "[OK] GStreamer is installed"
    gst-launch-1.0 --version
fi

# Install OpenCV (optional - pip version usually works)
echo "[INFO] OpenCV will be installed via pip in virtual environment"
echo "[INFO] Homebrew version is optional but can be installed for system-wide use:"
read -p "Install OpenCV via Homebrew? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    brew install opencv
fi

# Set up GStreamer environment variables
if [[ "$ARCH" == "arm64" ]]; then
    GSTREAMER_PATH="/opt/homebrew/lib/gstreamer-1.0"
else
    GSTREAMER_PATH="/usr/local/lib/gstreamer-1.0"
fi

if [ -d "$GSTREAMER_PATH" ]; then
    echo "[INFO] Setting up GStreamer environment variables..."
    
    # Check if already in shell config
    if ! grep -q "GST_PLUGIN_PATH" ~/.zprofile 2>/dev/null && ! grep -q "GST_PLUGIN_PATH" ~/.zshrc 2>/dev/null; then
        echo "" >> ~/.zprofile
        echo "# GStreamer plugin path for AMEC" >> ~/.zprofile
        echo "export GST_PLUGIN_PATH=$GSTREAMER_PATH" >> ~/.zprofile
        echo "[OK] Added GST_PLUGIN_PATH to ~/.zprofile"
    else
        echo "[OK] GST_PLUGIN_PATH already configured"
    fi
fi

echo ""
echo "============================================================"
echo "[OK] Prerequisites installation complete!"
echo "============================================================"
echo ""
echo "Next steps:"
echo "1. If you added environment variables, restart your terminal or run:"
echo "   source ~/.zprofile"
echo ""
echo "2. Run the setup script to create virtual environment:"
echo "   ./setup_env.sh"
echo ""
echo "3. Activate virtual environment and run AMEC:"
echo "   source venv/bin/activate"
echo "   python start.py [options]"
echo ""

