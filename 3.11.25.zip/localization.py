"""
Camera-based localization system using YOLO object detection and homography transformation.

This module provides tools to:
1. Calibrate a camera by selecting corner points in the image and mapping them to world coordinates
2. Detect objects using YOLO models
3. Transform pixel coordinates to real-world coordinates using homography
4. Send detection data via UDP for real-time tracking
"""

import argparse
import json
import socket
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple, Any

from config import setup_opencv_gstreamer_paths
setup_opencv_gstreamer_paths()
import cv2
import numpy as np


# ==========================
# Data structures
# ==========================


@dataclass
class WorldConfig:
    """
    Configuration for the world/ground plane coordinate system.
    
    Attributes:
        world_width_cm: Width of the world space in centimeters
        world_height_cm: Height of the world space in centimeters
        origin: Coordinate system origin location (fixed to "bottom_left")
    """
    world_width_cm: float
    world_height_cm: float
    origin: str = "bottom_left"  # fixed per user requirement


@dataclass
class CameraConfig:
    """
    Configuration for camera geometry used in height compensation calculations.
    
    Attributes:
        height_cm: Camera height above the ground plane in centimeters
        angle_degrees: Camera tilt angle from vertical (0 = looking straight down, 
                      positive values = camera tilted forward/downward)
        robot_height_cm: Height of the robot being tracked (used to compensate 
                        for 3D bounding box vs ground position)
    """
    height_cm: float  # Camera height above ground
    angle_degrees: float  # Camera angle from vertical (0 = looking straight down)
    robot_height_cm: float  # Height of the robot being tracked


@dataclass
class Calibration:
    """
    Stores calibration data including homography matrix for pixel-to-world transformation.
    
    The homography matrix transforms 2D image coordinates to 2D world coordinates,
    allowing us to map detected object positions from the camera view to real-world locations.
    
    Attributes:
        homography: 3x3 transformation matrix for perspective transformation
        image_width: Width of the input images in pixels
        image_height: Height of the input images in pixels
        world: World coordinate system configuration
        camera: Optional camera geometry configuration for height compensation
        waypoints: Optional list of navigation waypoints
        parking_zones: Optional list of parking zones
    """
    homography: np.ndarray
    image_width: int
    image_height: int
    world: WorldConfig
    camera: Optional[CameraConfig] = None
    waypoints: Optional[List[dict]] = None
    parking_zones: Optional[List[dict]] = None

    def to_dict(self) -> dict:
        """
        Convert calibration data to a dictionary for JSON serialization.
        
        Returns:
            Dictionary containing all calibration data that can be saved to JSON
        """
        result = {
            "homography": self.homography.tolist(),  # Convert numpy array to list for JSON
            "image_width": self.image_width,
            "image_height": self.image_height,
            "world": {
                "world_width_cm": self.world.world_width_cm,
                "world_height_cm": self.world.world_height_cm,
                "origin": self.world.origin,
            },
        }
        # Include camera config only if it exists
        if self.camera is not None:
            result["camera"] = {
                "height_cm": self.camera.height_cm,
                "angle_degrees": self.camera.angle_degrees,
                "robot_height_cm": self.camera.robot_height_cm,
            }
        # Include waypoints if they exist
        if self.waypoints is not None:
            result["waypoints"] = self.waypoints
        # Include parking zones if they exist
        if self.parking_zones is not None:
            result["parking_zones"] = self.parking_zones
        return result

    @staticmethod
    def from_dict(data: dict) -> "Calibration":
        """
        Create a Calibration object from a dictionary (loaded from JSON).
        
        Args:
            data: Dictionary containing calibration data
            
        Returns:
            Calibration object reconstructed from the dictionary
        """
        # Convert homography list back to numpy array
        H = np.array(data["homography"], dtype=np.float64)
        
        # Reconstruct world configuration
        world = WorldConfig(
            world_width_cm=float(data["world"]["world_width_cm"]),
            world_height_cm=float(data["world"]["world_height_cm"]),
            origin=str(data["world"].get("origin", "bottom_left")),  # Default to bottom_left if not specified
        )
        
        # Reconstruct camera config if present
        camera = None
        if "camera" in data:
            camera = CameraConfig(
                height_cm=float(data["camera"]["height_cm"]),
                angle_degrees=float(data["camera"]["angle_degrees"]),
                robot_height_cm=float(data["camera"]["robot_height_cm"]),
            )
        
        # Extract waypoints if present
        waypoints = data.get("waypoints")
        
        # Extract parking zones if present
        parking_zones = data.get("parking_zones")
        
        return Calibration(
            homography=H,
            image_width=int(data["image_width"]),
            image_height=int(data["image_height"]),
            world=world,
            camera=camera,
            waypoints=waypoints,
            parking_zones=parking_zones,
        )


# ==========================
# Utility functions
# ==========================


def create_stream_config(port: int, latency: int = 5, use_gstreamer: bool = True) -> dict:
    """
    Create a standardized stream configuration dictionary.
    
    Args:
        port: UDP stream port number
        latency: Stream latency buffer in milliseconds
        use_gstreamer: Whether to use GStreamer pipeline
        
    Returns:
        Dictionary with stream configuration
    """
    return {
        "use_gstreamer": use_gstreamer,
        "port": port,
        "latency": latency
    }


def open_video_capture(source: str, stream_config: Optional[dict] = None) -> cv2.VideoCapture:
    """
    Open a video capture source (camera, file, or UDP stream).
    
    Supports:
    - Webcam/camera: integer index (e.g., "0") or video file path
    - UDP streams: "udp://port" format or via stream_config with GStreamer
    
    Args:
        source: Video source identifier (camera index, file path, or UDP URL)
        stream_config: Optional dict with GStreamer settings (port, latency, use_gstreamer)
        
    Returns:
        OpenCV VideoCapture object
        
    Raises:
        RuntimeError: If the video source cannot be opened
    """
    # Handle GStreamer pipeline for UDP streams
    if source.startswith("udp://") or (stream_config and stream_config.get("use_gstreamer", False)):
        # Extract port and latency settings
        if stream_config:
            port = stream_config.get("port", 5000)
            latency = stream_config.get("latency", 5)
        else:
            # Extract port from udp:// format if stream_config not provided
            port = source.split("://")[1] if "://" in source else "5000"
            latency = 5
        
        # Build GStreamer pipeline for H.264 RTP stream
        # This pipeline: receives UDP RTP -> buffers -> depayloads H.264 -> decodes -> converts to BGR
        gst_pipeline = (
            f'udpsrc port={port} '  # Listen on UDP port
            'caps="application/x-rtp, media=video, encoding-name=H264, payload=96, clock-rate=90000" ! '
            f'rtpjitterbuffer latency={latency} ! '  # Buffer to handle network jitter
            'rtph264depay ! '  # Extract H.264 from RTP packets
            'h264parse ! '  # Parse H.264 stream
            'avdec_h264 ! '  # Decode H.264 to raw video
            'videoconvert ! video/x-raw,format=BGR ! '  # Convert to BGR format (OpenCV standard)
            'appsink drop=false sync=false'  # Output to OpenCV
        )
        cap = cv2.VideoCapture(gst_pipeline, cv2.CAP_GSTREAMER)
    else:
        # Handle regular camera/file sources (webcam, video files)
        try:
            # Try to interpret source as integer camera index
            source_index = int(source)
            cap = cv2.VideoCapture(source_index)
        except ValueError:
            # Source is a string (likely a file path or URL)
            cap = cv2.VideoCapture(source)
    
    # Verify that the capture was successfully opened
    if not cap.isOpened():
        raise RuntimeError(f"Unable to open video source: {source}")
    return cap


def save_calibration(calib: Calibration, path: Path, merge: bool = False) -> None:
    """
    Save calibration data to a JSON file.
    
    Args:
        calib: Calibration object to save
        path: File path where calibration will be saved (JSON format)
        merge: If True and file exists, merge with existing data (preserve waypoints/zones if not in calib)
    """
    # Create parent directories if they don't exist
    path.parent.mkdir(parents=True, exist_ok=True)
    
    # If merging and file exists, load existing data first
    existing_data = {}
    if merge and path.exists():
        try:
            with path.open("r", encoding="utf-8") as f:
                existing_data = json.load(f)
        except Exception:
            pass  # If loading fails, just overwrite
    
    # Get new data
    new_data = calib.to_dict()
    
    # Merge if requested: preserve existing waypoints/zones if not in new data
    if merge and existing_data:
        if "waypoints" in existing_data and "waypoints" not in new_data:
            new_data["waypoints"] = existing_data["waypoints"]
        if "parking_zones" in existing_data and "parking_zones" not in new_data:
            new_data["parking_zones"] = existing_data["parking_zones"]
    
    with path.open("w", encoding="utf-8") as f:
        json.dump(new_data, f, indent=2)  # Pretty-print with 2-space indent


def load_calibration(path: Path) -> Calibration:
    """
    Load calibration data from a JSON file.
    
    Args:
        path: File path to load calibration from
        
    Returns:
        Calibration object loaded from the file
    """
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    return Calibration.from_dict(data)


def compute_homography_from_corners(
    image_points: List[Tuple[float, float]],
    world_width_cm: float,
    world_height_cm: float,
) -> np.ndarray:
    """
    Compute a homography matrix from 4 corner point correspondences.
    
    The image points must be in order: bottom-left, bottom-right, top-right, top-left (BL, BR, TR, TL).
    These correspond to the four corners of the ground plane visible in the camera image.
    
    Args:
        image_points: List of 4 (x, y) pixel coordinates from the image, in order [BL, BR, TR, TL]
        world_width_cm: Width of the world coordinate system in centimeters
        world_height_cm: Height of the world coordinate system in centimeters
        
    Returns:
        3x3 homography matrix that transforms image coordinates to world coordinates
        
    Raises:
        ValueError: If exactly 4 points are not provided
        RuntimeError: If homography computation fails
    """
    if len(image_points) != 4:
        raise ValueError("Exactly 4 image points are required: BL, BR, TR, TL")

    # Define world coordinates in centimeters with origin at bottom-left
    # Order: [bottom-left, bottom-right, top-right, top-left]
    world_points = np.array(
        [
            [0.0, 0.0],                      # Bottom-left corner
            [world_width_cm, 0.0],           # Bottom-right corner
            [world_width_cm, world_height_cm],  # Top-right corner
            [0.0, world_height_cm],          # Top-left corner
        ],
        dtype=np.float64,
    )

    # Convert image points to numpy array and compute homography
    # RANSAC method helps handle any measurement errors or slight misalignments
    img_pts = np.array(image_points, dtype=np.float64)
    H, status = cv2.findHomography(img_pts, world_points, method=cv2.RANSAC)
    if H is None:
        raise RuntimeError("Homography computation failed")
    return H


def perspective_map_pixels_to_world(points_px: np.ndarray, H: np.ndarray) -> np.ndarray:
    """
    Transform pixel coordinates to world coordinates using a homography matrix.
    
    Args:
        points_px: Array of pixel coordinates, shape (N, 2) where each row is (x, y)
        H: 3x3 homography transformation matrix
        
    Returns:
        Array of world coordinates in centimeters, shape (N, 2) where each row is (x, y)
    """
    # Ensure correct shape and type in one step
    if points_px.ndim == 1:
        points_px = points_px.reshape(1, -1)
    points_px = points_px.reshape(-1, 1, 2).astype(np.float64, copy=False)
    # Apply perspective transformation and reshape in one step
    return cv2.perspectiveTransform(points_px, H).reshape(-1, 2)


def perspective_map_world_to_pixels(points_world: np.ndarray, H_inv: np.ndarray) -> np.ndarray:
    """
    Transform world coordinates to pixel coordinates using inverse homography matrix.
    
    Args:
        points_world: Array of world coordinates, shape (N, 2) where each row is (x, y) in cm
        H_inv: 3x3 inverse homography transformation matrix
        
    Returns:
        Array of pixel coordinates, shape (N, 2) where each row is (x, y)
    """
    if points_world.ndim == 1:
        points_world = points_world.reshape(1, -1)
    points_world = points_world.reshape(-1, 1, 2).astype(np.float64, copy=False)
    return cv2.perspectiveTransform(points_world, H_inv).reshape(-1, 2)


def world_to_pixel_camera_compensated(
    world_x: float, world_y: float, H_inv: np.ndarray,
    camera_config: Optional[CameraConfig] = None, 
    image_width: int = 0, image_height: int = 0,
    object_height_cm: float = 0.0
) -> Tuple[int, int]:
    """
    Convert world coordinates to pixel coordinates with optional camera height compensation.
    
    Args:
        world_x: World X coordinate in cm
        world_y: World Y coordinate in cm
        H_inv: Inverse homography matrix (cached for performance)
        camera_config: Optional camera configuration for height compensation
        image_width: Image width in pixels
        image_height: Image height in pixels
        object_height_cm: Object height for compensation
        
    Returns:
        Tuple of (pixel_x, pixel_y) as integers
    """
    pixel_x, pixel_y = perspective_map_world_to_pixels(
        np.array([[world_x, world_y]]), H_inv
    )[0]
    
    # Apply camera compensation if available
    if camera_config is not None and object_height_cm > 0:
        angle_rad = np.radians(camera_config.angle_degrees)
        focal_length_px = max(image_width, image_height)
        pixel_y -= (object_height_cm / camera_config.height_cm) * focal_length_px * np.sin(angle_rad)
    
    return int(pixel_x), int(pixel_y)


def get_centroid_from_bbox_xyxy(x1: float, y1: float, x2: float, y2: float) -> Tuple[float, float]:
    """Calculate the center point (centroid) of a bounding box."""
    return (x1 + x2) * 0.5, (y1 + y2) * 0.5


def compensate_for_robot_height(
    centroid_px: Tuple[float, float], 
    camera_config: CameraConfig,
    image_width: int,
    image_height: int
) -> Tuple[float, float]:
    """
    Compensate for robot height by adjusting the bounding box center to represent
    the ground position instead of the center of the 3D bounding box.
    
    Args:
        centroid_px: (x, y) pixel coordinates of bounding box center
        camera_config: Camera configuration with height and angle info
        image_width: Image width in pixels
        image_height: Image height in pixels
    
    Returns:
        Adjusted (x, y) pixel coordinates representing ground position
    """
    if camera_config is None:
        return centroid_px
    
    cx, cy = centroid_px
    
    # Convert angle to radians
    angle_rad = np.radians(camera_config.angle_degrees)
    
    # Calculate the vertical offset due to robot height
    # This is a simplified model assuming the camera is looking down at an angle
    # The actual calculation would depend on the specific camera geometry
    
    # For a camera looking down at an angle, the robot height causes a shift
    # in the image plane. The shift is proportional to the robot height and
    # the camera angle.
    
    # Calculate the effective focal length (approximate)
    # This is a rough estimate - in practice you'd want to calibrate this
    focal_length_px = max(image_width, image_height)  # Rough approximation
    
    # Calculate the vertical shift due to robot height
    # The robot height causes the bounding box center to appear higher in the image
    # than the actual ground position
    height_offset_px = (camera_config.robot_height_cm / camera_config.height_cm) * focal_length_px * np.sin(angle_rad)
    
    # Adjust the y-coordinate to move the center down to ground level
    adjusted_cy = cy + height_offset_px
    
    return cx, adjusted_cy


def send_detection_udp(payload: dict, target_ip: str, target_port: int, udp_sock: socket.socket) -> None:
    """
    Send detection data as JSON over UDP to a target address.
    
    Args:
        payload: Dictionary containing detection data (bounding box, position, etc.)
        target_ip: IP address to send UDP packet to
        target_port: Port number to send UDP packet to
        udp_sock: UDP socket object (must be already created and bound)
    """
    try:
        # Serialize dictionary to JSON string, then encode to bytes
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        udp_sock.sendto(data, (target_ip, target_port))
    except Exception as e:
        print(f"[UDP] send error: {e}")


# ==========================
# Calibration via manual clicks
# ==========================


class ClickCollector:
    """
    Helper class to collect mouse click coordinates for interactive calibration.
    
    Used during calibration to track user clicks on the video frame.
    """
    def __init__(self, required_points: int) -> None:
        self.required_points = required_points
        self.collected: List[Tuple[int, int]] = []  # List of (x, y) pixel coordinates

    def mouse_callback(self, _event, x, y, flags, param) -> None:  # type: ignore[override]
        """
        OpenCV mouse callback function called when mouse events occur.
        
        Args:
            _event: OpenCV mouse event type (only uses EVENT_LBUTTONDOWN)
            x, y: Mouse coordinates in the window
            flags: Mouse button flags (unused)
            param: Optional parameter (unused)
        """
        if _event == cv2.EVENT_LBUTTONDOWN:  # Left mouse button pressed
            self.collected.append((x, y))


def calibrate_corners_interactive(
    source: str,
    world_width_cm: float,
    world_height_cm: float,
    stream_config: Optional[dict] = None,
    camera_height_cm: Optional[float] = None,
    camera_angle_degrees: Optional[float] = None,
    robot_height_cm: Optional[float] = None,
) -> Calibration:
    """
    Interactive calibration by clicking 4 corner points on the video frame.
    
    The user clicks on the four corners of the ground plane in this order:
    1. Bottom-left (BL)
    2. Bottom-right (BR)
    3. Top-right (TR)
    4. Top-left (TL)
    
    Args:
        source: Video source (camera index, file, or UDP stream)
        world_width_cm: Width of the ground plane in centimeters
        world_height_cm: Height of the ground plane in centimeters
        stream_config: Optional GStreamer configuration for UDP streams
        camera_height_cm: Optional camera height for height compensation
        camera_angle_degrees: Optional camera angle for height compensation
        robot_height_cm: Optional robot height for height compensation
        
    Returns:
        Calibration object with computed homography matrix
        
    Raises:
        RuntimeError: If frame capture fails
        KeyboardInterrupt: If user presses ESC to cancel
    """
    # Open video source and capture initial frame
    cap = open_video_capture(source, stream_config)
    ok, frame = cap.read()
    if not ok:
        cap.release()
        raise RuntimeError("Failed to capture initial frame for calibration")

    # Setup interactive window and mouse callback
    window_name = "Select corners: BL, BR, TR, TL (ESC to cancel)"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    collector = ClickCollector(required_points=4)
    cv2.setMouseCallback(window_name, collector.mouse_callback)

    # Interactive loop: display frame and collect clicks
    while True:
        frame_copy = frame.copy()
        # Draw all collected points on the frame with numbers
        for idx, (px, py) in enumerate(collector.collected):
            cv2.circle(frame_copy, (px, py), 6, (0, 255, 0), -1)  # Green filled circle
            cv2.putText(
                frame_copy,
                str(idx + 1),  # Point number (1, 2, 3, 4)
                (px + 8, py - 8),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),  # Green text
                2,
                cv2.LINE_AA,
            )
        cv2.imshow(window_name, frame_copy)
        key = cv2.waitKey(20) & 0xFF  # Wait 20ms for keypress
        if key == 27:  # ESC key pressed - cancel calibration
            cap.release()
            cv2.destroyWindow(window_name)
            raise KeyboardInterrupt("Calibration cancelled")
        if len(collector.collected) >= 4:  # All 4 points collected
            break

    # Cleanup window and capture
    cv2.destroyWindow(window_name)
    cap.release()

    # Compute homography from collected points
    image_points = [tuple(map(float, p)) for p in collector.collected[:4]]
    H = compute_homography_from_corners(image_points, world_width_cm, world_height_cm)
    h, w = frame.shape[:2]  # Get image dimensions
    
    # Create camera config if all height compensation parameters are provided
    camera_config = None
    if all(param is not None for param in [camera_height_cm, camera_angle_degrees, robot_height_cm]):
        camera_config = CameraConfig(
            height_cm=camera_height_cm,
            angle_degrees=camera_angle_degrees,
            robot_height_cm=robot_height_cm
        )
    
    # Return complete calibration object
    return Calibration(
        homography=H, 
        image_width=w, 
        image_height=h, 
        world=WorldConfig(world_width_cm, world_height_cm),
        camera=camera_config
    )


# ==========================
# YOLO runner (Ultralytics)
# ==========================


class YoloDetector:
    """
    YOLO object detector wrapper using Ultralytics YOLO models.
    
    This class handles loading a YOLO model and detecting objects in frames,
    returning the centroid of detected bounding boxes.
    """
    def __init__(self, model_path: str, target_class: Optional[str] = None, device: Optional[str] = None) -> None:
        """
        Initialize the YOLO detector.
        
        Args:
            model_path: Path to the YOLO model file (.pt format)
            target_class: Optional class name to filter detections (e.g., "car", "person")
                         If None, uses the most confident detection regardless of class
            device: Optional device for inference ("cpu", "0" for GPU 0, "cuda", etc.)
                   If None, YOLO will auto-select the device
        """
        from ultralytics import YOLO  # lazy import (only import when needed)

        self.model = YOLO(model_path)  # Load YOLO model
        self.target_class = target_class  # Optional class filter
        self.device = device  # Optional device specification

    def detect_first_centroid(self, frame_bgr: Optional[np.ndarray] = None, results: Optional[Any] = None) -> Optional[Tuple[float, float]]:
        """
        Detect objects and return the centroid of the first/most relevant detection.
        
        Detection selection logic:
        1. If target_class is specified, returns the first detection matching that class
        2. Otherwise, returns the detection with the highest confidence score
        
        Args:
            frame_bgr: Input frame in BGR format (numpy array, shape: [H, W, 3])
                       Only used if results is None. If results is provided, this is ignored.
            results: Optional pre-computed YOLO results to avoid duplicate inference.
                     If provided, frame_bgr is ignored.
            
        Returns:
            Tuple of (center_x, center_y) pixel coordinates if detection found, else None
        """
        # Use pre-computed results if provided, otherwise run inference
        if results is None:
            if frame_bgr is None:
                return None
            results = self.model(frame_bgr, verbose=False, device=self.device)
        
        if not results:
            return None
        result = results[0]  # Get first (and typically only) result

        # Check if any detections were found
        if result.boxes is None or len(result.boxes) == 0:
            return None

        b = result.boxes  # Shortcut for boxes
        # Extract class IDs from detection boxes
        classes = None
        if hasattr(b, "cls") and b.cls is not None:
            try:
                classes = b.cls.cpu().numpy().astype(int)  # Convert to numpy array of integers
            except Exception:
                classes = None  # Fallback if extraction fails

        # Get class name mapping (e.g., {0: "car", 1: "person", ...})
        names = result.names if hasattr(result, "names") else {}

        # Choose the best detection based on target class or confidence
        best_index = None
        if self.target_class is not None and classes is not None:
            # If target class specified, find first matching detection
            for i, c in enumerate(classes):
                class_name = names.get(int(c), str(int(c)))  # Get class name or use ID as fallback
                if class_name == self.target_class:
                    best_index = i
                    break

        if best_index is None:
            # Fallback: use the detection with highest confidence
            conf = b.conf.cpu().numpy() if hasattr(b, "conf") and b.conf is not None else None
            best_index = int(np.argmax(conf)) if conf is not None else 0  # Get index of max confidence

        # Extract bounding box coordinates and compute centroid
        x1, y1, x2, y2 = b.xyxy[best_index].cpu().numpy().tolist()  # [left, top, right, bottom]
        return get_centroid_from_bbox_xyxy(x1, y1, x2, y2)


# ==========================
# Smoothing
# ==========================


class ExponentialMovingAverage:
    """
    Exponential Moving Average (EMA) filter for smoothing noisy position measurements.
    
    EMA provides a simple way to smooth position data over time, reducing jitter
    from detection noise while still responding to real movement.
    
    Formula: smoothed_value = alpha * new_value + (1 - alpha) * previous_smoothed_value
    
    Higher alpha (closer to 1.0) = more responsive, less smoothing
    Lower alpha (closer to 0.0) = more smoothing, slower response
    """
    def __init__(self, alpha: float) -> None:
        """
        Initialize the EMA filter.
        
        Args:
            alpha: Smoothing factor between 0.0 and 1.0
                  - 0.0 = maximum smoothing (output never changes)
                  - 1.0 = no smoothing (output equals input)
                  - Typical values: 0.2-0.5 for moderate smoothing
        """
        self.alpha = float(alpha)
        self.value: Optional[np.ndarray] = None  # Current smoothed value (None before first update)

    def update(self, new_value: np.ndarray) -> np.ndarray:
        """
        Update the smoothed value with a new measurement.
        
        Args:
            new_value: New measurement to incorporate (numpy array, typically shape [2] for x,y)
            
        Returns:
            Updated smoothed value (same shape as new_value)
        """
        if self.value is None:
            # First update: initialize with the new value
            self.value = new_value.astype(np.float64)
        else:
            # EMA update: blend new value with previous smoothed value
            self.value = self.alpha * new_value + (1.0 - self.alpha) * self.value
        return self.value


# ==========================
# Helper functions
# ==========================


def show_frame_and_check_exit(window_name: str, frame: np.ndarray) -> bool:
    """Display a frame and check if user pressed ESC to exit."""
    cv2.imshow(window_name, frame)
    return (cv2.waitKey(1) & 0xFF) == 27


def process_udp_detections(
    result, detector: YoloDetector, calib: Calibration, H: np.ndarray,
    args: argparse.Namespace, udp_sock: socket.socket, frame: np.ndarray
) -> bool:
    """Process all detections for UDP transmission. Returns True if any detections were sent."""
    if not (result.boxes and len(result.boxes) > 0):
        return False
    
    sent_any = False
    names = detector.model.names
    
    for box in result.boxes:
        conf = float(box.conf[0])
        if conf < args.confidence_threshold:
            continue
        
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        label = names[int(box.cls[0])]
        centroid = get_centroid_from_bbox_xyxy(x1, y1, x2, y2)
        
        # Apply height compensation if available
        if calib.camera is not None:
            centroid = compensate_for_robot_height(
                centroid, calib.camera, calib.image_width, calib.image_height
            )
        
        # Transform to world coordinates
        world_xy = perspective_map_pixels_to_world(
            np.array([[centroid[0], centroid[1]]], dtype=np.float64), H
        )[0]
        
        # Send UDP payload
        send_detection_udp({
            "x1": x1, "y1": y1, "x2": x2, "y2": y2,
            "label": label,
            "confidence": conf,
            "world_x": float(world_xy[0]),
            "world_y": float(world_xy[1])
        }, args.udp_ip, args.udp_port, udp_sock)
        sent_any = True
        
        # Draw visualization
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(frame, f"{label} {conf:.2f}", (x1, max(y1 - 10, 20)),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    
    return sent_any


# ==========================
# Commands
# ==========================


def cmd_calibrate(args: argparse.Namespace) -> None:
    """
    Command handler for calibration mode.
    
    Runs interactive calibration where the user clicks 4 corner points
    to establish the mapping between image coordinates and world coordinates.
    
    Args:
        args: Parsed command-line arguments for calibration
        
    Raises:
        NotImplementedError: If calibration method other than 'corners' is requested
    """
    if args.method != "corners":
        raise NotImplementedError("Only 'corners' calibration is implemented in this version")

    # Setup stream configuration for UDP streams if GStreamer is enabled
    stream_config = None
    if args.use_gstreamer:
        stream_config = create_stream_config(args.stream_port, args.stream_latency)

    # Run interactive calibration
    calib = calibrate_corners_interactive(
        source=args.source,
        world_width_cm=args.map_width_cm,
        world_height_cm=args.map_height_cm,
        stream_config=stream_config,
        camera_height_cm=getattr(args, 'camera_height_cm', None),  # Optional height compensation params
        camera_angle_degrees=getattr(args, 'camera_angle_degrees', None),
        robot_height_cm=getattr(args, 'robot_height_cm', None),
    )
    # Save calibration to file
    save_calibration(calib, Path(args.out))
    print(f"Saved calibration to {args.out}")


def cmd_run(args: argparse.Namespace) -> None:
    """
    Command handler for localization/跟踪 mode (main processing loop).
    
    This function:
    1. Loads calibration data
    2. Opens video source (camera/file/UDP stream)
    3. Runs YOLO object detection on each frame
    4. Transforms pixel coordinates to world coordinates using homography
    5. Optionally sends detection data via UDP
    6. Optionally displays visualization with position overlay
    7. Supports runtime corner calibration (press 'c' to calibrate)
    
    Args:
        args: Parsed command-line arguments for run mode
    """
    # Load calibration data from file
    calib = load_calibration(Path(args.calib))
    
    # Setup stream configuration for UDP streams if GStreamer is enabled
    stream_config = None
    if args.use_gstreamer:
        stream_config = create_stream_config(args.stream_port, args.stream_latency)
    
    # Open video capture source (camera, file, or UDP stream)
    cap = open_video_capture(args.source, stream_config)

    # Initialize YOLO detector and optional EMA smoother
    detector = YoloDetector(model_path=args.model, target_class=args.cls, device=args.device)
    ema = ExponentialMovingAverage(alpha=args.ema_alpha) if args.ema_alpha is not None else None

    # Extract homography matrix for coordinate transformation
    H = calib.homography.astype(np.float64)

    # Setup UDP socket for sending detection data (if enabled)
    udp_sock = None
    if args.udp_enabled:
        udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # UDP socket for data transmission

    # Runtime calibration state
    calibration_mode = False
    corner_collector = ClickCollector(required_points=4)
    calibration_callback_set = False
    
    # Setup window and mouse callback for calibration if showing
    if args.show:
        window_name = "localization"
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        
        def mouse_callback(event, x, y, flags, param):
            if calibration_mode and event == cv2.EVENT_LBUTTONDOWN:
                corner_collector.mouse_callback(event, x, y, flags, param)
        
        cv2.setMouseCallback(window_name, mouse_callback)
        calibration_callback_set = True

    # Throttle console output to avoid flooding (print at most every 20ms)
    last_print_time = 0.0
    min_print_interval = 0.02  # 20 ms = 50 updates per second max

    # Main processing loop: process each video frame
    while True:
        # Read next frame from video source
        ok, frame = cap.read()
        if not ok:
            break  # End of video or capture error

        # Run YOLO detection on the frame once
        # Results will be reused for both UDP transmission and primary target tracking
        results = detector.model(frame, verbose=False)
        
        # Handle calibration mode even when no detection
        if args.show and calibration_mode:
            # Draw calibration points
            for idx, (px, py) in enumerate(corner_collector.collected):
                cv2.circle(frame, (px, py), 6, (0, 255, 0), -1)
                cv2.putText(frame, str(idx + 1), (px + 8, py - 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)
            remaining = 4 - len(corner_collector.collected)
            if remaining > 0:
                cv2.putText(frame, f"CALIBRATION MODE: Click {remaining} more corner(s) (BL, BR, TR, TL)",
                           (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            else:
                cv2.putText(frame, "CALIBRATION MODE: All 4 corners collected! Press 's' to save, 'r' to reset",
                           (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            # Handle keyboard for calibration even without detection
            key = cv2.waitKey(1) & 0xFF
            if key == 27:
                break
            elif key == ord('c'):
                calibration_mode = not calibration_mode
                if calibration_mode:
                    corner_collector.collected.clear()
                    print("Calibration mode: ON - Click 4 corners in order: BL, BR, TR, TL")
                else:
                    print("Calibration mode: OFF")
            elif key == ord('s') and calibration_mode and len(corner_collector.collected) == 4:
                try:
                    image_points = [tuple(map(float, p)) for p in corner_collector.collected[:4]]
                    new_H = compute_homography_from_corners(
                        image_points, calib.world.world_width_cm, calib.world.world_height_cm
                    )
                    calib.homography = new_H
                    H = new_H.astype(np.float64)
                    save_calibration(calib, Path(args.calib), merge=True)
                    print(f"Calibration saved to {args.calib}")
                    calibration_mode = False
                    corner_collector.collected.clear()
                except Exception as e:
                    print(f"Error saving calibration: {e}")
            elif key == ord('r') and calibration_mode:
                corner_collector.collected.clear()
                print("Calibration points reset")
            cv2.imshow("localization", frame)
            continue
        
        if not results:
            # No detections found - just display frame if visualization enabled
            if args.show:
                if show_frame_and_check_exit("localization", frame):
                    break
            continue
            
        result = results[0]
        # Get centroid of the primary target using pre-computed results to avoid duplicate inference
        centroid_px = detector.detect_first_centroid(results=results)
        
        # Apply height compensation to adjust for robot's 3D height vs ground position
        # This corrects the bounding box center to represent ground position rather than box center
        if centroid_px is not None and calib.camera is not None:
            centroid_px = compensate_for_robot_height(
                centroid_px, 
                calib.camera, 
                calib.image_width, 
                calib.image_height
            )
        
        # Process UDP transmission if enabled
        if args.udp_enabled and udp_sock:
            sent_any = process_udp_detections(result, detector, calib, H, args, udp_sock, frame)
            if not sent_any:
                send_detection_udp({
                    "x1": 0, "y1": 0, "x2": 0, "y2": 0,
                    "label": "Nothing",
                    "confidence": 0.0,
                    "world_x": 0.0,
                    "world_y": 0.0
                }, args.udp_ip, args.udp_port, udp_sock)

        # If no primary target detected, skip coordinate transformation
        if centroid_px is None:
            # Nothing detected this frame - just display if visualization enabled
            if args.show:
                if show_frame_and_check_exit("localization", frame):
                    break
            continue

        # Transform primary target's pixel coordinates to world coordinates
        world_xy = perspective_map_pixels_to_world(
            np.array([centroid_px], dtype=np.float64), H
        )[0]
        
        # Apply exponential moving average smoothing to reduce jitter
        if ema is not None:
            world_xy = ema.update(world_xy)

        # Print position to console (throttled to avoid flooding)
        now = time.time()
        if now - last_print_time >= min_print_interval:
            print(f"X={world_xy[0]:.1f} cm, Y={world_xy[1]:.1f} cm")
            last_print_time = now

        # Display visualization if enabled
        if args.show:
            x_cm, y_cm = float(world_xy[0]), float(world_xy[1])
            # Draw red circle at detected centroid
            cv2.circle(frame, (int(centroid_px[0]), int(centroid_px[1])), 6, (0, 0, 255), -1)
            # Draw world coordinates text next to the centroid
            cv2.putText(
                frame,
                f"({x_cm:.1f}, {y_cm:.1f}) cm",
                (int(centroid_px[0]) + 8, int(centroid_px[1]) - 8),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),  # Red text
                2,
                cv2.LINE_AA,
            )
            
            # Draw calibration points and handle calibration mode
            if calibration_mode:
                # Draw all collected corner points
                for idx, (px, py) in enumerate(corner_collector.collected):
                    cv2.circle(frame, (px, py), 6, (0, 255, 0), -1)  # Green filled circle
                    cv2.putText(
                        frame,
                        str(idx + 1),  # Point number (1, 2, 3, 4)
                        (px + 8, py - 8),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 255, 0),  # Green text
                        2,
                        cv2.LINE_AA,
                    )
                # Show calibration instructions
                remaining = 4 - len(corner_collector.collected)
                if remaining > 0:
                    cv2.putText(
                        frame,
                        f"CALIBRATION MODE: Click {remaining} more corner(s) (BL, BR, TR, TL)",
                        (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 255, 255),  # Cyan
                        2,
                    )
                else:
                    cv2.putText(
                        frame,
                        "CALIBRATION MODE: All 4 corners collected! Press 's' to save, 'r' to reset",
                        (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 255, 0),  # Green
                        2,
                    )
            
            # Handle keyboard input
            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC
                break
            elif key == ord('c'):
                # Toggle calibration mode
                calibration_mode = not calibration_mode
                if calibration_mode:
                    corner_collector.collected.clear()
                    print("Calibration mode: ON - Click 4 corners in order: BL, BR, TR, TL")
                else:
                    print("Calibration mode: OFF")
            elif key == ord('s') and calibration_mode and len(corner_collector.collected) == 4:
                # Save new calibration
                try:
                    image_points = [tuple(map(float, p)) for p in corner_collector.collected[:4]]
                    new_H = compute_homography_from_corners(
                        image_points, calib.world.world_width_cm, calib.world.world_height_cm
                    )
                    calib.homography = new_H
                    H = new_H.astype(np.float64)  # Update current H
                    save_calibration(calib, Path(args.calib), merge=True)
                    print(f"Calibration saved to {args.calib}")
                    calibration_mode = False
                    corner_collector.collected.clear()
                except Exception as e:
                    print(f"Error saving calibration: {e}")
            elif key == ord('r') and calibration_mode:
                # Reset calibration points
                corner_collector.collected.clear()
                print("Calibration points reset")
        else:
            # Not showing, check for ESC key
            key = cv2.waitKey(1) & 0xFF
            if key == 27:
                break

    # Cleanup: release resources
    cap.release()  # Close video capture
    if udp_sock:
        udp_sock.close()  # Close UDP socket
    if args.show:
        cv2.destroyAllWindows()  # Close OpenCV windows


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Camera-to-map localization tool (YOLO + homography)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    # calibrate
    p_cal = sub.add_parser("calibrate", help="Run calibration")
    p_cal.add_argument("--source", default="0", help="Video source (index, URL, or udp://port). Default: 0")
    p_cal.add_argument("--method", choices=["corners", "pose"], default="corners", help="Calibration method")
    p_cal.add_argument("--map-width-cm", type=float, required=True, dest="map_width_cm")
    p_cal.add_argument("--map-height-cm", type=float, required=True, dest="map_height_cm")
    p_cal.add_argument("--out", default="calibration.json", help="Output calibration file path")
    p_cal.add_argument("--use-gstreamer", action="store_true", help="Use GStreamer for UDP streams")
    p_cal.add_argument("--stream-port", type=int, default=5000, help="UDP stream port (default: 5000)")
    p_cal.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer (default: 5)")
    
    # Camera configuration for height compensation
    p_cal.add_argument("--camera-height-cm", type=float, help="Camera height above ground in cm (for height compensation)")
    p_cal.add_argument("--camera-angle-degrees", type=float, help="Camera angle from vertical in degrees (for height compensation)")
    p_cal.add_argument("--robot-height-cm", type=float, help="Robot height in cm (for height compensation)")
    
    p_cal.set_defaults(func=cmd_calibrate)

    # run
    p_run = sub.add_parser("run", help="Run localization")
    p_run.add_argument("--source", default="0", help="Video source (index, URL, or udp://port). Default: 0")
    p_run.add_argument("--calib", default="calibration.json", help="Calibration file path")
    p_run.add_argument("--model", default="model_car_heading.pt", help="Ultralytics YOLO model path")
    p_run.add_argument("--cls", default=None, help="Target class name to filter (optional)")
    p_run.add_argument("--device", default=None, help="Inference device, e.g. 'cpu', '0'")
    p_run.add_argument("--ema-alpha", type=float, default=0.3, dest="ema_alpha", help="EMA smoothing factor (0-1). 0 disables")
    p_run.add_argument("--show", action="store_true", help="Show visualization window")
    
    # Streaming options
    p_run.add_argument("--use-gstreamer", action="store_true", help="Use GStreamer for UDP streams")
    p_run.add_argument("--stream-port", type=int, default=5000, help="UDP stream port (default: 5000)")
    p_run.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer (default: 5)")
    
    # UDP sending options
    p_run.add_argument("--udp-enabled", action="store_true", help="Enable UDP data transmission")
    p_run.add_argument("--udp-ip", default="147.232.73.238", help="UDP target IP address")
    p_run.add_argument("--udp-port", type=int, default=50000, help="UDP target port")
    p_run.add_argument("--confidence-threshold", type=float, default=0.8, help="Minimum confidence for detections")
    
    p_run.set_defaults(func=cmd_run)

    return parser


def main() -> None:
    """
    Main entry point for the localization tool.
    
    Parses command-line arguments and executes the appropriate command
    (either 'calibrate' or 'run').
    """
    parser = build_arg_parser()
    args = parser.parse_args()

    # Disable EMA smoothing if alpha is set to 0 or negative
    if hasattr(args, "ema_alpha") and args.ema_alpha is not None and args.ema_alpha <= 0.0:
        args.ema_alpha = None

    # Execute the command handler function (either cmd_calibrate or cmd_run)
    args.func(args)


if __name__ == "__main__":
    main()

