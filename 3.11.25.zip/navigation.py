#!/usr/bin/env python3
"""
Waypoint-based navigation that uses your calibrated logical waypoints for path planning.
This eliminates the numbered path waypoints and uses your actual waypoints instead.
"""

import argparse
import json
import math
import socket
import time
from pathlib import Path
from typing import Optional, List
import numpy as np

# Add OpenCV and GStreamer paths
from config import setup_opencv_gstreamer_paths
setup_opencv_gstreamer_paths()
import cv2

# Import from existing modules
from localization import (
    load_calibration, open_video_capture, YoloDetector, 
    ExponentialMovingAverage, perspective_map_pixels_to_world,
    compensate_for_robot_height, send_detection_udp,
    world_to_pixel_camera_compensated, create_stream_config,
    compute_homography_from_corners, ClickCollector, save_calibration
)
from movement_heading_detector import MovementHeadingDetector


class WaypointBasedNavigation:
    """Navigation system that uses logical waypoints for path planning"""
    
    def __init__(self, calibration_file: str, model_path: str = "model_car_heading.pt", 
                 heading_tolerance: float = 22.5, udp_ip: str = "127.0.0.1", udp_port: int = 50001, 
                 udp_send_interval: int = 30, continuous_navigation: bool = False):
        self.calibration_file = calibration_file
        self.calib = load_calibration(Path(calibration_file))
        # Use YoloDetector for position detection only (not heading)
        self.yolo_detector = YoloDetector(model_path=model_path)
        # Always use movement-based heading detection
        self.movement_detector = MovementHeadingDetector(history_size=5, min_movement_threshold=1.0)
        self.ema = ExponentialMovingAverage(alpha=0.3)
        # Load waypoints from unified calibration file
        if self.calib.waypoints:
            self.waypoints = self.calib.waypoints
            print(f"Loaded {len(self.waypoints)} waypoints from unified calibration file")
        else:
            raise ValueError("No waypoints found in calibration file. Please ensure waypoints are stored in the calibration file.")
        # Precompute waypoint positions as numpy array for fast vectorized operations
        self._waypoint_array = np.array(
            [[wp['world_x'], wp['world_y']] for wp in self.waypoints], 
            dtype=np.float64
        )
        self.H = self.calib.homography.astype(float)
        self.H_inv = np.linalg.inv(self.H)  # Cache inverse for performance
        
        # Navigation state
        self.target_waypoint = None
        self.current_path = []
        self.current_action_index = 0
        self.running = False
        self.heading_tolerance = heading_tolerance  # Degrees tolerance for waypoint selection
        self.continuous_navigation = continuous_navigation  # Demo mode - keep running after reaching target
        self.waypoint_cycle_index = 0  # For cycling through waypoints in continuous mode
        
        # Heading history for fallback when heading is unknown
        self.last_valid_heading_class = "rosmaster_r2_rotation"  # Default to rotation/unknown
        self.heading_history = []
        
        
        # UDP settings
        self.udp_ip = udp_ip
        self.udp_port = udp_port
        self.udp_socket = None
        
        # Frame counter for UDP sending frequency control
        self.frame_count = 0
        self.udp_send_interval = udp_send_interval  # Send UDP packets every N frames
        
        # Waypoint lookup
        self.waypoint_lookup = {wp['name']: i for i, wp in enumerate(self.waypoints)}
        
        # Define connections between waypoints (road network) - converted to adjacency dict for faster lookup
        connections_list = [
            # Cross connections (intersections to outer corners)
            (0, 4), (4, 0), (4, 1), (1, 4),  # Top cross
            (1, 8), (8, 1), (8, 2), (2, 8),  # Right cross  
            (2, 6), (6, 2), (6, 3), (3, 6),  # Bottom cross
            (3, 7), (7, 3), (7, 0), (0, 7),  # Left cross
            # Center connections
            (4, 5), (5, 6), (6, 5), (5, 4),  # Top-Center-Bottom
            (7, 9), (5, 8), (8, 5), (9, 7), (9, 5), (5, 9),  # Left-Center-Right
        ]
        # Convert to adjacency dict for O(1) lookup instead of O(n) iteration
        self.adjacency = {}
        for from_idx, to_idx in connections_list:
            if from_idx not in self.adjacency:
                self.adjacency[from_idx] = []
            self.adjacency[from_idx].append(to_idx)
    
    def save_waypoints(self):
        """Save waypoints to unified calibration file"""
        from localization import save_calibration
        self.calib.waypoints = self.waypoints
        # Update waypoint array and lookup after saving
        self._waypoint_array = np.array(
            [[wp['world_x'], wp['world_y']] for wp in self.waypoints], 
            dtype=np.float64
        )
        self.waypoint_lookup = {wp['name']: i for i, wp in enumerate(self.waypoints)}
        save_calibration(self.calib, Path(self.calibration_file), merge=True)
        print(f"Waypoints saved to {self.calibration_file}")
    
    def world_to_pixel_camera_compensated(self, world_x: float, world_y: float, object_height_cm: float = 0.0) -> tuple:
        """Convert world coordinates to pixel coordinates with camera compensation"""
        return world_to_pixel_camera_compensated(
            world_x, world_y, self.H_inv,
            self.calib.camera, self.calib.image_width, self.calib.image_height,
            object_height_cm
        )
    
    def get_waypoint_by_name(self, name: str) -> Optional[dict]:
        """Get waypoint by name"""
        if name in self.waypoint_lookup:
            return self.waypoints[self.waypoint_lookup[name]]
        return None
    
    def find_closest_waypoint(self, robot_x: float, robot_y: float) -> int:
        """Find closest waypoint to robot position using vectorized numpy operations"""
        deltas = self._waypoint_array - np.array([robot_x, robot_y])
        return int(np.argmin(np.sum(deltas ** 2, axis=1)))
    
    def find_waypoint_in_heading_direction(self, robot_x: float, robot_y: float, robot_heading_class: str) -> int:
        """Find the closest waypoint that is within heading tolerance using vectorized numpy operations"""
        robot_direction = self.get_heading_direction_from_class(robot_heading_class)
        deltas = self._waypoint_array - np.array([robot_x, robot_y])
        dist_sq = np.sum(deltas ** 2, axis=1)
        
        # Vectorized direction filtering - batch compute all directions
        directions_to_wp = np.array([
            self.get_direction_to_waypoint(dx, dy)
            for dx, dy in deltas
        ])
        valid_mask = np.array([
            self.is_waypoint_in_heading_direction(robot_direction, dir_to_wp)
            for dir_to_wp in directions_to_wp
        ])
        
        if not np.any(valid_mask):
            print(f"No waypoint found in {robot_direction} direction, using closest waypoint")
            return self.find_closest_waypoint(robot_x, robot_y)
        
        best_idx = int(np.argmin(np.where(valid_mask, dist_sq, np.inf)))
        print(f"Selected waypoint {best_idx} at {math.sqrt(dist_sq[best_idx]):.1f}cm in {robot_direction} direction (within {self.heading_tolerance}° angle)")
        return best_idx
    
    def find_waypoint_path(self, start_idx: int, goal_idx: int, robot_heading_class: str = "rosmaster_r2_rotation") -> Optional[List[int]]:
        """Find path through waypoint network using heading-aware pathfinding"""
        if start_idx == goal_idx:
            return [start_idx]
        
        # Use Dijkstra-like algorithm with turn cost consideration
        import heapq
        
        # Priority queue: (total_cost, current_idx, path, current_heading)
        queue = [(0, start_idx, [start_idx], robot_heading_class)]
        visited = {}  # (waypoint_idx, heading_class) -> cost

        # Determine the index of the waypoint that is "behind" the robot at start and mark as visited
        # "Behind" is the opposite direction from the robot's heading
        
        # Mark waypoint "behind" robot at start to prevent backtracking
        behind_idx = None
        current_direction = self.get_heading_direction_from_class(robot_heading_class)
        opposite_dir = {'North': 'South', 'South': 'North', 'East': 'West', 'West': 'East', 'Unknown': 'Unknown'}
        
        if current_direction != 'Unknown':
            start_pos = self._waypoint_array[start_idx]
            deltas = self._waypoint_array - start_pos
            dist_sq = np.sum(deltas ** 2, axis=1)
            dist_sq[start_idx] = np.inf  # Exclude start waypoint
            
            # Vectorized: compute all directions at once
            directions = np.array([
                self.get_direction_to_waypoint(dx, dy)
                for dx, dy in deltas
            ])
            opposite_mask = directions == opposite_dir[current_direction]
            
            if np.any(opposite_mask):
                # Find closest waypoint in opposite direction
                behind_idx = int(np.argmin(np.where(opposite_mask, dist_sq, np.inf)))
            
            if behind_idx is not None:
                visited[(behind_idx, robot_heading_class)] = float('inf')
        
        while queue:
            total_cost, current_idx, path, current_heading = heapq.heappop(queue)
            
            # Check if we've reached the goal
            if current_idx == goal_idx:
                return path
            
            # Skip if we've visited this state with better cost
            state = (current_idx, current_heading)
            if state in visited and visited[state] <= total_cost:
                continue
            visited[state] = total_cost
            
            # Check all connected waypoints using adjacency dict (O(1) lookup)
            for next_idx in self.adjacency.get(current_idx, []):
                # Calculate turn cost to reach next waypoint
                turn_cost = self.calculate_turn_cost(current_idx, next_idx, current_heading)
                new_cost = total_cost + 1 + turn_cost  # Base cost + turn cost
                
                # Get heading after turn
                next_heading = self.get_heading_after_turn(current_idx, next_idx, current_heading)
                
                # Add to queue if not visited or better cost
                new_state = (next_idx, next_heading)
                if new_state not in visited or visited[new_state] > new_cost:
                    heapq.heappush(queue, (new_cost, next_idx, path + [next_idx], next_heading))
        
        return None
    def start_navigation_to_waypoint(self, target_waypoint_name: str):
        """Start navigation to a named waypoint"""
        target_wp = self.get_waypoint_by_name(target_waypoint_name)
        if not target_wp:
            print(f"Error: Waypoint '{target_waypoint_name}' not found!")
            return False
        
        self.target_waypoint = target_wp
        self.running = True
        self.current_action_index = 0
        
        # Setup UDP socket for sending commands
        if self.udp_socket is None:
            self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        print(f"Navigation started to waypoint: {target_waypoint_name}")
        print(f"Target position: ({target_wp['world_x']:.1f}, {target_wp['world_y']:.1f}) cm")
        print(f"UDP target: {self.udp_ip}:{self.udp_port}")
        if self.continuous_navigation:
            print("CONTINUOUS MODE: Robot will cycle through waypoints for demo presentation")
        return True
    
    def start_navigation_to_custom(self, world_x: float, world_y: float):
        """Start navigation to custom coordinates"""
        # Create a temporary waypoint-like target
        self.target_waypoint = {
            'name': 'Custom',
            'world_x': world_x,
            'world_y': world_y,
            'color': (255, 0, 255)  # Magenta for custom target
        }
        self.running = True
        self.current_action_index = 0
        
        # Setup UDP socket for sending commands
        if self.udp_socket is None:
            self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        print(f"Navigation started to custom coordinates: ({world_x:.1f}, {world_y:.1f}) cm")
        print(f"UDP target: {self.udp_ip}:{self.udp_port}")
        return True
    
    def get_next_waypoint_for_continuous_mode(self) -> str:
        """Get next waypoint for continuous navigation cycling"""
        if not self.waypoints:
            return None
        
        # Cycle through waypoints in order
        waypoint_name = self.waypoints[self.waypoint_cycle_index]['name']
        self.waypoint_cycle_index = (self.waypoint_cycle_index + 1) % len(self.waypoints)
        return waypoint_name
    
    def update_robot_position(self, robot_x: float, robot_y: float, heading_class: str = "rosmaster_r2_rotation"):
        """Update robot position and plan path with approach direction validation"""
        if not self.running or not self.target_waypoint:
            return
        
        # Find waypoint in robot's heading direction using categorical heading
        start_idx = self.find_waypoint_in_heading_direction(robot_x, robot_y, heading_class)
        
        # Determine target waypoint index
        if self.target_waypoint['name'] == 'Custom':
            # For custom targets, find the closest waypoint to the custom target
            target_x = self.target_waypoint['world_x']
            target_y = self.target_waypoint['world_y']
            target_idx = self.find_closest_waypoint(target_x, target_y)
            print(f"Custom target at ({target_x:.1f}, {target_y:.1f}) - using closest waypoint {self.waypoints[target_idx]['name']}")
        else:
            # For named waypoints, use the lookup
            target_idx = self.waypoint_lookup[self.target_waypoint['name']]
        
        # Plan path through waypoint network with heading awareness
        path_indices = self.find_waypoint_path(start_idx, target_idx, heading_class)
        if not path_indices:
            print("No path found to target waypoint!")
            return
        
        # Convert to world coordinates
        self.current_path = []
        for idx in path_indices:
            wp = self.waypoints[idx]
            self.current_path.append((wp['world_x'], wp['world_y']))
        
        # For custom targets, add the actual target coordinates at the end
        if self.target_waypoint['name'] == 'Custom':
            self.current_path.append((self.target_waypoint['world_x'], self.target_waypoint['world_y']))
        
        # Add robot's current position as first point
        self.current_path.insert(0, (robot_x, robot_y))
        
        start_wp_name = self.waypoints[start_idx]['name']
        target_name = self.target_waypoint['name']
        print(f"Path planned: {len(self.current_path)} waypoints from {start_wp_name} to {target_name}")
    
    def get_next_command(self, robot_x: float, robot_y: float, robot_heading_class: str) -> Optional[dict]:
        """Get next navigation command - only determines turn direction at waypoints"""
        if not self.current_path or self.current_action_index >= len(self.current_path) - 1:
            return None
        
        current_point = self.current_path[self.current_action_index]
        next_point = self.current_path[self.current_action_index + 1]
        
        # Calculate distance squared (avoid sqrt for comparison)
        dx = next_point[0] - robot_x
        dy = next_point[1] - robot_y
        dist_sq = dx * dx + dy * dy
        distance_threshold_sq = 225.0  # 15cm threshold squared (15^2 = 225)
        
        # Check if we're at the final target waypoint (works for both named waypoints and custom targets)
        is_final_target = (self.current_action_index == len(self.current_path) - 2 and 
                          self.target_waypoint and 
                          abs(next_point[0] - self.target_waypoint['world_x']) < 0.1 and 
                          abs(next_point[1] - self.target_waypoint['world_y']) < 0.1)
        
        # If we're at the final target and within 15cm, handle based on mode
        if is_final_target and dist_sq < distance_threshold_sq:
            if self.continuous_navigation:
                # In continuous mode, move to next waypoint
                next_waypoint_name = self.get_next_waypoint_for_continuous_mode()
                if next_waypoint_name:
                    print(f"TARGET REACHED: Moving to next waypoint '{next_waypoint_name}' for continuous demo")
                    # Start navigation to next waypoint
                    self.start_navigation_to_waypoint(next_waypoint_name)
                    # Return direction command for next waypoint
                    return {"action": "straight"}
                else:
                    print("No more waypoints available for continuous mode")
                    return {"action": "stop"}
            else:
                print(f"STOP: Robot reached target - stopping navigation")
                self.running = False  # Stop navigation
                return {"action": "stop"}
        
        # Check if we're close to current waypoint (15cm threshold)
        if dist_sq < distance_threshold_sq:
            self.current_action_index += 1
            if self.current_action_index < len(self.current_path) - 1:
                return self.get_turn_command_at_waypoint(robot_x, robot_y, robot_heading_class)
            return {"action": "stop"}
        
        # Not at waypoint yet - provide driving command based on direction
        return self.get_driving_command_to_waypoint(robot_x, robot_y, robot_heading_class, next_point)
    
    def get_driving_command_to_waypoint(self, robot_x: float, robot_y: float, robot_heading_class: str, next_point: tuple) -> dict:
        """Determine driving command when robot is far from waypoint"""
        # Calculate direction to next waypoint
        dx = next_point[0] - robot_x
        dy = next_point[1] - robot_y
        required_direction = self.get_direction_to_waypoint(dx, dy)
        robot_direction = self.get_heading_direction_from_class(robot_heading_class)
        
        # If robot is facing the right direction, go straight
        if robot_direction == required_direction:
            return {"action": "straight"}
        
        # If robot needs to turn, determine turn direction
        action = self.get_turn_command_from_directions(robot_direction, required_direction)
        distance = math.sqrt(dx * dx + dy * dy)  # Only calculate sqrt for display
        print(f"Driving to waypoint: Robot facing {robot_direction}, need to go {required_direction}, distance: {distance:.1f}cm, command: {action}")
        return {"action": action}
    
    def get_turn_command_at_waypoint(self, robot_x: float, robot_y: float, robot_heading_class: str) -> dict:
        """Determine turn command when robot reaches a waypoint using categorical heading"""
        if self.current_action_index >= len(self.current_path) - 1:
            return {"action": "stop"}
        
        current_point = self.current_path[self.current_action_index]
        next_point = self.current_path[self.current_action_index + 1]
        dx = next_point[0] - current_point[0]
        dy = next_point[1] - current_point[1]
        
        required_direction = self.get_direction_to_waypoint(dx, dy)
        robot_direction = self.get_heading_direction_from_class(robot_heading_class)
        action = self.get_turn_command_from_directions(robot_direction, required_direction)
        
        print(f"At waypoint: {robot_direction} -> {required_direction}, command: {action}")
        return {"action": action}
    
    # Direction mapping constants (faster than if/elif chain)
    HEADING_CLASS_TO_DIR = {
        'rosmaster_r2_north': 'North',
        'rosmaster_r2_east': 'East',
        'rosmaster_r2_south': 'South',
        'rosmaster_r2_west': 'West',
        'rosmaster_r2_rotation': 'Unknown'
    }
    DIR_TO_HEADING_CLASS = {v: k for k, v in HEADING_CLASS_TO_DIR.items() if v != 'Unknown'}
    
    def get_heading_direction_from_class(self, class_name: str) -> str:
        """Convert heading detector class name to cardinal direction"""
        return self.HEADING_CLASS_TO_DIR.get(class_name, 'Unknown')
    
    def get_direction_to_waypoint(self, dx: float, dy: float) -> str:
        """Calculate cardinal direction from robot to waypoint"""
        if abs(dx) < abs(dy):
            if dy > 0:
                return 'North'  # Fixed: positive Y is North
            else:
                return 'South'  # Fixed: negative Y is South
        else:
            if dx > 0:
                return 'East'
            else:
                return 'West'
    
    def is_waypoint_in_heading_direction(self, robot_direction: str, waypoint_direction: str) -> bool:
        """Check if waypoint is within 45° (half of 90°) of the robot's heading direction"""
        if robot_direction == 'Unknown' or waypoint_direction == 'Unknown':
            return True  # Allow any direction if unknown
        
        # Define direction angles (0° = North, 90° = East, 180° = South, 270° = West)
        direction_angles = {
            'North': 0,
            'East': 90,
            'South': 180,
            'West': 270
        }
        
        robot_angle = direction_angles.get(robot_direction, 0)
        waypoint_angle = direction_angles.get(waypoint_direction, 0)
        
        # Calculate angle difference (accounting for 360° wrap-around)
        angle_diff = abs(robot_angle - waypoint_angle)
        if angle_diff > 180:
            angle_diff = 360 - angle_diff
        
        # Allow waypoints within heading tolerance of robot heading (more precise selection)
        is_within_tolerance = angle_diff <= self.heading_tolerance
        if not is_within_tolerance:
            print(f"DEBUG: Waypoint rejected - angle difference {angle_diff:.1f}° > tolerance {self.heading_tolerance}°")
        return is_within_tolerance
    
    def get_turn_command_from_directions(self, current_direction: str, target_direction: str) -> str:
        """Determine turn command based on current and target directions"""
        if current_direction == 'Unknown' or target_direction == 'Unknown':
            return "straight"  # Default to straight if unknown
        
        if current_direction == target_direction:
            return "straight"
        
        # Define turn relationships
        turn_map = {
            'North': {'East': 'right', 'West': 'left', 'South': 'right'},  # South could be right or left, defaulting to right
            'East': {'South': 'right', 'North': 'left', 'West': 'right'},  # West could be right or left, defaulting to right
            'South': {'West': 'right', 'East': 'left', 'North': 'right'},  # North could be right or left, defaulting to right
            'West': {'North': 'right', 'South': 'left', 'East': 'right'}   # East could be right or left, defaulting to right
        }
        
        return turn_map.get(current_direction, {}).get(target_direction, "straight")
    
    def get_best_heading_class(self, current_heading_class: str) -> str:
        """Get the best available heading class, using last valid if current is unknown"""
        # If current heading is valid (not rotation/unknown), use it and update history
        if current_heading_class != "rosmaster_r2_rotation":
            self.last_valid_heading_class = current_heading_class
            # Add to history for smoothing
            self.heading_history.append(current_heading_class)
            if len(self.heading_history) > 10:  # Keep last 10 headings
                self.heading_history.pop(0)
            return current_heading_class
        
        # If current heading is unknown, use last valid heading
        if self.last_valid_heading_class != "rosmaster_r2_rotation":
            print(f"WARNING: Heading unknown, using last valid heading: {self.last_valid_heading_class}")
            return self.last_valid_heading_class
        else:
            # If no valid heading history, try to get most common from history
            if self.heading_history:
                most_common = max(set(self.heading_history), key=self.heading_history.count)
                print(f"WARNING: No valid heading, using most common from history: {most_common}")
                return most_common
            else:
                print("WARNING: No heading history available, using default rotation")
                return "rosmaster_r2_rotation"
    
    def calculate_turn_cost(self, from_idx: int, to_idx: int, current_heading_class: str) -> float:
        """Calculate the cost of turning from current heading to reach next waypoint"""
        if from_idx >= len(self.waypoints) or to_idx >= len(self.waypoints):
            return 0.0
        
        # Get waypoint positions
        from_wp = self.waypoints[from_idx]
        to_wp = self.waypoints[to_idx]
        
        # Calculate direction to next waypoint
        dx = to_wp['world_x'] - from_wp['world_x']
        dy = to_wp['world_y'] - from_wp['world_y']
        required_direction = self.get_direction_to_waypoint(dx, dy)
        
        # Get current robot direction
        current_direction = self.get_heading_direction_from_class(current_heading_class)
        
        # Calculate turn cost based on direction change
        if current_direction == 'Unknown' or required_direction == 'Unknown':
            return 0.5  # Moderate cost for unknown directions
        
        if current_direction == required_direction:
            return 0.0  # No turn needed
        
        # Calculate turn cost based on angle difference
        turn_cost_map = {
            'North': {'East': 1.0, 'West': 1.0, 'South': 20.0},  # 180° turn is expensive
            'East': {'South': 1.0, 'North': 1.0, 'West': 20.0},
            'South': {'West': 1.0, 'East': 1.0, 'North': 20.0},
            'West': {'North': 1.0, 'South': 1.0, 'East': 20.0}
        }
        
        return turn_cost_map.get(current_direction, {}).get(required_direction, 1.0)
    
    def get_heading_after_turn(self, from_idx: int, to_idx: int, current_heading_class: str) -> str:
        """Get the heading class after turning to face the next waypoint"""
        if from_idx >= len(self.waypoints) or to_idx >= len(self.waypoints):
            return current_heading_class
        
        # Get waypoint positions
        from_wp = self.waypoints[from_idx]
        to_wp = self.waypoints[to_idx]
        
        # Calculate direction to next waypoint
        dx = to_wp['world_x'] - from_wp['world_x']
        dy = to_wp['world_y'] - from_wp['world_y']
        required_direction = self.get_direction_to_waypoint(dx, dy)
        
        # Convert back to heading class using cached mapping
        return self.DIR_TO_HEADING_CLASS.get(required_direction, current_heading_class)
    
    def run_with_udp_stream(self, stream_port: int = 5000, show_video: bool = True, 
                           stream_latency: int = 5):
        """Run waypoint-based navigation using UDP video stream"""
        
        # Setup stream configuration
        stream_config = create_stream_config(stream_port, stream_latency)
        
        # Open UDP video stream
        cap = open_video_capture(f"udp://{stream_port}", stream_config)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open UDP stream on port {stream_port}")
        
        print(f"Starting waypoint-based navigation (port {stream_port})...")
        print("Features:")
        print("- Uses your calibrated logical waypoints for path planning")
        print("- No numbered path waypoints - only your actual waypoints")
        print("- Real-time robot detection and tracking")
        if self.continuous_navigation:
            print("- CONTINUOUS MODE: Will cycle through all waypoints for demo")
        print()
        print("Controls:")
        print("  'q': Quit")
        print("  'r': Replan path")
        print("  'c': Enter/exit waypoint calibration mode")
        print("  'm': Enter/exit map corners calibration mode")
        print("  's': Save waypoints (in waypoint calibration mode) or map corners (in corners calibration mode)")
        print("  'T': Enter/exit target change mode (change target while running)")
        print("  In waypoint calibration mode: Click waypoints to adjust positions")
        print("  In map corners calibration mode: Click 4 corners (BL, BR, TR, TL)")
        print("  In target change mode: Click waypoint to select, or click anywhere for custom coordinates")
        
        # Waypoint calibration state
        waypoint_calibration_mode = False
        current_waypoint_index = 0
        calibration_callback_set = False
        all_waypoints_completed = False  # Track if we've completed a full cycle
        
        # Map corners calibration state
        map_corners_calibration_mode = False
        current_corner_index = 0
        all_corners_completed = False
        # Define corners with world coordinates and full names
        # World coordinates are fixed: BL=(0,0), BR=(width,0), TR=(width,height), TL=(0,height)
        corners_world_coords = [
            {'name': 'Bottom-Left', 'world_x': 0.0, 'world_y': 0.0, 'color': (255, 0, 0)},      # Red
            {'name': 'Bottom-Right', 'world_x': self.calib.world.world_width_cm, 'world_y': 0.0, 'color': (0, 255, 0)},  # Green
            {'name': 'Top-Right', 'world_x': self.calib.world.world_width_cm, 'world_y': self.calib.world.world_height_cm, 'color': (0, 0, 255)},  # Blue
            {'name': 'Top-Left', 'world_x': 0.0, 'world_y': self.calib.world.world_height_cm, 'color': (255, 255, 0)},  # Yellow
        ]
        # Initialize corner pixel positions from current homography
        def initialize_corner_pixels():
            from localization import perspective_map_world_to_pixels
            for corner in corners_world_coords:
                pixel_pt = perspective_map_world_to_pixels(
                    np.array([[corner['world_x'], corner['world_y']]], dtype=np.float64),
                    self.H_inv
                )[0]
                corner['pixel_x'] = float(pixel_pt[0])
                corner['pixel_y'] = float(pixel_pt[1])
        
        # Target change mode state
        target_change_mode = False
        
        # Setup mouse callback for waypoint calibration, map corners calibration, and target selection
        def waypoint_mouse_callback(event, x, y, flags, param):
            nonlocal waypoint_calibration_mode, current_waypoint_index, all_waypoints_completed, target_change_mode
            nonlocal map_corners_calibration_mode, current_corner_index, all_corners_completed
            if event == cv2.EVENT_LBUTTONDOWN:
                if map_corners_calibration_mode:
                    # Update current corner position
                    if 0 <= current_corner_index < len(corners_world_coords):
                        corner = corners_world_coords[current_corner_index]
                        corner['pixel_x'] = float(x)
                        corner['pixel_y'] = float(y)
                        print(f"Corner {current_corner_index + 1} '{corner['name']}' moved to pixel ({x}, {y})")
                        
                        # Recompute homography from all 4 corners
                        try:
                            world_width = self.calib.world.world_width_cm
                            world_height = self.calib.world.world_height_cm
                            
                            # Get pixel coordinates in order: BL, BR, TR, TL
                            image_points = [
                                (corners_world_coords[0]['pixel_x'], corners_world_coords[0]['pixel_y']),
                                (corners_world_coords[1]['pixel_x'], corners_world_coords[1]['pixel_y']),
                                (corners_world_coords[2]['pixel_x'], corners_world_coords[2]['pixel_y']),
                                (corners_world_coords[3]['pixel_x'], corners_world_coords[3]['pixel_y']),
                            ]
                            
                            new_H = compute_homography_from_corners(image_points, world_width, world_height)
                            
                            # Update calibration object and navigation system
                            self.calib.homography = new_H
                            self.H = new_H.astype(float)
                            self.H_inv = np.linalg.inv(self.H)
                            
                            print(f"Homography updated for '{corner['name']}'")
                            
                            # Move to next corner
                            prev_index = current_corner_index
                            current_corner_index = (current_corner_index + 1) % len(corners_world_coords)
                            
                            # Check if we completed a full cycle
                            if current_corner_index == 0 and prev_index == len(corners_world_coords) - 1:
                                all_corners_completed = True
                                print("=" * 60)
                                print("✓ ALL CORNERS ADJUSTED!")
                                print("Automatically saving map corners to calibration file...")
                                
                                # Automatically save map corners
                                try:
                                    save_calibration(self.calib, Path(self.calibration_file), merge=True)
                                    print("✓ MAP CORNERS SAVED! Homography matrix updated.")
                                    print(f"Saved to {self.calibration_file}")
                                    print("Press 'm' to exit calibration mode, or continue adjusting corners")
                                    print("=" * 60)
                                except Exception as e:
                                    print(f"ERROR saving map corners: {e}")
                                    print("Press 's' to manually save or 'm' to exit calibration mode")
                                    print("=" * 60)
                            elif current_corner_index == 0:
                                # We cycled back, show reminder
                                print(f"Cycling back to first corner. All corners can be re-adjusted.")
                                print("Press 's' to SAVE or 'm' to exit calibration mode.")
                        except Exception as e:
                            print(f"ERROR updating homography: {e}")
                    else:
                        print(f"ERROR: Invalid corner index {current_corner_index}")
                elif waypoint_calibration_mode:
                    # Convert pixel to world coordinates
                    from localization import perspective_map_pixels_to_world
                    pixel_point = np.array([[x, y]], dtype=np.float64)
                    world_point = perspective_map_pixels_to_world(pixel_point, self.H)[0]
                    
                    # Update current waypoint position
                    if 0 <= current_waypoint_index < len(self.waypoints):
                        self.waypoints[current_waypoint_index]['world_x'] = float(world_point[0])
                        self.waypoints[current_waypoint_index]['world_y'] = float(world_point[1])
                        wp_name = self.waypoints[current_waypoint_index]['name']
                        print(f"Waypoint {current_waypoint_index + 1} '{wp_name}' moved to ({world_point[0]:.1f}, {world_point[1]:.1f}) cm")
                        
                        # Move to next waypoint
                        prev_index = current_waypoint_index
                        current_waypoint_index = (current_waypoint_index + 1) % len(self.waypoints)
                        
                        # Check if we completed a full cycle
                        if current_waypoint_index == 0 and prev_index == len(self.waypoints) - 1:
                            all_waypoints_completed = True
                            print("=" * 60)
                            print("✓ ALL WAYPOINTS ADJUSTED!")
                            print("Automatically saving waypoints to calibration file...")
                            
                            # Automatically save waypoints
                            try:
                                self.save_waypoints()
                                print("✓ WAYPOINTS SAVED! Calibration file updated.")
                                print(f"Saved to {self.calibration_file}")
                                print("Press 'c' to exit calibration mode, or continue adjusting waypoints")
                                print("=" * 60)
                            except Exception as e:
                                print(f"ERROR saving waypoints: {e}")
                                print("Press 's' to manually save or 'c' to exit calibration mode")
                                print("=" * 60)
                        elif current_waypoint_index == 0:
                            # We cycled back, show reminder
                            print(f"Cycling back to first waypoint. All waypoints can be re-adjusted.")
                            print("Press 's' to SAVE or 'c' to exit calibration mode.")
                    else:
                        print(f"ERROR: Invalid waypoint index {current_waypoint_index}")
                elif target_change_mode:
                    # Target change mode: check if click is on a waypoint or use as custom coordinates
                    from localization import perspective_map_pixels_to_world
                    
                    # Check if click is near any waypoint (within 20 pixels)
                    clicked_waypoint = None
                    click_radius = 20
                    
                    for waypoint in self.waypoints:
                        wp_px, wp_py = self.world_to_pixel_camera_compensated(
                            waypoint['world_x'], waypoint['world_y'], 0.0
                        )
                        distance = math.sqrt((x - wp_px) ** 2 + (y - wp_py) ** 2)
                        if distance <= click_radius:
                            clicked_waypoint = waypoint
                            break
                    
                    if clicked_waypoint:
                        # Clicked on a waypoint - navigate to it
                        print(f"Target changed to waypoint: {clicked_waypoint['name']}")
                        self.start_navigation_to_waypoint(clicked_waypoint['name'])
                        target_change_mode = False  # Exit target change mode
                        print("Target change mode: OFF")
                    else:
                        # Clicked elsewhere - use as custom coordinates
                        pixel_point = np.array([[x, y]], dtype=np.float64)
                        world_point = perspective_map_pixels_to_world(pixel_point, self.H)[0]
                        print(f"Target changed to custom coordinates: ({world_point[0]:.1f}, {world_point[1]:.1f}) cm")
                        self.start_navigation_to_custom(float(world_point[0]), float(world_point[1]))
                        target_change_mode = False  # Exit target change mode
                        print("Target change mode: OFF")
                elif not map_corners_calibration_mode:
                    print(f"DEBUG: Click detected. Press 'c' for waypoint calibration, 'm' for map corners calibration, or 'T' for target change mode.")
        
        if show_video:
            cv2.namedWindow("Waypoint-Based Navigation", cv2.WINDOW_NORMAL)
            cv2.setMouseCallback("Waypoint-Based Navigation", waypoint_mouse_callback)
            calibration_callback_set = True
        
        last_print_time = 0.0
        min_print_interval = 0.02  # 20 ms
        
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    print("Failed to read from UDP stream")
                    break
                
                # Increment frame counter
                self.frame_count += 1
                
                # Detect robot position using YOLO (position only, heading comes from movement)
                centroid_px = self.yolo_detector.detect_first_centroid(frame)
                
                if centroid_px is not None:
                    # Apply height compensation if available
                    if self.calib.camera is not None:
                        centroid_px = compensate_for_robot_height(
                            centroid_px, 
                            self.calib.camera, 
                            self.calib.image_width, 
                            self.calib.image_height
                        )
                    
                    # Convert to world coordinates
                    px = np.array([[centroid_px[0], centroid_px[1]]], dtype=np.float64)
                    world_xy = perspective_map_pixels_to_world(px, self.H)[0]
                    
                    # Apply smoothing
                    world_xy = self.ema.update(world_xy)
                    
                    # Store last known position for movement-based heading fallback
                    self.last_known_position = world_xy
                    
                    # Always use movement-based heading detection
                    movement_heading_class = self.movement_detector.get_smoothed_heading_class(world_xy[0], world_xy[1])
                    movement_heading_angle = self.movement_detector.heading_classes.get(movement_heading_class)
                    
                    heading = movement_heading_angle
                    class_name = movement_heading_class
                    
                    print(f"DEBUG: Using movement-based heading: {movement_heading_class} ({movement_heading_angle}°)")
                    
                    # Print location and heading to terminal
                    now = time.time()
                    if now - last_print_time >= min_print_interval:
                        heading_str = f"{heading:.1f}°" if heading is not None else "unknown"
                        print(f"X={world_xy[0]:.1f} cm, Y={world_xy[1]:.1f} cm, Heading={heading_str} ({class_name})")
                        last_print_time = now
                    
                    # Get best available heading class (use last valid if current is unknown)
                    best_heading_class = self.get_best_heading_class(class_name)
                    
                    # Update navigation with heading class
                    self.update_robot_position(world_xy[0], world_xy[1], best_heading_class)
                    
                    # Get next command
                    command = self.get_next_command(world_xy[0], world_xy[1], best_heading_class)
                    
                    # Send UDP status if enabled (only every N frames)
                    if self.udp_socket and (self.frame_count % self.udp_send_interval == 0):
                        heading_direction = self.get_heading_direction_from_class(class_name)
                        if command:
                            cmd_action = command['action']
                        else:
                            cmd_action = None
                        
                        payload = {
                            "type": "navigation_status",
                            "robot_position": {"x": world_xy[0], "y": world_xy[1]},
                            "heading": heading_direction,
                            "command": cmd_action
                        }
                        send_detection_udp(payload, self.udp_ip, self.udp_port, self.udp_socket)
                    
                    if command:
                        print(f"Command: {command['action']}")
                            
                    
                    # Draw robot position and heading
                    cv2.circle(frame, (int(centroid_px[0]), int(centroid_px[1])), 8, (0, 0, 255), -1)
                    
                    # Draw heading arrow
                    if heading is not None:
                        arrow_length = 30
                        end_x = int(centroid_px[0] + arrow_length * np.sin(np.radians(heading)))
                        end_y = int(centroid_px[1] - arrow_length * np.cos(np.radians(heading)))
                        cv2.arrowedLine(frame, (int(centroid_px[0]), int(centroid_px[1])), 
                                      (end_x, end_y), (0, 255, 0), 3, tipLength=0.3)
                    
                    # Draw robot info
                    heading_str = f"{heading:.1f}" if heading is not None else "unknown"
                    # Convert heading class to readable direction
                    heading_direction = self.get_heading_direction_from_class(class_name)
                    cv2.putText(
                        frame,
                        f"Robot Position: ({world_xy[0]:.1f}, {world_xy[1]:.1f}) cm",
                        (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 255, 0),
                        2
                    )
                    cv2.putText(
                        frame,
                        f"Heading: {heading_str} ({heading_direction})",
                        (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 255, 0),
                        2
                    )
                    
                    # Draw current command with enhanced display
                    if command:
                        # Create command display with action text only (no icon)
                        command_text = command['action'].upper()
                        
                        # Choose color and background based on command type
                        if command['action'] == 'stop':
                            text_color = (255, 255, 255)  # White text
                            bg_color = (0, 0, 255)  # Red background
                            border_color = (0, 0, 200)  # Darker red border
                        elif command['action'] == 'straight':
                            text_color = (0, 0, 0)  # Black text
                            bg_color = (0, 255, 0)  # Green background
                            border_color = (0, 200, 0)  # Darker green border
                        elif command['action'] in ['left', 'right']:
                            text_color = (0, 0, 0)  # Black text
                            bg_color = (255, 255, 0)  # Yellow background
                            border_color = (200, 200, 0)  # Darker yellow border
                        else:
                            text_color = (255, 255, 255)  # White text
                            bg_color = (128, 128, 128)  # Gray background
                            border_color = (100, 100, 100)  # Darker gray border
                        
                        # Draw command background with border
                        text_size = cv2.getTextSize(command_text, cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2)[0]
                        padding = 10
                        x1, y1 = 10, 90
                        x2, y2 = x1 + text_size[0] + 2*padding, y1 + text_size[1] + 2*padding
                        
                        # Draw border
                        cv2.rectangle(frame, (x1-2, y1-2), (x2+2, y2+2), border_color, -1)
                        # Draw background
                        cv2.rectangle(frame, (x1, y1), (x2, y2), bg_color, -1)
                        # Draw text
                        cv2.putText(
                            frame,
                            command_text,
                            (x1 + padding, y1 + text_size[1] + padding),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            1.0,
                            text_color,
                            2
                        )
                        
                        # Removed: Additional command description
                        # Removed: Status indicator display
                    else:
                        # No command - show idle status
                        idle_text = "⏸ IDLE - No Command"
                        cv2.putText(
                            frame,
                            idle_text,
                            (10, 90),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.8,
                            (128, 128, 128),
                            2
                        )
                else:
                    # No YOLO detection - try to continue with last known position for movement-based heading
                    if hasattr(self, 'last_known_position'):
                        # Use last known position for movement-based heading
                        world_xy = self.last_known_position
                        movement_heading_class = self.movement_detector.get_smoothed_heading_class(world_xy[0], world_xy[1])
                        movement_heading_angle = self.movement_detector.heading_classes.get(movement_heading_class)
                        
                        heading = movement_heading_angle
                        class_name = movement_heading_class
                        
                        print(f"DEBUG: No YOLO detection - using movement-based heading with last known position: {movement_heading_class} ({movement_heading_angle}°)")
                        
                        # Use dummy centroid for drawing (since we don't have visual detection)
                        centroid_px = self.world_to_pixel_camera_compensated(world_xy[0], world_xy[1], 0.0)
                        
                        # Continue with navigation using movement-based heading
                        # (The rest of the navigation logic will be executed below)
                    else:
                        # No detection and no last known position - show no detection status
                        if show_video:
                            self.draw_static_elements(frame, hide_waypoints=map_corners_calibration_mode)
                            
                            # Draw no detection status
                            no_detection_text = "⚠ NO DETECTION - Waiting for robot"
                            cv2.putText(
                                frame,
                                no_detection_text,
                                (10, 90),
                                cv2.FONT_HERSHEY_SIMPLEX,
                                0.8,
                                (0, 0, 255),  # Red text
                                2
                            )
                            
                            cv2.imshow("Waypoint-Based Navigation", frame)
                            if (cv2.waitKey(1) & 0xFF) == 27:
                                break
                        continue
                
                # Draw all visual elements
                # Hide waypoints during map corners calibration
                self.draw_static_elements(frame, hide_waypoints=map_corners_calibration_mode)
                if not map_corners_calibration_mode:
                    self.draw_waypoint_path(frame)
                
                # Draw waypoint calibration mode indicators
                if waypoint_calibration_mode:
                    # Highlight current waypoint being adjusted
                    if 0 <= current_waypoint_index < len(self.waypoints):
                        current_wp = self.waypoints[current_waypoint_index]
                        pixel_x, pixel_y = self.world_to_pixel_camera_compensated(
                            current_wp['world_x'], current_wp['world_y'], 0.0
                        )
                        if 0 <= pixel_x < frame.shape[1] and 0 <= pixel_y < frame.shape[0]:
                            # Draw pulsing circle around current waypoint
                            cv2.circle(frame, (pixel_x, pixel_y), 20, (0, 255, 255), 3)
                            cv2.circle(frame, (pixel_x, pixel_y), 15, (0, 255, 255), -1)
                    
                    # Show calibration instructions
                    if all_waypoints_completed and current_waypoint_index == 0:
                        # Show completion message
                        cv2.putText(frame, 
                                  "ALL WAYPOINTS ADJUSTED & SAVED! Press 'c' to exit",
                                  (10, frame.shape[0] - 60),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                        cv2.putText(frame,
                                  f"Waypoint {current_waypoint_index + 1}/{len(self.waypoints)} '{self.waypoints[current_waypoint_index]['name']}' (cycling - can re-adjust)",
                                  (10, frame.shape[0] - 30),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
                    elif current_waypoint_index == 0:
                        cv2.putText(frame, 
                                  f"WAYPOINT CALIBRATION: Click waypoint {current_waypoint_index + 1}/{len(self.waypoints)} '{self.waypoints[current_waypoint_index]['name']}'",
                                  (10, frame.shape[0] - 40),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                    else:
                        remaining = len(self.waypoints) - current_waypoint_index
                        cv2.putText(frame,
                                  f"WAYPOINT CALIBRATION: Click waypoint {current_waypoint_index + 1}/{len(self.waypoints)} '{self.waypoints[current_waypoint_index]['name']}' ({remaining} remaining)",
                                  (10, frame.shape[0] - 40),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                        cv2.putText(frame,
                                  "Press 's' to save anytime",
                                  (10, frame.shape[0] - 10),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
                
                # Draw map corners calibration mode indicators
                if map_corners_calibration_mode:
                    # Draw all corners
                    for idx, corner in enumerate(corners_world_coords):
                        px = int(corner['pixel_x'])
                        py = int(corner['pixel_y'])
                        if 0 <= px < frame.shape[1] and 0 <= py < frame.shape[0]:
                            # Draw corner circle with its color
                            cv2.circle(frame, (px, py), 8, corner['color'], -1)
                            cv2.circle(frame, (px, py), 4, (255, 255, 255), -1)
                            
                            # Draw corner number
                            cv2.putText(frame, str(idx + 1), (px - 5, py + 5), 
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2)
                            
                            # Draw corner name with enhanced visibility
                            name_text = corner['name']
                            font = cv2.FONT_HERSHEY_SIMPLEX
                            font_scale_name = 0.4
                            thickness_name = 1
                            name_x = px + 10
                            name_y = py - 10
                            
                            # Draw text with outline effect
                            corner_color = corner['color']
                            # Draw black outline
                            for dx, dy in [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]:
                                cv2.putText(frame, name_text, (name_x + dx, name_y + dy),
                                           font, font_scale_name, (0, 0, 0), thickness_name + 1)
                            # Draw colored text on top
                            cv2.putText(frame, name_text, (name_x, name_y),
                                       font, font_scale_name, corner_color, thickness_name)
                    
                    # Highlight current corner being adjusted
                    if 0 <= current_corner_index < len(corners_world_coords):
                        current_corner = corners_world_coords[current_corner_index]
                        px = int(current_corner['pixel_x'])
                        py = int(current_corner['pixel_y'])
                        if 0 <= px < frame.shape[1] and 0 <= py < frame.shape[0]:
                            # Draw pulsing circle around current corner
                            cv2.circle(frame, (px, py), 20, (0, 255, 255), 3)
                            cv2.circle(frame, (px, py), 15, (0, 255, 255), -1)
                    
                    # Show calibration instructions
                    if all_corners_completed and current_corner_index == 0:
                        # Show completion message
                        cv2.putText(frame, 
                                  "ALL CORNERS ADJUSTED & SAVED! Press 'm' to exit",
                                  (10, frame.shape[0] - 60),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                        cv2.putText(frame,
                                  f"Corner {current_corner_index + 1}/{len(corners_world_coords)} '{corners_world_coords[current_corner_index]['name']}' (cycling - can re-adjust)",
                                  (10, frame.shape[0] - 30),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
                    elif current_corner_index == 0:
                        cv2.putText(frame, 
                                  f"MAP CORNERS CALIBRATION: Click corner {current_corner_index + 1}/{len(corners_world_coords)} '{corners_world_coords[current_corner_index]['name']}'",
                                  (10, frame.shape[0] - 40),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                    else:
                        remaining = len(corners_world_coords) - current_corner_index
                        cv2.putText(frame,
                                  f"MAP CORNERS CALIBRATION: Click corner {current_corner_index + 1}/{len(corners_world_coords)} '{corners_world_coords[current_corner_index]['name']}' ({remaining} remaining)",
                                  (10, frame.shape[0] - 40),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                        cv2.putText(frame,
                                  "Press 's' to save anytime",
                                  (10, frame.shape[0] - 10),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
                
                # Draw target change mode indicators
                if target_change_mode:
                    # Highlight all waypoints as clickable
                    for waypoint in self.waypoints:
                        pixel_x, pixel_y = self.world_to_pixel_camera_compensated(
                            waypoint['world_x'], waypoint['world_y'], 0.0
                        )
                        if 0 <= pixel_x < frame.shape[1] and 0 <= pixel_y < frame.shape[0]:
                            # Draw pulsing circle around waypoint to indicate it's clickable
                            cv2.circle(frame, (pixel_x, pixel_y), 25, (255, 255, 0), 3)
                    
                    # Show target change instructions
                    cv2.putText(frame,
                              "TARGET CHANGE MODE: Click a waypoint to select, or click anywhere for custom coordinates",
                              (10, frame.shape[0] - 40),
                              cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
                    cv2.putText(frame,
                              "Press 'T' again to exit target change mode",
                              (10, frame.shape[0] - 10),
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
                
                # Draw helper text with available commands (only when not in special modes)
                if not waypoint_calibration_mode and not map_corners_calibration_mode and not target_change_mode:
                    commands_text = [
                        "Commands:",
                        "Q - Quit",
                        "T - Change Target",
                        "C - Waypoint Calib",
                        "M - Map Corners"
                    ]
                    
                    # Position at top right
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    font_scale = 0.5
                    thickness = 1
                    line_height = 20
                    start_y = 10
                    start_x = frame.shape[1] - 200
                    
                    # Draw semi-transparent background
                    bg_height = len(commands_text) * line_height + 10
                    bg_width = 190
                    overlay = frame.copy()
                    cv2.rectangle(overlay, 
                                (start_x - 5, start_y - 5), 
                                (start_x + bg_width, start_y + bg_height), 
                                (0, 0, 0), -1)
                    cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
                    
                    # Draw text
                    for i, cmd in enumerate(commands_text):
                        y_pos = start_y + (i + 1) * line_height
                        color = (255, 255, 255) if i == 0 else (200, 200, 200)
                        thickness_actual = 2 if i == 0 else thickness
                        cv2.putText(frame, cmd, (start_x, y_pos),
                                  font, font_scale, color, thickness_actual)
                
                if show_video:
                    cv2.imshow("Waypoint-Based Navigation", frame)
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord('q'):
                        break
                    elif key == ord('r'):
                        # Replan path
                        if self.running:
                            self.current_action_index = 0
                            print("Path replanned!")
                    elif key == ord('T') or key == ord('t'):
                        # Toggle target change mode
                        if waypoint_calibration_mode:
                            print("Note: Exit waypoint calibration mode ('c') first before entering target change mode")
                        elif map_corners_calibration_mode:
                            print("Note: Exit map corners calibration mode ('m') first before entering target change mode")
                        else:
                            target_change_mode = not target_change_mode
                            if target_change_mode:
                                print("=" * 60)
                                print("TARGET CHANGE MODE: ON")
                                print("Click on a waypoint to navigate to it, or click anywhere for custom coordinates")
                                print("Press 'T' again to exit")
                                print("=" * 60)
                            else:
                                print("Target change mode: OFF")
                    elif key == ord('m'):
                        # Toggle map corners calibration mode
                        if target_change_mode:
                            print("Note: Exit target change mode ('T') first before entering calibration mode")
                        elif waypoint_calibration_mode:
                            print("Note: Exit waypoint calibration mode ('c') first before entering map corners calibration mode")
                        else:
                            map_corners_calibration_mode = not map_corners_calibration_mode
                            if map_corners_calibration_mode:
                                # Initialize corner pixel positions from current homography
                                initialize_corner_pixels()
                                current_corner_index = 0
                                all_corners_completed = False
                                print("=" * 60)
                                print("MAP CORNERS CALIBRATION MODE: ON")
                                print("Click corners to adjust positions. Starting with:")
                                print(f"  1. Bottom-Left")
                                print(f"  2. Bottom-Right")
                                print(f"  3. Top-Right")
                                print(f"  4. Top-Left")
                                print("TIP: After adjusting all corners, press 's' to save to calibration file")
                                print("Press 'm' again to exit")
                                print("=" * 60)
                            else:
                                print("Map corners calibration mode: OFF")
                                current_corner_index = 0
                                all_corners_completed = False
                    elif key == ord('c'):
                        # Toggle waypoint calibration mode
                        if target_change_mode:
                            print("Note: Exit target change mode ('T') first before entering calibration mode")
                        elif map_corners_calibration_mode:
                            print("Note: Exit map corners calibration mode ('m') first before entering waypoint calibration mode")
                        else:
                            waypoint_calibration_mode = not waypoint_calibration_mode
                            if waypoint_calibration_mode:
                                current_waypoint_index = 0
                                all_waypoints_completed = False
                                print(f"Waypoint calibration mode: ON - Click waypoints to adjust. Starting with '{self.waypoints[0]['name']}'")
                                print("TIP: After adjusting all waypoints, press 's' to save to calibration file")
                            else:
                                print("Waypoint calibration mode: OFF")
                                all_waypoints_completed = False
                    elif key == ord('s'):
                        if map_corners_calibration_mode:
                            # Save map corners
                            try:
                                # Get world dimensions from calibration
                                world_width = self.calib.world.world_width_cm
                                world_height = self.calib.world.world_height_cm
                                
                                # Get pixel coordinates in order: BL, BR, TR, TL
                                image_points = [
                                    (corners_world_coords[0]['pixel_x'], corners_world_coords[0]['pixel_y']),
                                    (corners_world_coords[1]['pixel_x'], corners_world_coords[1]['pixel_y']),
                                    (corners_world_coords[2]['pixel_x'], corners_world_coords[2]['pixel_y']),
                                    (corners_world_coords[3]['pixel_x'], corners_world_coords[3]['pixel_y']),
                                ]
                                
                                # Compute homography (already computed after each click, but recompute for consistency)
                                new_H = compute_homography_from_corners(image_points, world_width, world_height)
                                
                                # Update calibration object
                                self.calib.homography = new_H
                                self.H = new_H.astype(float)
                                self.H_inv = np.linalg.inv(self.H)
                                
                                # Save to file
                                save_calibration(self.calib, Path(self.calibration_file), merge=True)
                                print("=" * 60)
                                print("✓ MAP CORNERS SAVED! Homography matrix updated.")
                                print(f"Saved to {self.calibration_file}")
                                print("You can continue adjusting corners or press 'm' to exit calibration mode")
                                print("=" * 60)
                            except Exception as e:
                                print(f"ERROR saving map corners: {e}")
                        elif waypoint_calibration_mode:
                            # Save waypoints
                            self.save_waypoints()
                            print("✓ Waypoints saved to calibration file!")
                            print("You can continue adjusting waypoints or press 'c' to exit calibration mode")
                        else:
                            print("Note: Enter calibration mode ('c' for waypoints or 'm' for map corners) first, then press 's' to save")
                
        finally:
            cap.release()
            if show_video:
                cv2.destroyAllWindows()
            if self.udp_socket:
                self.udp_socket.close()
    
    def draw_static_elements(self, frame, hide_waypoints=False):
        """Draw static elements (waypoints, target)"""
        # Draw all waypoints (unless hidden)
        if not hide_waypoints:
            for i, waypoint in enumerate(self.waypoints):
                pixel_x, pixel_y = self.world_to_pixel_camera_compensated(
                    waypoint['world_x'], waypoint['world_y'], 0.0
                )
                
                if 0 <= pixel_x < frame.shape[1] and 0 <= pixel_y < frame.shape[0]:
                    # Draw waypoint circle
                    cv2.circle(frame, (pixel_x, pixel_y), 8, waypoint['color'], -1)
                    cv2.circle(frame, (pixel_x, pixel_y), 4, (255, 255, 255), -1)
                    
                    # Draw waypoint number
                    cv2.putText(frame, str(i + 1), (pixel_x - 5, pixel_y + 5), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2)
                    
                    # Draw waypoint name with enhanced visibility (outline only, no background)
                    name_text = waypoint['name']
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    font_scale_name = 0.4
                    thickness_name = 1
                    name_x = pixel_x + 10
                    name_y = pixel_y - 10
                    
                    # Draw text with outline effect
                    wp_color = waypoint['color']
                    # Draw black outline
                    for dx, dy in [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]:
                        cv2.putText(frame, name_text, (name_x + dx, name_y + dy),
                                   font, font_scale_name, (0, 0, 0), thickness_name + 1)
                    # Draw colored text on top
                    cv2.putText(frame, name_text, (name_x, name_y),
                               font, font_scale_name, wp_color, thickness_name)
        
        # Draw target if set (also hide during map corners calibration)
        if hide_waypoints:
            return  # Don't draw target either during corner calibration
        if self.target_waypoint:
            target_px = self.world_to_pixel_camera_compensated(
                self.target_waypoint['world_x'], self.target_waypoint['world_y'], 0.0
            )
            
            if 0 <= target_px[0] < frame.shape[1] and 0 <= target_px[1] < frame.shape[0]:
                # Use red color for target marker
                target_color = (0, 0, 255)  # Red
                
                # Draw target marker (thinner circle, red color)
                cv2.circle(frame, target_px, 15, target_color, 2)  # Thinner circle (thickness 2 instead of filled)
                cv2.circle(frame, target_px, 8, (255, 255, 255), -1)
                
                # Draw crosshairs (use target color)
                cv2.line(frame, 
                       (target_px[0] - 20, target_px[1]), 
                       (target_px[0] + 20, target_px[1]), 
                       target_color, 2)
                cv2.line(frame, 
                       (target_px[0], target_px[1] - 20), 
                       (target_px[0], target_px[1] + 20), 
                       target_color, 2)
                
                # Draw target label only for custom targets (waypoints already show their name)
                target_name = self.target_waypoint.get('name', 'TARGET')
                if target_name == 'Custom':
                    cv2.putText(frame, target_name.upper(), (target_px[0] + 20, target_px[1]), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.6, target_color, 2)
    
    def draw_waypoint_path(self, frame):
        """Draw path through waypoints (no numbered intermediate points)"""
        if len(self.current_path) > 1:
            path_points_px = []
            for world_x, world_y in self.current_path:
                pixel_x, pixel_y = self.world_to_pixel_camera_compensated(world_x, world_y, 0.0)
                if 0 <= pixel_x < frame.shape[1] and 0 <= pixel_y < frame.shape[0]:
                    path_points_px.append((pixel_x, pixel_y))
            
            # Draw path lines (magenta)
            for i in range(len(path_points_px) - 1):
                cv2.line(frame, path_points_px[i], path_points_px[i + 1], (255, 0, 255), 3)
            
            # Draw waypoints on path (only the actual waypoints, no numbers)
            for i, (px, py) in enumerate(path_points_px):
                if i == 0:  # Robot position
                    cv2.circle(frame, (px, py), 6, (0, 0, 255), -1)  # Red for robot
                elif i == len(path_points_px) - 1:  # Target
                    cv2.circle(frame, (px, py), 6, (0, 255, 0), -1)  # Green for target
                else:  # Intermediate waypoints
                    cv2.circle(frame, (px, py), 6, (255, 255, 0), -1)  # Yellow for intermediate


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Waypoint-based navigation for robots that can't turn on the spot")
    parser.add_argument("--calibration", required=True, help="Calibration file path (unified calibration file)")
    parser.add_argument("--target-waypoint", required=True, help="Target waypoint name")
    parser.add_argument("--stream-port", type=int, default=5000, help="UDP stream port")
    parser.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer")
    parser.add_argument("--model", default="model_car_heading.pt", help="YOLO model path")
    parser.add_argument("--udp-ip", default="127.0.0.1", help="UDP target IP for robot commands")
    parser.add_argument("--udp-port", type=int, default=50001, help="UDP target port for robot commands")
    parser.add_argument("--no-show", action="store_true", help="Don't show video window")
    parser.add_argument("--heading-tolerance", type=float, default=22.5, 
                       help="Heading tolerance in degrees for waypoint selection (default: 22.5°)")
    parser.add_argument("--udp-send-interval", type=int, default=30,
                       help="Send UDP packets every N frames (default: 30)")
    parser.add_argument("--continuous", action="store_true",
                       help="Enable continuous navigation mode for demo - robot will cycle through waypoints without stopping")
    
    args = parser.parse_args()
    
    # Create navigation runner with heading tolerance and UDP settings
    runner = WaypointBasedNavigation(args.calibration, args.model, args.heading_tolerance, args.udp_ip, args.udp_port, args.udp_send_interval, args.continuous)
    
    print(f"Using heading tolerance: {args.heading_tolerance}°")
    print(f"Waypoints must be within {args.heading_tolerance}° of robot heading to be selected")
    print("Robot will go to nearest waypoint in its heading direction first")
    print("MOVEMENT-BASED HEADING ENABLED: Robot heading determined by movement direction (North/South/East/West)")
    if args.continuous:
        print("CONTINUOUS MODE ENABLED: Robot will cycle through all waypoints for demo presentation")
    
    # Start navigation to waypoint
    if runner.start_navigation_to_waypoint(args.target_waypoint):
        # Run with UDP stream
        runner.run_with_udp_stream(
            stream_port=args.stream_port,
            show_video=not args.no_show,
            stream_latency=args.stream_latency
        )


if __name__ == "__main__":
    main()
