#!/usr/bin/env python3
"""
Object Detection System using YOLO model from best.pt
Detects objects in video stream and sends UDP packets with detection information.
"""

import argparse
import os
import socket
import time
from typing import Optional, List, Dict
import numpy as np

# Add OpenCV and GStreamer paths
from config import setup_opencv_gstreamer_paths
setup_opencv_gstreamer_paths()

import cv2

# Import from existing modules
from localization import (
    open_video_capture, send_detection_udp, create_stream_config
)


class ObjectDetector:
    """YOLO-based object detection system with UDP output"""
    
    def __init__(self, model_path: str = "best.pt", device: Optional[str] = None):
        from ultralytics import YOLO
        self.model = YOLO(model_path)
        self.device = device
        
        # UDP settings
        self.udp_socket = None
        self.udp_ip = "127.0.0.1"
        self.udp_port = 50003  # Different port from other services
        
        # Detection settings
        self.confidence_threshold = 0.5
        
        # Statistics
        self.detection_count = 0
        
        # Frame counter for UDP sending frequency control
        self.frame_count = 0
        self.udp_send_interval = 30  # Send UDP packets every 30 frames
        
    def setup_udp_socket(self, ip: str = "127.0.0.1", port: int = 50003):
        """Setup UDP socket for sending detection data"""
        self.udp_ip = ip
        self.udp_port = port
        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        print(f"UDP socket created for object detection on {self.udp_ip}:{self.udp_port}")
    
    def detect_objects(self, frame: np.ndarray) -> List[Dict]:
        """Detect objects in frame and return detection information"""
        detections = []
        
        # Run YOLO inference
        results = self.model(frame, verbose=False, device=self.device)
        if not results:
            return detections
        
        result = results[0]
        if result.boxes is None or len(result.boxes) == 0:
            return detections
        
        # Get class names (YOLO results always have names)
        class_names = getattr(result, 'names', {})
        
        # Process each detection
        for box in result.boxes:
            confidence = float(box.conf[0])
            if confidence < self.confidence_threshold:
                continue
            
            # Get bounding box coordinates (convert to int directly)
            coords = box.xyxy[0].cpu().numpy()
            x1, y1, x2, y2 = int(coords[0]), int(coords[1]), int(coords[2]), int(coords[3])
            
            # Get class information
            class_id = int(box.cls[0]) if hasattr(box, 'cls') else 0
            class_name = class_names.get(class_id, f"class_{class_id}")
            
            # Calculate center point
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            
            detection = {
                'id': self.detection_count,
                'class_id': class_id,
                'class_name': class_name,
                'confidence': confidence,
                'bbox': {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2},
                'center': {'pixel_x': center_x, 'pixel_y': center_y},
                'timestamp': time.time()
            }
            
            detections.append(detection)
            self.detection_count += 1
        
        return detections
    
    def send_detection_udp(self, detections: List[Dict]):
        """Send all detections in a single UDP packet"""
        if self.udp_socket is None or not detections:
            return

        payload = {
            "type": "object_detections",
            "timestamp": time.time(),
            "count": len(detections),
            "detections": [
                {
                    "detection_id": d['id'],
                    "class_name": d['class_name'],
                    "class_id": d['class_id'],
                    "confidence": d['confidence'],
                    "bbox": d['bbox'],
                    "center_pixel": {"x": d['center']['pixel_x'], "y": d['center']['pixel_y']},
                    "detected_at": d['timestamp']
                }
                for d in detections
            ]
        }

        try:
            send_detection_udp(payload, self.udp_ip, self.udp_port, self.udp_socket)
            print(f"UDP: sent {len(detections)} detections")
        except Exception as e:
            print(f"UDP send error: {e}")
    
    def draw_detections(self, frame: np.ndarray, detections: List[Dict]) -> np.ndarray:
        """Draw detection bounding boxes and labels on frame"""
        if not detections:
            return frame
        
        frame_copy = frame.copy()
        color = (0, 255, 0)  # Green
        thickness = 2
        
        for detection in detections:
            bbox = detection['bbox']
            x1, y1, x2, y2 = bbox['x1'], bbox['y1'], bbox['x2'], bbox['y2']
            center = detection['center']
            
            # Draw bounding box
            cv2.rectangle(frame_copy, (x1, y1), (x2, y2), color, thickness)
            
            # Draw center point
            center_x, center_y = int(center['pixel_x']), int(center['pixel_y'])
            cv2.circle(frame_copy, (center_x, center_y), 5, (255, 0, 0), -1)
            
            # Draw label
            label = f"{detection['class_name']}: {detection['confidence']:.2f}"
            label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
            cv2.rectangle(frame_copy, (x1, y1 - label_size[1] - 10), 
                         (x1 + label_size[0], y1), color, -1)
            cv2.putText(frame_copy, label, (x1, y1 - 5), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
        
        return frame_copy
    
    def run_detection(self, stream_port: int = 5000, show_video: bool = True, 
                     stream_latency: int = 5, udp_ip: str = "127.0.0.1", 
                     udp_port: int = 50003, confidence: float = 0.5, 
                     udp_send_interval: int = 30):
        """Run object detection with UDP stream"""
        
        # Setup UDP socket
        self.setup_udp_socket(udp_ip, udp_port)
        self.confidence_threshold = confidence
        self.udp_send_interval = udp_send_interval
        
        # Setup stream configuration
        stream_config = create_stream_config(stream_port, stream_latency)
        
        # Open UDP video stream
        cap = open_video_capture(f"udp://{stream_port}", stream_config)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open UDP stream on port {stream_port}")
        
        print(f"Starting object detection on port {stream_port}...")
        print(f"Features: YOLO detection, UDP transmission, visual overlay")
        print("Controls: 'q'=quit, 's'=save frame, 'i'=info\n")
        
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    print("Failed to read from UDP stream")
                    break
                
                self.frame_count += 1
                
                # Detect objects
                detections = self.detect_objects(frame)
                
                # Send detections via UDP only every N frames
                if detections and (self.frame_count % self.udp_send_interval == 0):
                    self.send_detection_udp(detections)
                
                # Draw detections on frame
                if show_video:
                    frame_with_detections = self.draw_detections(frame, detections)
                    
                    # Draw status info
                    status_text = f"Detections: {len(detections)}"
                    cv2.putText(frame_with_detections, status_text, (10, 30), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                    
                    cv2.imshow("Object Detection", frame_with_detections)
                    key = cv2.waitKey(1) & 0xFF
                    
                    if key == ord('q'):
                        break
                    elif key == ord('s'):
                        # Save current frame
                        filename = f"detection_frame_{int(time.time())}.jpg"
                        cv2.imwrite(filename, frame_with_detections)
                        print(f"Frame saved as {filename}")
                    elif key == ord('i'):
                        # Print detection info
                        print(f"\n=== Detection Info ===")
                        print(f"Total detections: {self.detection_count}")
                        print(f"Current frame detections: {len(detections)}")
                        for i, det in enumerate(detections):
                            print(f"  {i+1}. {det['class_name']} (conf: {det['confidence']:.2f}) at pixel ({det['center']['pixel_x']:.0f}, {det['center']['pixel_y']:.0f})")
                        print("=====================\n")
                    
        finally:
            cap.release()
            if show_video:
                cv2.destroyAllWindows()
            if self.udp_socket:
                self.udp_socket.close()
                print("UDP socket closed")


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Object detection system using YOLO model")
    parser.add_argument("--model", default="best.pt", help="YOLO model path (default: best.pt)")
    parser.add_argument("--stream-port", type=int, default=5000, help="UDP stream port (default: 5000)")
    parser.add_argument("--stream-latency", type=int, default=5, help="Stream latency buffer (default: 5)")
    parser.add_argument("--udp-ip", default="127.0.0.1", help="UDP target IP (default: 127.0.0.1)")
    parser.add_argument("--udp-port", type=int, default=50003, help="UDP target port (default: 50003)")
    parser.add_argument("--confidence", type=float, default=0.9, help="Detection confidence threshold (default: 0.9)")
    parser.add_argument("--device", help="Inference device (e.g., 'cpu', '0', 'cuda')")
    parser.add_argument("--no-show", action="store_true", help="Don't show video window")
    parser.add_argument("--udp-send-interval", type=int, default=30, 
                       help="Send UDP packets every N frames (default: 30)")
    
    args = parser.parse_args()
    
    # Check if model file exists
    if not os.path.exists(args.model):
        print(f"Error: Model file '{args.model}' not found!")
        return 1
    
    # Create object detector
    detector = ObjectDetector(
        model_path=args.model,
        device=args.device
    )
    
    # Run detection
    try:
        detector.run_detection(
            stream_port=args.stream_port,
            show_video=not args.no_show,
            stream_latency=args.stream_latency,
            udp_ip=args.udp_ip,
            udp_port=args.udp_port,
            confidence=args.confidence,
            udp_send_interval=args.udp_send_interval
        )
    except KeyboardInterrupt:
        print("\nDetection stopped by user")
    except Exception as e:
        print(f"Error: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
