#!/bin/bash
# Setup script for AMEC virtual environment (Linux/Mac)

echo "============================================================"
echo "Setting up AMEC Python Virtual Environment"
echo "============================================================"
echo ""

# Detect platform and architecture
PLATFORM="$(uname -s)"
ARCH="$(uname -m)"

echo "[INFO] Platform: $PLATFORM"
echo "[INFO] Architecture: $ARCH"

# Apple Silicon specific checks
if [[ "$PLATFORM" == "Darwin" && "$ARCH" == "arm64" ]]; then
    echo "[INFO] Detected Apple Silicon (M-series) Mac"
    echo "[INFO] See MAC_M_SERIES_SETUP.md for detailed Mac installation guide"
    echo ""
    
    # Check if Homebrew is installed (recommended for Mac)
    if ! command -v brew &> /dev/null; then
        echo "[WARNING] Homebrew not found. Recommended for Mac installation."
        echo "[INFO] Install Homebrew: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
        echo ""
    fi
    
    # Check for GStreamer (required for Mac)
    if ! command -v gst-launch-1.0 &> /dev/null; then
        echo "[WARNING] GStreamer not found. Required for UDP video streams."
        echo "[INFO] Install via Homebrew: brew install gstreamer gst-plugins-base gst-plugins-good"
        echo "[INFO] Or run: ./install_mac_prerequisites.sh"
        echo ""
    fi
    
    # Verify Python is ARM64
    PYTHON_ARCH=$(python3 -c "import platform; print(platform.machine())" 2>/dev/null || echo "unknown")
    if [[ "$PYTHON_ARCH" != "arm64" ]]; then
        echo "[WARNING] Python is not running natively on ARM64 (detected: $PYTHON_ARCH)"
        echo "[WARNING] For best performance, use ARM64-native Python"
        echo ""
    fi
fi

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 is not installed"
    echo "Please install Python 3.8 or higher"
    if [[ "$PLATFORM" == "Darwin" ]]; then
        echo "On Mac: brew install python@3.11"
    fi
    exit 1
fi

echo "[1/4] Creating virtual environment..."
if [ -d "venv" ]; then
    echo "Virtual environment already exists"
    echo ""
else
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to create virtual environment"
        exit 1
    fi
    echo "[OK] Virtual environment created"
fi

echo "[2/4] Activating virtual environment..."
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo "[ERROR] Failed to activate virtual environment"
    exit 1
fi

echo "[3/4] Upgrading pip..."
python -m pip install --upgrade pip

echo "[4/4] Installing dependencies..."

# Apple Silicon: Ensure ARM64 packages
if [[ "$PLATFORM" == "Darwin" && "$ARCH" == "arm64" ]]; then
    echo "[INFO] Installing packages for Apple Silicon..."
    echo "[INFO] PyTorch will be installed with MPS (Metal) support for GPU acceleration"
fi

pip install -r requirements.txt

# Apple Silicon: Verify PyTorch MPS support
if [[ "$PLATFORM" == "Darwin" && "$ARCH" == "arm64" ]]; then
    echo ""
    echo "[INFO] Verifying PyTorch MPS support..."
    python3 -c "import torch; print(f'PyTorch version: {torch.__version__}'); print(f'MPS available: {torch.backends.mps.is_available() if hasattr(torch.backends, \"mps\") else False}')" 2>/dev/null || echo "[INFO] PyTorch MPS check skipped (not critical)"
fi

if [ $? -ne 0 ]; then
    echo "[ERROR] Failed to install dependencies"
    echo "Please check requirements.txt and try again"
    exit 1
fi

echo ""
echo "============================================================"
echo "[OK] Setup complete!"
echo "============================================================"
echo ""
echo "Virtual environment created at: venv"
echo ""
echo "To activate the virtual environment, run:"
echo "  source venv/bin/activate"
echo ""
echo "Then run your program with:"
echo "  python start.py [options]"
echo ""

if [[ "$PLATFORM" == "Darwin" && "$ARCH" == "arm64" ]]; then
    echo "Mac M-series Notes:"
    echo "  - GPU acceleration (MPS) is automatically enabled if available"
    echo "  - For detailed Mac setup, see: MAC_M_SERIES_SETUP.md"
    echo ""
fi

echo "To deactivate:"
echo "  deactivate"
echo ""
