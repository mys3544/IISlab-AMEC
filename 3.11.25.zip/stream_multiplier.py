#!/usr/bin/env python3
"""
Stream Multiplicator
Captures a single UDP video stream and redistributes it to multiple ports.
This allows multiple applications to consume the same stream simultaneously.
"""

import argparse
import threading
import time
from typing import List, Optional

# Add OpenCV and GStreamer paths BEFORE importing cv2
from config import setup_opencv_gstreamer_paths
setup_opencv_gstreamer_paths()

import cv2


class StreamMultiplier:
    """Captures a single UDP stream and redistributes it to multiple ports"""
    
    def __init__(self, source_port: int = 5000, output_ports: Optional[List[int]] = None, 
                 latency: int = 5, bitrate: int = 6000, fps: int = 15):
        self.source_port = source_port
        self.output_ports = output_ports or [5001, 5002, 5003, 5004]
        self.latency = latency
        self.bitrate = bitrate
        self.fps = fps
        
        self.running = False
        self.capture_thread: Optional[threading.Thread] = None
        self.broadcast_threads: List[threading.Thread] = []
        self.frame_buffer: Optional[cv2.Mat] = None
        self.frame_lock = threading.Lock()
        
        self.gst_pipeline = (
            f'udpsrc port={source_port} '
            'caps="application/x-rtp, media=video, encoding-name=H264, payload=96, clock-rate=90000" ! '
            f'rtpjitterbuffer latency={latency} ! '
            'rtph264depay ! h264parse ! avdec_h264 ! '
            'videoconvert ! video/x-raw,format=BGR ! '
            'appsink drop=false sync=false'
        )
        
        print(f"Stream Multiplier initialized:")
        print(f"  Source port: {source_port}")
        print(f"  Output ports: {self.output_ports}")
        print(f"  Latency: {latency}ms, Bitrate: {bitrate} kbps, FPS: {fps}")
    
    @staticmethod
    def _log_fps(frame_count: int, last_time: float, interval: float, 
                 label: str) -> tuple[int, float]:
        """Calculate and log FPS if interval has passed"""
        current_time = time.time()
        if current_time - last_time >= interval:
            fps = frame_count / (current_time - last_time)
            print(f"[INFO] {label} at {fps:.1f} FPS")
            return 0, current_time
        return frame_count, last_time
    
    def capture_stream(self):
        """Capture the source stream using GStreamer"""
        print(f"Starting stream capture from port {self.source_port}...")
        
        try:
            cap = cv2.VideoCapture(self.gst_pipeline, cv2.CAP_GSTREAMER)
            if not cap.isOpened():
                print(f"[ERROR] Failed to open source stream on port {self.source_port}")
                return
            
            print(f"[OK] Connected to source stream on port {self.source_port}")
        except Exception as e:
            print(f"[ERROR] Error setting up video capture: {e}")
            return
        
        frame_count = 0
        last_fps_time = time.time()
        
        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            
            with self.frame_lock:
                self.frame_buffer = frame.copy()
            
            frame_count, last_fps_time = self._log_fps(
                frame_count, last_fps_time, 5.0,
                f"Capturing from port {self.source_port}"
            )
            frame_count += 1
        
        cap.release()
        print("[INFO] Stream capture stopped")
    
    def _get_frame_dimensions(self, timeout: float = 5.0) -> Optional[tuple[int, int]]:
        """Wait for first frame and return dimensions"""
        start_time = time.time()
        while self.running and (time.time() - start_time) < timeout:
            with self.frame_lock:
                if self.frame_buffer is not None:
                    return self.frame_buffer.shape[:2]
            time.sleep(0.1)
        return None
    
    def broadcast_to_port(self, port: int):
        """Broadcast frames to a specific port using GStreamer"""
        print(f"Starting broadcast to port {port}...")
        
        dimensions = self._get_frame_dimensions()
        if dimensions is None:
            print(f"[ERROR] No frames available for port {port}")
            return
        
        frame_height, frame_width = dimensions
        gst_pipeline = (
            f'appsrc caps="video/x-raw,format=BGR,width={frame_width},height={frame_height},framerate={self.fps}/1" ! '
            'videoconvert ! '
            f'x264enc tune=zerolatency bitrate={self.bitrate} speed-preset=ultrafast ! '
            'rtph264pay ! '
            f'udpsink host=127.0.0.1 port={port}'
        )
        
        try:
            out = cv2.VideoWriter(gst_pipeline, cv2.CAP_GSTREAMER, 0, self.fps, (frame_width, frame_height))
            if not out.isOpened():
                print(f"[ERROR] Failed to setup broadcast pipeline for port {port}")
                return
            
            print(f"[OK] Broadcasting to port {port} at {frame_width}x{frame_height}")
        except Exception as e:
            print(f"[ERROR] Error setting up broadcast for port {port}: {e}")
            return
        
        frame_count = 0
        last_fps_time = time.time()
        
        while self.running:
            with self.frame_lock:
                frame = self.frame_buffer.copy() if self.frame_buffer is not None else None
            
            if frame is None:
                time.sleep(0.01)
                continue
            
            out.write(frame)
            frame_count, last_fps_time = self._log_fps(
                frame_count, last_fps_time, 10.0,
                f"Broadcasting to port {port}"
            )
            frame_count += 1
        
        out.release()
        print(f"[INFO] Broadcast to port {port} stopped")
    
    def start(self):
        """Start the stream multiplier"""
        if self.running:
            print("[WARNING] Stream multiplier is already running")
            return
        
        print("[INFO] Starting Stream Multiplier...")
        self.running = True
        
        self.capture_thread = threading.Thread(target=self.capture_stream, daemon=True)
        self.capture_thread.start()
        
        for port in self.output_ports:
            thread = threading.Thread(target=self.broadcast_to_port, args=(port,), daemon=True)
            thread.start()
            self.broadcast_threads.append(thread)
        
        print("[OK] Stream Multiplier started successfully!")
        print("Press Ctrl+C to stop...")
    
    def stop(self):
        """Stop the stream multiplier"""
        if not self.running:
            return
        
        print("[INFO] Stopping Stream Multiplier...")
        self.running = False
        
        if self.capture_thread and self.capture_thread.is_alive():
            self.capture_thread.join(timeout=2.0)
        
        for thread in self.broadcast_threads:
            if thread.is_alive():
                thread.join(timeout=2.0)
        
        print("[OK] Stream Multiplier stopped")


def main():
    parser = argparse.ArgumentParser(description="Stream Multiplier - Redistribute UDP video stream to multiple ports")
    parser.add_argument("--source-port", type=int, default=5000, 
                       help="Source UDP port to capture from (default: 5000)")
    parser.add_argument("--output-ports", nargs="+", type=int, default=[5001, 5002, 5003, 5004],
                       help="Output UDP ports to broadcast to (default: 5001 5002 5003 5004)")
    parser.add_argument("--latency", type=int, default=5,
                       help="Stream latency in milliseconds (default: 5)")
    parser.add_argument("--bitrate", type=int, default=6000,
                       help="Video bitrate in kbps (default: 6000)")
    parser.add_argument("--fps", type=int, default=10,
                       help="Output frame rate in FPS (default: 10)")
    
    args = parser.parse_args()
    
    multiplier = StreamMultiplier(
        source_port=args.source_port,
        output_ports=args.output_ports,
        latency=args.latency,
        bitrate=args.bitrate,
        fps=args.fps
    )
    
    try:
        multiplier.start()
        
        # Keep running until interrupted
        while multiplier.running:
            time.sleep(0.1)
            
    except KeyboardInterrupt:
        print("\n[INFO] Interrupted by user")
    finally:
        multiplier.stop()


if __name__ == "__main__":
    main()
