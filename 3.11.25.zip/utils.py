#!/usr/bin/env python3
"""
Shared utility functions for AMEC applications.
Eliminates code duplication across multiple entry point scripts.
"""

import subprocess
from pathlib import Path
from typing import List, Optional


def run_command(cmd: List[str], name: str, log_file: Optional[Path] = None) -> subprocess.Popen:
    """
    Run a command in a separate process and log output.
    
    Args:
        cmd: Command to run as a list of strings
        name: Display name for the process
        log_file: Optional path to log file (if None, output is piped)
        
    Returns:
        Popen process object
    """
    print(f"[INFO] Starting {name}...")
    print(f"Command: {' '.join(cmd)}")
    
    if log_file:
        with open(log_file, 'w') as f:
            process = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT, text=True)
    else:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    
    return process

